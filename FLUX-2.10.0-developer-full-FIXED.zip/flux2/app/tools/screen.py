"""Экран: скриншоты всего экрана, отдельного окна, области, монитора и вкладки браузера.

ЧТО БЫЛО СЛОМАНО В СТАРОМ `screen_screenshot` (app/tools/computer.py):

1) ВСПЛЫВАЮЩАЯ КОНСОЛЬ.
   `_ps()` звал `subprocess.run(["powershell", ...])` без `creationflags`. Так как
   FluxChat.exe / pywebview / pythonw создаются БЕЗ консоли, Windows выделяла
   powershell.exe новую консоль -> чёрное окно мигало на каждый скриншот.
   -> все дочерние процессы теперь через app.winproc (CREATE_NO_WINDOW + SW_HIDE).

2) `$args[0]` ПУСТ -> ФАЙЛ НЕ СОХРАНЯЛСЯ.
   Скрипт заканчивался `$bmp.Save($args[0], …)`, а путь дописывался строкой к
   `-Command`. В режиме `-Command` PowerShell НЕ заполняет `$args` (это работает
   только для `-File`, скрипт-блоков и функций). Итог: `Save($null)`, файла нет,
   тулз отвечал «PowerShell не смог сохранить скриншот». Та же ошибка была в OCR.
   -> аргументы инлайнятся как PS-литералы (winproc.ps_quote), `$args` не используется.

3) МЕДЛЕННО. Холодный старт powershell.exe = 0.6–1.5 с на каждый снимок.
   -> основной путь теперь ЧИСТЫЙ Win32 GDI через ctypes (BitBlt / PrintWindow /
      GetDIBits): ноль дочерних процессов, снимок за ~20–60 мс. PowerShell остался
      только как последний фолбэк.

4) 64-БИТНЫЕ РУЧКИ. В старом коде не задавались `restype`/`argtypes`, а ctypes по
   умолчанию считает возвращаемое значение `c_int` — на x64 это ОБРЕЗАЕТ HWND/HDC/
   HBITMAP до 32 бит и даёт то «чёрный кадр», то падение. Здесь все прототипы объявлены.

5) НЕ БЫЛО ВЫБОРА ЦЕЛИ: только весь экран. Добавлены окно (по HWND/заголовку),
   область, конкретный монитор, вкладка браузера (CDP/мост), элемент страницы,
   снимок с задержкой (чтобы поймать раскрытое меню) и список окон/мониторов.

PNG кодируется встроенным кодеком (zlib + struct), поэтому Pillow/pyautogui НЕ
требуются; если Pillow есть — используется он (быстрее и умеет честный ресайз).
"""
from __future__ import annotations

import base64
import ctypes
import os
import shutil
import struct
import sys
import time
import zlib
from typing import Optional

from .. import winproc
from ..config import app_dir
from .registry import P, REG, ToolResult

C = "screen"
T = REG.tool

NT = sys.platform == "win32"
MAC = sys.platform == "darwin"
LNX = not NT and not MAC

SHOTS_DIR = os.path.join(app_dir(), "data", "shots")

try:
    from PIL import Image as _PILImage           # опционально
except Exception:
    _PILImage = None


# ============================================================== PNG-кодер
def _chunk(tag: bytes, data: bytes) -> bytes:
    return (struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def encode_png(width: int, height: int, bgra: bytes, downscale: int = 1) -> bytes:
    """BGRA (top-down, 32 бита на пиксель) -> PNG. Без сторонних зависимостей.

    Перестановка каналов делается срезами с шагом (это C-уровень, а не цикл по
    пикселям), поэтому 1080p кодируется за десятки миллисекунд.
    """
    downscale = max(1, int(downscale or 1))
    raw = bytearray()
    out_w = 0
    for y in range(height):
        row = bgra[y * width * 4:(y + 1) * width * 4]
        b, g, r = row[0::4], row[1::4], row[2::4]
        if downscale > 1:
            b, g, r = b[::downscale], g[::downscale], r[::downscale]
        out_w = len(r)
        line = bytearray(out_w * 3)
        line[0::3] = r
        line[1::3] = g
        line[2::3] = b
        raw.append(0)                     # фильтр «None» для строки
        raw += line
    if out_w == 0:
        raise ValueError("пустой кадр")
    ihdr = struct.pack(">IIBBBBB", out_w, height, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", ihdr)
            + _chunk(b"IDAT", zlib.compress(bytes(raw), 6)) + _chunk(b"IEND", b""))


def save_png(path: str, width: int, height: int, bgra: bytes, downscale: int = 1) -> str:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data = encode_png(width, height, bgra, downscale)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)
    return path


# ============================================================== Win32 GDI
if NT:
    import ctypes.wintypes          # обязателен явный импорт: ctypes его сам не подтягивает

    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    try:
        dwmapi = ctypes.windll.dwmapi
    except Exception:
        dwmapi = None

    class RECT(ctypes.Structure):
        _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                    ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

    class POINT(ctypes.Structure):
        _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

    class CURSORINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.wintypes.DWORD), ("flags", ctypes.wintypes.DWORD),
                    ("hCursor", ctypes.wintypes.HANDLE), ("ptScreenPos", POINT)]

    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [("biSize", ctypes.wintypes.DWORD), ("biWidth", ctypes.c_long),
                    ("biHeight", ctypes.c_long), ("biPlanes", ctypes.wintypes.WORD),
                    ("biBitCount", ctypes.wintypes.WORD), ("biCompression", ctypes.wintypes.DWORD),
                    ("biSizeImage", ctypes.wintypes.DWORD), ("biXPelsPerMeter", ctypes.c_long),
                    ("biYPelsPerMeter", ctypes.c_long), ("biClrUsed", ctypes.wintypes.DWORD),
                    ("biClrImportant", ctypes.wintypes.DWORD)]

    class BITMAPINFO(ctypes.Structure):
        _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", ctypes.wintypes.DWORD * 3)]

    class MONITORINFOEX(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.wintypes.DWORD), ("rcMonitor", RECT), ("rcWork", RECT),
                    ("dwFlags", ctypes.wintypes.DWORD), ("szDevice", ctypes.c_wchar * 32)]

    SRCCOPY = 0x00CC0020
    CAPTUREBLT = 0x40000000
    DIB_RGB_COLORS = 0
    BI_RGB = 0
    PW_RENDERFULLCONTENT = 0x00000002
    PW_CLIENTONLY = 0x00000001
    DI_NORMAL = 0x0003
    CURSOR_SHOWING = 0x00000001
    SM_XVIRTUALSCREEN, SM_YVIRTUALSCREEN = 76, 77
    SM_CXVIRTUALSCREEN, SM_CYVIRTUALSCREEN = 78, 79
    SM_CXSCREEN, SM_CYSCREEN = 0, 1
    DWMWA_EXTENDED_FRAME_BOUNDS = 9
    DWMWA_CLOAKED = 14
    MONITORINFOF_PRIMARY = 1

    # --- прототипы: на x64 без restype ctypes обрежет ручку до 32 бит -------
    user32.GetDC.restype = ctypes.wintypes.HDC
    user32.GetDC.argtypes = [ctypes.wintypes.HWND]
    user32.GetWindowDC.restype = ctypes.wintypes.HDC
    user32.GetWindowDC.argtypes = [ctypes.wintypes.HWND]
    user32.ReleaseDC.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.HDC]
    user32.GetForegroundWindow.restype = ctypes.wintypes.HWND
    user32.GetWindowRect.argtypes = [ctypes.wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.argtypes = [ctypes.wintypes.HWND, ctypes.POINTER(RECT)]
    user32.ClientToScreen.argtypes = [ctypes.wintypes.HWND, ctypes.POINTER(POINT)]
    user32.PrintWindow.restype = ctypes.wintypes.BOOL
    user32.PrintWindow.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.HDC, ctypes.wintypes.UINT]
    user32.IsWindow.argtypes = [ctypes.wintypes.HWND]
    user32.IsWindowVisible.argtypes = [ctypes.wintypes.HWND]
    user32.IsIconic.argtypes = [ctypes.wintypes.HWND]
    user32.GetWindowTextLengthW.argtypes = [ctypes.wintypes.HWND]
    user32.GetWindowTextW.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowThreadProcessId.argtypes = [ctypes.wintypes.HWND, ctypes.POINTER(ctypes.wintypes.DWORD)]
    user32.ShowWindow.argtypes = [ctypes.wintypes.HWND, ctypes.c_int]
    user32.SetForegroundWindow.argtypes = [ctypes.wintypes.HWND]
    user32.GetCursorInfo.argtypes = [ctypes.POINTER(CURSORINFO)]
    user32.EnumWindows.restype = ctypes.wintypes.BOOL
    user32.GetSystemMetrics.argtypes = [ctypes.c_int]
    user32.MonitorFromWindow.restype = ctypes.wintypes.HANDLE
    user32.MonitorFromWindow.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.DWORD]
    user32.GetMonitorInfoW.argtypes = [ctypes.wintypes.HANDLE, ctypes.POINTER(MONITORINFOEX)]

    gdi32.CreateCompatibleDC.restype = ctypes.wintypes.HDC
    gdi32.CreateCompatibleDC.argtypes = [ctypes.wintypes.HDC]
    gdi32.CreateCompatibleBitmap.restype = ctypes.wintypes.HBITMAP
    gdi32.CreateCompatibleBitmap.argtypes = [ctypes.wintypes.HDC, ctypes.c_int, ctypes.c_int]
    gdi32.SelectObject.restype = ctypes.wintypes.HGDIOBJ
    gdi32.SelectObject.argtypes = [ctypes.wintypes.HDC, ctypes.wintypes.HGDIOBJ]
    gdi32.BitBlt.restype = ctypes.wintypes.BOOL
    gdi32.BitBlt.argtypes = [ctypes.wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                             ctypes.c_int, ctypes.wintypes.HDC, ctypes.c_int, ctypes.c_int,
                             ctypes.wintypes.DWORD]
    gdi32.GetDIBits.argtypes = [ctypes.wintypes.HDC, ctypes.wintypes.HBITMAP, ctypes.wintypes.UINT,
                                ctypes.wintypes.UINT, ctypes.c_void_p, ctypes.POINTER(BITMAPINFO),
                                ctypes.wintypes.UINT]
    gdi32.DeleteObject.argtypes = [ctypes.wintypes.HGDIOBJ]
    gdi32.DeleteDC.argtypes = [ctypes.wintypes.HDC]
    user32.DrawIconEx.restype = ctypes.wintypes.BOOL
    user32.DrawIconEx.argtypes = [ctypes.wintypes.HDC, ctypes.c_int, ctypes.c_int,
                                  ctypes.wintypes.HANDLE, ctypes.c_int, ctypes.c_int,
                                  ctypes.wintypes.UINT, ctypes.wintypes.HBRUSH,
                                  ctypes.wintypes.UINT]

    if dwmapi is not None:
        dwmapi.DwmGetWindowAttribute.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.DWORD,
                                                 ctypes.c_void_p, ctypes.wintypes.DWORD]

    _dpi_done = False

    def ensure_dpi_aware() -> str:
        """Per-Monitor V2 -> System -> SetProcessDPIAware. Без этого на 150% масштабе
        снимок получится обрезанным/растянутым, а координаты окон не сойдутся с пикселями."""
        global _dpi_done
        if _dpi_done:
            return "ok"
        _dpi_done = True
        for fn, arg in (("SetProcessDpiAwarenessContext", -4),   # Win10 1703+
                        ("SetProcessDpiAwareness", 2)):          # Win8.1+
            try:
                lib = ctypes.windll.user32 if fn.endswith("Context") else ctypes.windll.shcore
                if fn == "SetProcessDpiAwarenessContext":
                    if lib.SetProcessDpiAwarenessContext(ctypes.c_void_p(arg)):
                        return "per-monitor-v2"
                elif lib.SetProcessDpiAwareness(arg) == 0:
                    return "per-monitor"
            except Exception:
                continue
        try:
            user32.SetProcessDPIAware()
            return "system"
        except Exception:
            return "none"

    def _proc_name(hwnd) -> str:
        pid = ctypes.wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return ""
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        h = None
        try:
            k32 = ctypes.windll.kernel32
            k32.OpenProcess.restype = ctypes.wintypes.HANDLE
            k32.OpenProcess.argtypes = [ctypes.wintypes.DWORD, ctypes.wintypes.BOOL, ctypes.wintypes.DWORD]
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
            if not h:
                return f"pid:{pid.value}"
            buf = ctypes.create_unicode_buffer(512)
            size = ctypes.wintypes.DWORD(512)
            k32.QueryFullProcessImageNameW.argtypes = [ctypes.wintypes.HANDLE, ctypes.wintypes.DWORD,
                                                       ctypes.wintypes.LPWSTR,
                                                       ctypes.POINTER(ctypes.wintypes.DWORD)]
            if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                return os.path.basename(buf.value)
        except Exception:
            pass
        finally:
            if h:
                try:
                    ctypes.windll.kernel32.CloseHandle(h)
                except Exception:
                    pass
        return f"pid:{pid.value}"

    def _title(hwnd) -> str:
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value or ""

    def _class(hwnd) -> str:
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        return buf.value or ""

    def _is_cloaked(hwnd) -> bool:
        """UWP-приложения и свёрнутые «виртуальные» окна помечены cloaked — их не показываем."""
        if dwmapi is None:
            return False
        val = ctypes.wintypes.DWORD(0)
        try:
            if dwmapi.DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, ctypes.byref(val),
                                            ctypes.sizeof(val)) == 0:
                return val.value != 0
        except Exception:
            pass
        return False

    def list_windows(include_empty: bool = False, limit: int = 200) -> list[dict]:
        """Видимые окна верхнего уровня: hwnd, заголовок, класс, процесс, геометрия."""
        ensure_dpi_aware()
        out: list[dict] = []

        @ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HWND, ctypes.wintypes.LPARAM)
        def cb(hwnd, _lp):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return True
                title = _title(hwnd)
                if not title and not include_empty:
                    return True
                if _is_cloaked(hwnd):
                    return True
                r = RECT()
                if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
                    return True
                if dwmapi is not None:
                    er = RECT()
                    if dwmapi.DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS,
                                                    ctypes.byref(er), ctypes.sizeof(er)) == 0:
                        r = er
                w, h = r.right - r.left, r.bottom - r.top
                if w < 40 or h < 24:
                    return True
                out.append({
                    "hwnd": int(hwnd), "title": title, "class": _class(hwnd),
                    "process": _proc_name(hwnd),
                    "rect": [r.left, r.top, w, h],
                    "minimized": bool(user32.IsIconic(hwnd)),
                    "foreground": hwnd == user32.GetForegroundWindow(),
                })
            except Exception:
                pass
            return True

        user32.EnumWindows(cb, 0)
        out.sort(key=lambda d: (not d["foreground"], d["process"].lower(), d["title"].lower()))
        return out[:limit]

    def find_window(title: str = "", hwnd: int = 0, process: str = "") -> Optional[dict]:
        """Поиск окна: точный HWND -> точный заголовок -> подстрока заголовка -> процесс."""
        wins = list_windows()
        if hwnd:
            for w in wins:
                if w["hwnd"] == int(hwnd):
                    return w
        if title:
            t = title.strip().lower()
            for w in wins:
                if w["title"].lower() == t:
                    return w
            hits = [w for w in wins if t in w["title"].lower()]
            if len(hits) == 1:
                return hits[0]
            if len(hits) > 1:
                hits.sort(key=lambda w: len(w["title"]))
                return hits[0]
        if process:
            p = process.strip().lower()
            hits = [w for w in wins if p in w["process"].lower()]
            if hits:
                return hits[0]
        return None

    def list_monitors() -> list[dict]:
        ensure_dpi_aware()
        out: list[dict] = []

        @ctypes.WINFUNCTYPE(ctypes.wintypes.BOOL, ctypes.wintypes.HANDLE, ctypes.wintypes.HDC,
                            ctypes.POINTER(RECT), ctypes.wintypes.LPARAM)
        def cb(hmon, _hdc, _lprc, _lp):
            mi = MONITORINFOEX()
            mi.cbSize = ctypes.sizeof(MONITORINFOEX)
            if user32.GetMonitorInfoW(hmon, ctypes.byref(mi)):
                r = mi.rcMonitor
                out.append({"index": len(out), "device": mi.szDevice,
                            "primary": bool(mi.dwFlags & MONITORINFOF_PRIMARY),
                            "rect": [r.left, r.top, r.right - r.left, r.bottom - r.top]})
            return True

        user32.EnumDisplayMonitors(None, None, cb, 0)
        if not out:
            w = user32.GetSystemMetrics(SM_CXSCREEN)
            h = user32.GetSystemMetrics(SM_CYSCREEN)
            out.append({"index": 0, "device": "DISPLAY", "primary": True, "rect": [0, 0, w, h]})
        out.sort(key=lambda m: (not m["primary"], m["index"]))
        for i, m in enumerate(out):
            m["index"] = i
        return out

    def _dib_from_dc(hdc_mem, hbmp, w: int, h: int) -> bytes:
        bmi = BITMAPINFO()
        bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.bmiHeader.biWidth = w
        bmi.bmiHeader.biHeight = -h            # отрицательная -> top-down, как нужно PNG
        bmi.bmiHeader.biPlanes = 1
        bmi.bmiHeader.biBitCount = 32
        bmi.bmiHeader.biCompression = BI_RGB
        buf = ctypes.create_string_buffer(w * h * 4)
        got = gdi32.GetDIBits(hdc_mem, hbmp, 0, h, buf, ctypes.byref(bmi), DIB_RGB_COLORS)
        if not got:
            raise RuntimeError("GetDIBits вернул 0")
        return buf.raw

    def _looks_black(bgra: bytes, samples: int = 64) -> bool:
        """PrintWindow на некоторых приложениях даёт чёрный кадр — надо откатиться на BitBlt."""
        n = len(bgra)
        if n < 4:
            return True
        step = max(4, (n // samples) // 4 * 4)
        for i in range(0, n - 3, step):
            if bgra[i] or bgra[i + 1] or bgra[i + 2]:
                return False
        return True

    def capture(x: int, y: int, w: int, h: int, *, hwnd: Optional[int] = None,
                client_only: bool = False, include_cursor: bool = False,
                layered: bool = True) -> tuple[int, int, bytes]:
        """Снимок области экрана или окна. Возвращает (width, height, BGRA)."""
        ensure_dpi_aware()
        if w <= 0 or h <= 0:
            raise ValueError(f"некорректный размер кадра: {w}x{h}")
        if w * h > 200_000_000:
            raise ValueError("слишком большая область (лимит ~200 Мп)")

        hdc_screen = user32.GetDC(None)
        if not hdc_screen:
            raise RuntimeError("GetDC(None) вернул NULL")
        hdc_mem = hbmp = old = None
        try:
            hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
            if not hdc_mem:
                raise RuntimeError("CreateCompatibleDC вернул NULL")
            hbmp = gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
            if not hbmp:
                raise RuntimeError("CreateCompatibleBitmap вернул NULL")
            old = gdi32.SelectObject(hdc_mem, hbmp)

            done = False
            if hwnd:
                flags = PW_RENDERFULLCONTENT | (PW_CLIENTONLY if client_only else 0)
                try:
                    done = bool(user32.PrintWindow(hwnd, hdc_mem, flags))
                except Exception:
                    done = False

            if not done:
                rop = SRCCOPY | (CAPTUREBLT if layered else 0)
                if not gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_screen, x, y, rop):
                    raise RuntimeError("BitBlt не удался (защищённый контент или DRM-окно?)")

            if include_cursor:
                try:
                    ci = CURSORINFO()
                    ci.cbSize = ctypes.sizeof(CURSORINFO)
                    if user32.GetCursorInfo(ctypes.byref(ci)) and (ci.flags & CURSOR_SHOWING):
                        user32.DrawIconEx(hdc_mem, ci.ptScreenPos.x - x, ci.ptScreenPos.y - y,
                                          ci.hCursor, 0, 0, 0, None, DI_NORMAL)
                except Exception:
                    pass

            data = _dib_from_dc(hdc_mem, hbmp, w, h)
            if hwnd and done and _looks_black(data):
                # PrintWindow отдал чёрный кадр -> честный BitBlt по экранным координатам
                r = RECT()
                user32.GetWindowRect(hwnd, ctypes.byref(r))
                if gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_screen, r.left, r.top,
                                SRCCOPY | (CAPTUREBLT if layered else 0)):
                    data = _dib_from_dc(hdc_mem, hbmp, w, h)
            return w, h, data
        finally:
            try:
                if hdc_mem and old:
                    gdi32.SelectObject(hdc_mem, old)
                if hbmp:
                    gdi32.DeleteObject(hbmp)
                if hdc_mem:
                    gdi32.DeleteDC(hdc_mem)
            finally:
                user32.ReleaseDC(None, hdc_screen)

    def virtual_screen_rect() -> tuple[int, int, int, int]:
        return (user32.GetSystemMetrics(SM_XVIRTUALSCREEN),
                user32.GetSystemMetrics(SM_YVIRTUALSCREEN),
                user32.GetSystemMetrics(SM_CXVIRTUALSCREEN),
                user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))


# ============================================================== PowerShell-фолбэк
_PS_SHOOT = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$out = $a0
$x = [int]$a1; $y = [int]$a2; $w = [int]$a3; $h = [int]$a4
if ($w -le 0 -or $h -le 0) {
  $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
  $x = $b.X; $y = $b.Y; $w = $b.Width; $h = $b.Height
}
$bmp = New-Object System.Drawing.Bitmap $w, $h
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($x, $y, 0, 0, (New-Object System.Drawing.Size $w, $h))
$bmp.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Output ("OK " + (Get-Item $out).Length)
"""


def _ps_shoot(path: str, x: int, y: int, w: int, h: int) -> bool:
    """Запасной путь. ОБРАТИ ВНИМАНИЕ: путь передаётся через $a0 (см. winproc.ps_command),
    а НЕ через $args — именно так был сломан старый код."""
    out = winproc.ps(_PS_SHOOT, args=[path, int(x), int(y), int(w), int(h)], timeout=30)
    return out.startswith("OK") and os.path.exists(path) and os.path.getsize(path) > 200


def _sh(cmd: list[str], timeout: int = 25) -> str:
    try:
        r = winproc.run(cmd, timeout=timeout)
        return ((r.stdout or "") + (r.stderr or "")).strip()
    except Exception:
        return ""


def _have(*tools: str) -> Optional[str]:
    for t in tools:
        p = shutil.which(t)
        if p:
            return p
    return None


# ============================================================== сохранение результата
def _shot_path(prefix: str = "screen") -> str:
    os.makedirs(SHOTS_DIR, exist_ok=True)
    return os.path.join(SHOTS_DIR, f"{prefix}_{int(time.time() * 1000)}.png")


def _result(path: str, what: str, w: int = 0, h: int = 0,
            downscale: int = 1, extra: Optional[dict] = None) -> ToolResult:
    size = os.path.getsize(path) if os.path.exists(path) else 0
    if size <= 0:
        return ToolResult(False, f"файл не создан: {path}")
    meta = {"path": path, "bytes": size, "what": what}
    if w and h:
        meta["size"] = f"{w}x{h}"
        if downscale > 1:
            meta["saved_as"] = f"{w // downscale}x{h // downscale}"
    if extra:
        meta.update(extra)
    return ToolResult(True, f"{what}: {path} ({size // 1024} КБ"
                            + (f", {meta['size']}" if w and h else "") + ")",
                      images=[path], data=meta)


# ============================================================== основная съёмка
def shoot(target: str = "screen", *, window: str = "", hwnd: int = 0, process: str = "",
          monitor: int = -1, x: int = 0, y: int = 0, w: int = 0, h: int = 0,
          include_cursor: bool = False, client_only: bool = False, downscale: int = 1,
          delay: float = 0.0, bring_to_front: bool = False, layered: bool = True) -> ToolResult:
    """Единая точка съёмки для всех тулзов. target: screen|window|region|monitor."""
    try:
        if delay and delay > 0:
            time.sleep(min(float(delay), 30.0))
        downscale = max(1, min(8, int(downscale or 1)))
        target = (target or "screen").lower()

        # --- Windows: чистый Win32, без единого дочернего процесса -----------
        if NT:
            wx = wy = ww = wh = 0
            use_hwnd: Optional[int] = None
            what = "весь экран"
            if target == "window":
                info = find_window(window, hwnd, process)
                if not info:
                    avail = "\n".join(f"  {i['hwnd']} | {i['process']} | {i['title'][:70]}"
                                      for i in list_windows()[:25])
                    return ToolResult(False, f"окно не найдено: {window or hwnd or process}\n"
                                             f"Доступные окна:\n{avail or '  (нет)'}")
                use_hwnd = info["hwnd"]
                wx, wy, ww, wh = info["rect"]
                if client_only:
                    # клиентская область: пересчёт из координат окна
                    r = RECT()
                    user32.GetClientRect(use_hwnd, ctypes.byref(r))
                    p = POINT(0, 0)
                    user32.ClientToScreen(use_hwnd, ctypes.byref(p))
                    wx, wy = p.x, p.y
                    ww, wh = r.right - r.left, r.bottom - r.top
                if info["minimized"] or bring_to_front:
                    user32.ShowWindow(use_hwnd, 9)     # SW_RESTORE
                    user32.SetForegroundWindow(use_hwnd)
                    time.sleep(0.25)
                what = f"окно «{info['title'][:60]}» ({info['process']})"
            elif target == "monitor":
                mons = list_monitors()
                if not mons:
                    return ToolResult(False, "мониторы не найдены")
                idx = 0 if monitor < 0 else min(monitor, len(mons) - 1)
                m = mons[idx]
                wx, wy, ww, wh = m["rect"]
                what = f"монитор #{m['index']} {m['device']} ({ww}x{wh})"
            elif target == "region":
                if w <= 0 or h <= 0:
                    return ToolResult(False, "для области нужны width и height больше 0")
                wx, wy, ww, wh = x, y, w, h
                what = f"область {wx},{wy} {ww}x{wh}"
            else:
                vx, vy, vw, vh = virtual_screen_rect()
                if vw <= 0 or vh <= 0:
                    vw, vh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
                wx, wy, ww, wh = vx, vy, vw, vh
                multi = len(list_monitors()) > 1
                what = "весь виртуальный экран" if multi else "весь экран"

            if ww <= 0 or wh <= 0:
                return ToolResult(False, f"нулевой размер кадра: {ww}x{wh}")

            try:
                cw, ch, bgra = capture(wx, wy, ww, wh, hwnd=use_hwnd,
                                       client_only=False, include_cursor=include_cursor,
                                       layered=layered)
                path = _shot_path({"window": "window", "region": "region",
                                   "monitor": "monitor"}.get(target, "screen"))
                save_png(path, cw, ch, bgra, downscale)
                return _result(path, what, cw, ch, downscale,
                               {"backend": "win32-gdi", "hwnd": use_hwnd or 0,
                                "rect": [wx, wy, ww, wh]})
            except Exception as e:
                # GDI не смог (очень старая Windows, защищённый рабочий стол) -> PowerShell
                path = _shot_path("screen_ps")
                if _ps_shoot(path, wx, wy, ww, wh):
                    return _result(path, what + " (через PowerShell, скрыто)", ww, wh, 1,
                                   {"backend": "powershell-hidden", "gdi_error": str(e)})
                return ToolResult(False, f"Win32 GDI: {type(e).__name__}: {e}; PowerShell тоже не смог")

        # --- macOS -----------------------------------------------------------
        if MAC:
            exe = _have("screencapture")
            if not exe:
                return ToolResult(False, "нет screencapture (macOS?)")
            path = _shot_path(target)
            argv = [exe, "-x"]
            if target == "region" and w and h:
                argv += ["-R", f"{x},{y},{w},{h}"]
            elif target == "window":
                # window id даёт только Quartz; без pyobjc — через System Events
                wid = _mac_window_id(window)
                if wid:
                    argv += ["-l", str(wid)]
                else:
                    box = _mac_window_bounds(window)
                    if box:
                        argv += ["-R", ",".join(str(int(v)) for v in box)]
            _sh(argv + [path], timeout=25)
            if os.path.exists(path) and os.path.getsize(path) > 200:
                return _result(path, f"скриншот ({target})", 0, 0, 1, {"backend": "screencapture"})
            return ToolResult(False, "screencapture не создал файл (проверь доступ к записи экрана)")

        # --- Linux -----------------------------------------------------------
        if target == "window":
            xid = _x11_window_id(window)
            imp = _have("import")
            if xid and imp:
                path = _shot_path("window")
                _sh([imp, "-window", str(xid), path], timeout=25)
                if os.path.exists(path) and os.path.getsize(path) > 200:
                    return _result(path, f"окно «{window}»", 0, 0, 1, {"backend": "imagemagick"})
        path = _shot_path(target)
        if target == "region" and w and h:
            for tool, argv in (("grim", [_have("grim"), "-g", f"{x},{y} {w}x{h}", path]),
                               ("import", [_have("import"), "-crop", f"{w}x{h}+{x}+{y}",
                                           "x:", path])):
                if argv[0]:
                    _sh(argv, timeout=25)
                    if os.path.exists(path) and os.path.getsize(path) > 200:
                        return _result(path, f"область {x},{y} {w}x{h}", w, h, 1,
                                       {"backend": tool})
        for tool in ("scrot", "grim", "gnome-screenshot", "spectacle", "import"):
            exe = _have(tool)
            if not exe:
                continue
            argv = {"scrot": [exe, "-z", path],
                    "grim": [exe, path],
                    "gnome-screenshot": [exe, "-f", path],
                    "spectacle": [exe, "-b", "-n", "-o", path],
                    "import": [exe, "-window", "root", path]}[tool]
            _sh(argv, timeout=25)
            if os.path.exists(path) and os.path.getsize(path) > 200:
                return _result(path, f"скриншот ({target})", 0, 0, 1, {"backend": tool})
        return ToolResult(False, "нет бэкенда скриншота: нужны scrot / grim / gnome-screenshot "
                                 "/ imagemagick(import) или pyautogui")
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")


def _mac_window_id(title: str) -> Optional[int]:
    try:
        import Quartz  # pyobjc
        wl = Quartz.CGWindowListCopyWindowInfo(
            Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements,
            Quartz.kCGNullWindowID)
        t = (title or "").lower()
        for w in wl:
            name = (w.get("kCGWindowName") or "")
            if t and t in name.lower():
                return int(w["kCGWindowNumber"])
    except Exception:
        pass
    return None


def _mac_window_bounds(title: str) -> Optional[list]:
    script = ('tell application "System Events" to tell (first process whose name contains '
              f'"{title}") to get {{position, size}} of window 1')
    out = _sh(["osascript", "-e", script], timeout=15)
    try:
        nums = [int(v) for v in out.replace(" ", "").split(",") if v.strip()]
        if len(nums) == 4:
            return [nums[0], nums[1], nums[2], nums[3]]
    except Exception:
        pass
    return None


def _x11_window_id(title: str) -> Optional[int]:
    xdo = _have("xdotool")
    if not xdo or not title:
        return None
    out = _sh([xdo, "search", "--name", title], timeout=10)
    for line in out.splitlines():
        line = line.strip()
        if line.isdigit():
            return int(line)
    return None


# ============================================================== ТУЛЗЫ
@T("screen_screenshot",
   "Скриншот экрана БЕЗ всплывающих окон консоли и мгновенно (Win32 GDI через ctypes, "
   "а не PowerShell). target: screen=весь экран | window=конкретное окно | region=область | "
   "monitor=один монитор. Для окна задай `window` (часть заголовка) или `hwnd`. "
   "Для вкладки браузера используй screen_capture_browser_tab.",
   [P("target", desc="screen|window|region|monitor", required=False, default="screen",
      enum=["screen", "window", "region", "monitor"]),
    P("window", desc="часть заголовка окна (для target=window)", required=False, default=""),
    P("hwnd", "integer", desc="HWND окна (точнее заголовка)", required=False, default=0),
    P("monitor", "integer", desc="индекс монитора (0=основной)", required=False, default=-1),
    P("x", "integer", desc="X области", required=False, default=0),
    P("y", "integer", desc="Y области", required=False, default=0),
    P("width", "integer", desc="ширина области", required=False, default=0),
    P("height", "integer", desc="высота области", required=False, default=0),
    P("include_cursor", "boolean", desc="рисовать курсор на снимке", required=False, default=False),
    P("client_only", "boolean", desc="только клиентская область окна (без рамки/заголовка)",
      required=False, default=False),
    P("downscale", "integer", desc="уменьшить в N раз (1-8) — меньше файл для модели",
      required=False, default=1),
    P("delay_s", "number", desc="задержка перед снимком, с (чтобы поймать меню)",
      required=False, default=0)],
   C, core=True)
def _(ctx, target, window, hwnd, monitor, x, y, width, height, include_cursor,
      client_only, downscale, delay_s):
    return shoot(target, window=window, hwnd=hwnd, monitor=monitor, x=x, y=y,
                 w=width, h=height, include_cursor=include_cursor, client_only=client_only,
                 downscale=downscale, delay=delay_s or 0)


@T("screen_capture_window",
   "Скриншот КОНКРЕТНОГО ОКНА (PrintWindow с PW_RENDERFULLCONTENT — снимает даже "
   "перекрытые и Chrome/Electron-окна; при чёрном кадре автоматически откатывается на BitBlt). "
   "Окно ищется по части заголовка, HWND или имени процесса.",
   [P("window", desc="часть заголовка окна, например 'Chrome' или 'Блокнот'", required=False, default=""),
    P("hwnd", "integer", desc="HWND (если известен — точнее всего)", required=False, default=0),
    P("process", desc="имя процесса, например chrome.exe", required=False, default=""),
    P("client_only", "boolean", desc="без рамки и заголовка", required=False, default=False),
    P("bring_to_front", "boolean", desc="сначала развернуть/поднять окно", required=False, default=False),
    P("include_cursor", "boolean", desc="рисовать курсор", required=False, default=False),
    P("downscale", "integer", desc="уменьшить в N раз (1-8)", required=False, default=1),
    P("delay_s", "number", desc="задержка перед снимком, с", required=False, default=0)],
   C, core=True)
def _(ctx, window, hwnd, process, client_only, bring_to_front, include_cursor, downscale, delay_s):
    if not (window or hwnd or process):
        return ToolResult(False, "укажи window (часть заголовка), hwnd или process. "
                                 "Список окон — screen_windows_list")
    return shoot("window", window=window, hwnd=hwnd, process=process, client_only=client_only,
                 bring_to_front=bring_to_front, include_cursor=include_cursor,
                 downscale=downscale, delay=delay_s or 0)


@T("screen_capture_region", "Скриншот прямоугольной области экрана (в пикселях)",
   [P("x", "integer", desc="левый верхний X"), P("y", "integer", desc="левый верхний Y"),
    P("width", "integer", desc="ширина"), P("height", "integer", desc="высота"),
    P("include_cursor", "boolean", desc="рисовать курсор", required=False, default=False)], C)
def _(ctx, x, y, width, height, include_cursor):
    if width <= 0 or height <= 0:
        return ToolResult(False, "width и height должны быть больше 0")
    return shoot("region", x=x, y=y, w=width, h=height, include_cursor=include_cursor)


@T("screen_capture_monitor", "Скриншот одного монитора (для мультимониторных конфигураций)",
   [P("monitor", "integer", desc="индекс из screen_monitors_list (0 = основной)",
      required=False, default=0)], C)
def _(ctx, monitor):
    return shoot("monitor", monitor=monitor)


@T("screen_monitors_list", "Список мониторов: индекс, имя устройства, разрешение, основной ли", [], C)
def _(ctx):
    if NT:
        mons = list_monitors()
        return "\n".join(f"#{m['index']} {m['device']} {m['rect'][2]}x{m['rect'][3]} "
                         f"@({m['rect'][0]},{m['rect'][1]}){' [основной]' if m['primary'] else ''}"
                         for m in mons) or "мониторы не найдены"
    if MAC:
        out = _sh(["system_profiler", "SPDisplaysDataType"], timeout=25)
        return out[:3000] or "нет данных"
    for tool in ("xrandr", "wlr-randr"):
        exe = _have(tool)
        if exe:
            return _sh([exe], timeout=15)[:3000]
    return ToolResult(False, "нет xrandr/wlr-randr")


@T("screen_windows_list", "Список окон, которые МОЖНО снять: HWND, заголовок, процесс, "
                          "геометрия, активно/свёрнуто. Нужен перед screen_capture_window.",
   [P("filter", desc="фильтр по подстроке (заголовок или процесс)", required=False, default=""),
    P("limit", "integer", desc="сколько показать", required=False, default=40)], C, core=True)
def _(ctx, filter, limit):
    if NT:
        wins = list_windows()
    elif MAC:
        out = _sh(["osascript", "-e", 'tell application "System Events" to get name of every '
                                      'process whose visible is true'], timeout=15)
        return out or "нет данных"
    else:
        exe = _have("wmctrl")
        out = _sh([exe, "-l", "-G"], timeout=15) if exe else ""
        if not out:
            xdo = _have("xdotool")
            if xdo:
                ids = _sh([xdo, "search", "--onlyvisible", "--name", ""], timeout=15).split()
                rows = []
                for i in ids[:80]:
                    rows.append(f"{i} | {_sh([xdo, 'getwindowname', i], timeout=5)}")
                out = "\n".join(rows)
        if filter:
            out = "\n".join(l for l in out.splitlines() if filter.lower() in l.lower())
        return out[:4000] or "окон не найдено"
    if filter:
        f = filter.lower()
        wins = [w for w in wins if f in w["title"].lower() or f in w["process"].lower()]
    rows = []
    for w in wins[: max(1, int(limit or 40))]:
        mark = " [АКТИВНО]" if w["foreground"] else (" [свёрнуто]" if w["minimized"] else "")
        rows.append(f"{w['hwnd']} | {w['process']:<22} | {w['rect'][2]}x{w['rect'][3]} "
                    f"@({w['rect'][0]},{w['rect'][1]}) | {w['title'][:70]}{mark}")
    return "\n".join(rows) or "окон не найдено"


@T("screen_active_window_screenshot", "Скриншот окна, которое сейчас в фокусе",
   [P("client_only", "boolean", desc="без рамки и заголовка", required=False, default=False),
    P("downscale", "integer", desc="уменьшить в N раз", required=False, default=1)], C)
def _(ctx, client_only, downscale):
    if NT:
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ToolResult(False, "нет активного окна")
        return shoot("window", hwnd=int(hwnd), client_only=client_only, downscale=downscale)
    if MAC:
        name = _sh(["osascript", "-e", 'tell application "System Events" to get name of first '
                                      'process whose frontmost is true'], timeout=15)
        return shoot("window", window=name.strip(), client_only=client_only, downscale=downscale)
    xdo = _have("xdotool")
    if xdo:
        wid = _sh([xdo, "getactivewindow"], timeout=10).strip()
        imp = _have("import")
        if wid and imp:
            path = _shot_path("active")
            _sh([imp, "-window", wid, path], timeout=25)
            if os.path.exists(path) and os.path.getsize(path) > 200:
                return _result(path, "активное окно", 0, 0, 1, {"backend": "imagemagick"})
    return shoot("screen", downscale=downscale)


@T("screen_capture_delayed", "Скриншот с задержкой (успеть открыть меню/тултип/контекстное меню)",
   [P("delay_s", "number", desc="сколько секунд подождать перед снимком (макс. 30)"),
    P("target", desc="screen|window|region|monitor", required=False, default="screen",
      enum=["screen", "window", "region", "monitor"]),
    P("window", desc="часть заголовка окна", required=False, default="")], C)
def _(ctx, delay_s, target, window):
    return shoot(target, window=window, delay=float(delay_s or 0))


@T("screen_capture_browser_tab",
   "Скриншот ОТДЕЛЬНОЙ ВКЛАДКИ браузера (Chrome/Edge) через CDP или расширение FLUX Bridge. "
   "Вкладка выбирается по id (browser_tabs_list), по части URL, по части заголовка, "
   "либо active=true для текущей. full_page=true снимает всю страницу с прокруткой.",
   [P("tab", desc="id вкладки / часть URL / часть заголовка", required=False, default=""),
    P("active", "boolean", desc="взять активную вкладку", required=False, default=False),
    P("full_page", "boolean", desc="снимать всю страницу (за пределами экрана)",
      required=False, default=False),
    P("format", desc="png|jpeg", required=False, default="png", enum=["png", "jpeg"]),
    P("quality", "integer", desc="качество для jpeg (1-100)", required=False, default=85)], C, core=True)
async def _(ctx, tab, active, full_page, format, quality):
    try:
        from .. import browserbus as bus
        from .. import browser_cdp as cdp
    except Exception as e:
        return ToolResult(False, f"браузерный модуль недоступен: {e}")

    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    try:
        targets = await bus.targets()
    except Exception as e:
        return ToolResult(False, f"не получил список вкладок: {e}")
    if not targets:
        return ToolResult(False, "вкладок нет")

    chosen = None
    if active:
        chosen = next((t for t in targets if t.get("active")), targets[0])
    elif str(tab).strip():
        key = str(tab).strip()
        for t in targets:                                   # точный id
            if str(t.get("id")) == key:
                chosen = t
                break
        if not chosen:
            kl = key.lower()
            hits = [t for t in targets
                    if kl in (t.get("title") or "").lower() or kl in (t.get("url") or "").lower()]
            if len(hits) == 1:
                chosen = hits[0]
            elif len(hits) > 1:
                lst = "\n".join(f"  {t['id']} | {(t.get('title') or '')[:50]} | "
                                f"{(t.get('url') or '')[:70]}" for t in hits[:12])
                return ToolResult(False, f"найдено несколько вкладок по «{key}» — уточни id:\n{lst}")
    if not chosen:
        return ToolResult(False, f"вкладка не найдена: {tab or '(не указана)'}\n"
                                 f"Список: " + "; ".join(f"{t['id']}={t.get('title', '')[:30]}"
                                                          for t in targets[:10]))

    tid = str(chosen.get("id"))
    params = {"format": format or "png", "fromSurface": True}
    if format == "jpeg":
        params["quality"] = max(1, min(100, int(quality or 85)))
    if full_page:
        params["captureBeyondViewport"] = True

    b64 = ""
    try:
        from .. import bridge
        if bridge.online():
            r = await bridge.call({"cmd": "cdp", "tabId": int(tid),
                                   "method": "Page.captureScreenshot", "params": params})
            b64 = (r or {}).get("data", "")
        else:
            ws = await bus._cdp_ws(tid)
            r = await cdp.cmd_target(ws, "Page.captureScreenshot", params, timeout=30)
            b64 = r.get("data", "")
    except Exception:
        b64 = ""
    if not b64:                                             # фолбэк без full_page
        try:
            b64 = await bus.screenshot_b64(tid)
        except Exception as e:
            return ToolResult(False, f"не смог снять вкладку: {type(e).__name__}: {e}")
    if not b64:
        return ToolResult(False, "вкладка вернула пустой кадр")

    ext = "jpg" if (format or "png") == "jpeg" else "png"
    path = os.path.join(SHOTS_DIR, f"tab_{int(time.time() * 1000)}.{ext}")
    os.makedirs(SHOTS_DIR, exist_ok=True)
    data = base64.b64decode(b64)
    with open(path, "wb") as f:
        f.write(data)
    return _result(path, f"вкладка «{(chosen.get('title') or '')[:60]}»",
                   0, 0, 1, {"backend": f"cdp/{bus.transport()}", "tab": tid,
                             "url": chosen.get("url", ""), "full_page": bool(full_page)})


@T("screen_capture_page_element",
   "Скриншот ЭЛЕМЕНТА страницы вкладки (по CSS-селектору) — клип по bounding box.",
   [P("tab", desc="id вкладки"), P("selector", desc="CSS-селектор элемента")], C)
async def _(ctx, tab, selector):
    import json as _json
    try:
        from .. import browserbus as bus
        from .. import browser_cdp as cdp
    except Exception as e:
        return ToolResult(False, f"браузерный модуль недоступен: {e}")
    if not await bus.ensure():
        return ToolResult(False, cdp.FRIENDLY_HINT)
    expr = ("""(() => { const el = document.querySelector(%s); if (!el) return null;
        el.scrollIntoView({block:'center'}); const r = el.getBoundingClientRect();
        return {x:r.x, y:r.y, width:r.width, height:r.height}; })()"""
            % _json.dumps(selector))
    try:
        box = await bus.evaluate(str(tab), expr)
    except Exception as e:
        return ToolResult(False, f"ошибка страницы: {e}")
    if not box:
        return ToolResult(False, f"селектор не найден: {selector}")
    params = {"format": "png", "clip": {**box, "scale": 1}, "fromSurface": True}
    b64 = ""
    try:
        from .. import bridge
        if bridge.online():
            r = await bridge.call({"cmd": "cdp", "tabId": int(tab),
                                   "method": "Page.captureScreenshot", "params": params})
            b64 = (r or {}).get("data", "")
        else:
            ws = await bus._cdp_ws(str(tab))
            r = await cdp.cmd_target(ws, "Page.captureScreenshot", params, timeout=30)
            b64 = r.get("data", "")
    except Exception as e:
        return ToolResult(False, f"не смог снять элемент: {type(e).__name__}: {e}")
    if not b64:
        return ToolResult(False, "пустой кадр элемента")
    path = os.path.join(SHOTS_DIR, f"el_{int(time.time() * 1000)}.png")
    os.makedirs(SHOTS_DIR, exist_ok=True)
    with open(path, "wb") as f:
        f.write(base64.b64decode(b64))
    return _result(path, f"элемент {selector}", int(box["width"]), int(box["height"]), 1,
                   {"backend": "cdp-clip", "tab": str(tab)})


@T("screen_info", "Диагностика подсистемы скриншотов: DPI-режим, мониторы, доступные бэкенды",
   [], C)
def _(ctx):
    info: dict = {"platform": sys.platform, "pil": bool(_PILImage)}
    if NT:
        info["dpi_mode"] = ensure_dpi_aware()
        info["monitors"] = list_monitors()
        vs = virtual_screen_rect()
        info["virtual_screen"] = {"x": vs[0], "y": vs[1], "w": vs[2], "h": vs[3]}
        info["windows"] = len(list_windows())
        info["backend"] = "win32-gdi (без PowerShell и без окна консоли)"
    else:
        info["backends"] = [t for t in ("scrot", "grim", "gnome-screenshot", "spectacle",
                                        "import", "screencapture", "xdotool", "wmctrl")
                            if shutil.which(t)]
    info["shots_dir"] = SHOTS_DIR
    import json as _json
    return _json.dumps(info, ensure_ascii=False, default=str)


# ============================================================== геометрия экрана
@T("screen_size", "Разрешение экрана / всей виртуальной рабочей области (все мониторы)", [], C)
def _(ctx):
    if NT:
        ensure_dpi_aware()
        vs = virtual_screen_rect()
        prim = (user32.GetSystemMetrics(0), user32.GetSystemMetrics(1))
        return (f"основной: {prim[0]}x{prim[1]}; виртуальный экран: {vs[2]}x{vs[3]} "
                f"@({vs[0]},{vs[1]}); мониторов: {len(list_monitors())}")
    try:
        import pyautogui
        return str(pyautogui.size())
    except Exception:
        pass
    if MAC:
        return _sh(["system_profiler", "SPDisplaysDataType"], timeout=20)[:800] or "?"
    for tool in ("xdotool", "wlr-randr", "xrandr"):
        exe = _have(tool)
        if not exe:
            continue
        if tool == "xdotool":
            return _sh([exe, "getdisplaygeometry"], timeout=10) or "?"
        out = _sh([exe], timeout=15)
        return out[:800] or "?"
    return ToolResult(False, "не удалось определить размер экрана")


@T("screen_pixel", "Цвет пикселя экрана в (x,y) — RGB и HEX (GetPixel / pyautogui.pixel)",
   [P("x", "integer", desc="x"), P("y", "integer", desc="y")], C)
def _(ctx, x, y):
    if NT:
        ensure_dpi_aware()
        hdc = user32.GetDC(None)
        if not hdc:
            return ToolResult(False, "GetDC вернул NULL")
        try:
            gdi32.GetPixel.restype = ctypes.wintypes.DWORD
            gdi32.GetPixel.argtypes = [ctypes.wintypes.HDC, ctypes.c_int, ctypes.c_int]
            v = gdi32.GetPixel(hdc, int(x), int(y))
        finally:
            user32.ReleaseDC(None, hdc)
        if v == 0xFFFFFFFF:
            return ToolResult(False, f"({x},{y}) вне экрана")
        r, g, b = v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF
        return f"({x},{y}) rgb=({r},{g},{b}) hex=#{r:02X}{g:02X}{b:02X}"
    try:
        import pyautogui
        return str(pyautogui.pixel(int(x), int(y)))
    except Exception:
        return ToolResult(False, "нужен pyautogui: pip install pyautogui")


# ============================================================== OCR
# Исправлено: путь к файлу передаётся как $a0 (winproc.ps_command), а НЕ через $args —
# в режиме `powershell -Command` переменная $args пуста, из-за чего OCR всегда падал.
_PS_OCR = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}
[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics,ContentType=WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($a0)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine = $null
if ($a1) { try { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language($a1))) } catch {} }
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
if (-not $engine) { Write-Output ''; exit 0 }
$ocr = Await ($engine.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
$ocr.Text
"""


@T("ocr_screen",
   "OCR: распознать текст с экрана (Windows.Media.Ocr WinRT, скрыто, без окна консоли; "
   "на других ОС — tesseract). source: screen=весь экран, window=окно, file=свой PNG/JPG.",
   [P("source", desc="screen|window|file", required=False, default="screen",
      enum=["screen", "window", "file"]),
    P("window", desc="часть заголовка окна (для source=window)", required=False, default=""),
    P("path", desc="путь к картинке (для source=file)", required=False, default=""),
    P("lang", desc="язык: ru-RU, en-US… (пусто = языки профиля)", required=False, default="ru-RU")],
   C, core=True)
def _(ctx, source, window, path, lang):
    src = path.strip() if (source or "screen") == "file" else ""
    if not src:
        res = shoot("window" if source == "window" else "screen", window=window, downscale=1)
        if not res.ok or not res.images:
            return res
        src = res.images[0]
    if not os.path.exists(src):
        return ToolResult(False, f"файл не найден: {src}")
    if NT:
        try:
            txt = winproc.ps(_PS_OCR, args=[os.path.abspath(src), lang or ""], timeout=45)
            if txt:
                return txt[:6000]
        except Exception:
            pass
    exe = _have("tesseract")
    if exe:
        argv = [exe, src, "stdout"]
        if lang:
            argv += ["-l", lang.split("-")[0]]
        out = _sh(argv, timeout=60)
        if out:
            return out[:6000]
    return ToolResult(False, "OCR недоступен: на Windows нужен Windows.Media.Ocr (есть в 10/11), "
                             "иначе установи tesseract")


@T("ocr_image", "OCR по файлу картинки (тот же движок, что и ocr_screen)",
   [P("path", desc="путь к PNG/JPG"),
    P("lang", desc="язык", required=False, default="ru-RU")], C)
def _(ctx, path, lang):
    return REG.tools["ocr_screen"].handler(ctx=ctx, source="file", window="", path=path, lang=lang)

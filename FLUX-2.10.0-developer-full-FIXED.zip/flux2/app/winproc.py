r"""Скрытый запуск дочерних процессов + безопасная передача аргументов в PowerShell.

Зачем отдельный модуль (это корень двух багов скриншота):

1) ВСПЛЫВАЮЩАЯ КОНСОЛЬ. `powershell.exe` — приложение GUI-подсистемы. Если родитель
   (FluxChat.exe / pywebview / pythonw.exe) создан БЕЗ консоли, Windows выделяет
   дочернему процессу собственную консоль -> чёрное окно мигает на весь экран.
   Лечится парой: `creationflags=CREATE_NO_WINDOW` + `STARTUPINFO(wShowWindow=SW_HIDE)`.
   Плюс `stdin=DEVNULL` и `-NonInteractive`, чтобы PS не завис в ожидании ввода.

2) `$args` НЕ РАБОТАЕТ с `-Command`. Старый код делал
       powershell -NoProfile -Command "<скрипт с $bmp.Save($args[0])>  'C:\path.png'"
   В режиме `-Command` автоматическая переменная `$args` пуста (она заполняется только
   для `-File`, скрипт-блоков и функций). Итог: `Save($null)` -> файл не создавался,
   тулз рапортовал «PowerShell не смог сохранить скриншот». Здесь аргументы ИНЛАЙНЯТСЯ
   в скрипт как PS-литералы в одинарных кавычках (`'` -> `''`), что заодно закрывает
   проблему путей с пробелами/кавычками/`$`/апострофами.

3) ЛОЖНЫЕ СРАБАТЫВАНИЯ АВ. `-EncodedCommand`, `-enc`, временные `.ps1` в %TEMP%,
   `IEX` и `DownloadString` — топ-сигнатуры эвристик. Поэтому: никаких encoded-команд
   и никаких временных скриптов; а там, где можно, PowerShell не используется вовсе
   (см. app/tools/screen.py — там чистый Win32 GDI через ctypes, ноль дочерних процессов).

Модуль кроссплатформенный: на Linux/macOS это тонкая обёртка над subprocess
(c `start_new_session=True`, чтобы сигнал Ctrl+C в терминале не убивал детей).
"""
from __future__ import annotations

import os
import subprocess
import sys
from typing import Any, Iterable, Optional, Sequence

NT = sys.platform == "win32"

# --- флаги CreateProcess ---------------------------------------------------
CREATE_NO_WINDOW = 0x08000000
DETACHED_PROCESS = 0x00000008
CREATE_NEW_PROCESS_GROUP = 0x00000200

STARTF_USESHOWWINDOW = 0x00000001
SW_HIDE = 0

# Полный путь к powershell.exe: обходим PATH и «App Execution Alias»-заглушки
# из WindowsApps, которые иногда резолвятся не туда и дают лишний процесс.
_PS_CANDIDATES = (
    r"{sys}\System32\WindowsPowerShell\v1.0\powershell.exe",
    r"{sys}\SysWOW64\WindowsPowerShell\v1.0\powershell.exe",
)


def powershell_exe() -> str:
    """Абсолютный путь к powershell.exe (или 'powershell', если не нашли)."""
    sysroot = os.environ.get("SystemRoot") or r"C:\Windows"
    for tpl in _PS_CANDIDATES:
        p = tpl.format(sys=sysroot)
        if os.path.exists(p):
            return p
    return "powershell"


def _startupinfo():
    """STARTUPINFO с принудительно скрытым окном (двойная страховка к CREATE_NO_WINDOW)."""
    if not NT:
        return None
    si = subprocess.STARTUPINFO()
    si.dwFlags |= STARTF_USESHOWWINDOW
    si.wShowWindow = SW_HIDE
    return si


def hidden_kwargs(argv_is_gui_app: bool = True, new_group: bool = False) -> dict:
    """Универсальные kwargs «без окна» для subprocess.run/Popen.

    argv_is_gui_app=True  — для powershell/wscript/cscript/mshta и т.п. (GUI-подсистема):
                            нужен именно CREATE_NO_WINDOW.
    argv_is_gui_app=False — для консольных exe (cmd, tasklist, git…): CREATE_NO_WINDOW
                            тоже работает, но добавляем DETACHED_PROCESS нельзя
                            (флаги взаимоисключающие), поэтому только NO_WINDOW.
    """
    if not NT:
        kw: dict[str, Any] = {"start_new_session": True}
        return kw
    flags = CREATE_NO_WINDOW
    if new_group:
        flags |= CREATE_NEW_PROCESS_GROUP
    return {"creationflags": flags, "startupinfo": _startupinfo()}


def run(argv: Sequence[str] | str, *, timeout: Optional[float] = 30,
        stdin_data: Optional[str] = None, shell: bool = False,
        cwd: Optional[str] = None, env: Optional[dict] = None,
        text: bool = True, new_group: bool = False, **extra) -> subprocess.CompletedProcess:
    """subprocess.run, который НИКОГДА не показывает окно консоли."""
    kw = hidden_kwargs(new_group=new_group)
    kw.update(extra)
    if stdin_data is None:
        kw.setdefault("stdin", subprocess.DEVNULL)
    return subprocess.run(argv, capture_output=True, text=text, timeout=timeout,
                          shell=shell, cwd=cwd, env=env, input=stdin_data, **kw)


def popen(argv: Sequence[str] | str, *, shell: bool = False, detach: bool = False,
          cwd: Optional[str] = None, env: Optional[dict] = None,
          new_group: bool = False, **extra) -> subprocess.Popen:
    """subprocess.Popen без окна. detach=True — процесс переживает смерть FLUX."""
    if detach and NT:
        kw: dict[str, Any] = {"creationflags": DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                              "startupinfo": _startupinfo(),
                              "stdin": subprocess.DEVNULL,
                              "stdout": subprocess.DEVNULL,
                              "stderr": subprocess.DEVNULL,
                              "close_fds": True}
    elif detach:
        kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL,
              "stderr": subprocess.DEVNULL, "start_new_session": True, "close_fds": True}
    else:
        kw = hidden_kwargs(new_group=new_group)
        kw.setdefault("stdin", subprocess.DEVNULL)
        kw.setdefault("stdout", subprocess.DEVNULL)
        kw.setdefault("stderr", subprocess.DEVNULL)
    kw.update(extra)
    return subprocess.Popen(argv, shell=shell, cwd=cwd, env=env, **kw)


# ----------------------------------------------------------------- PowerShell
def ps_quote(value: Any) -> str:
    """Значение -> безопасный PS-литерал в одинарных кавычках.

    В одинарных кавычках PowerShell не раскрывает `$var`, backtick и не трогает
    спецсимволы; единственное, что нужно удваивать, — сам апостроф.
    """
    if value is None:
        return "$null"
    if isinstance(value, bool):
        return "$true" if value else "$false"
    if isinstance(value, (int, float)):
        return repr(value)
    return "'" + str(value).replace("'", "''") + "'"


def ps_command(script: str, args: Iterable[Any] = ()) -> str:
    """Скрипт + аргументы -> одна строка для `-Command`.

    Аргументы объявляются в начале как `$a0, $a1, ...`, поэтому внутри скрипта
    НЕЛЬЗЯ полагаться на `$args` (см. докстринг модуля). Это же делает подстановку
    значений проверяемой: они проходят через ps_quote.
    """
    args = list(args)
    head = "".join(f"$a{i}={ps_quote(v)}; " for i, v in enumerate(args))
    return head + script


def ps(script: str, args: Iterable[Any] = (), timeout: float = 25.0,
       noninteractive: bool = True) -> str:
    """Выполнить PowerShell-скрипт СКРЫТО и вернуть stdout (или stderr при неудаче)."""
    if not NT:
        return ""
    argv = [powershell_exe(), "-NoProfile", "-ExecutionPolicy", "Bypass"]
    if noninteractive:
        argv.append("-NonInteractive")
    argv += ["-Command", ps_command(script, args)]
    try:
        r = run(argv, timeout=timeout)
    except subprocess.TimeoutExpired:
        return ""
    except Exception:
        return ""
    out = (r.stdout or "").strip()
    if r.returncode != 0 and not out:
        out = (r.stderr or "").strip()
    return out


def ps_ok(script: str, args: Iterable[Any] = (), timeout: float = 25.0) -> bool:
    """То же, что ps(), но возвращает успех/неуспех (по коду выхода)."""
    if not NT:
        return False
    argv = [powershell_exe(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-Command", ps_command(script, args) + "; exit 0"]
    try:
        r = run(argv, timeout=timeout)
        return r.returncode == 0
    except Exception:
        return False


def tasklist(image: str = "") -> str:
    """Скрытый tasklist (проверка «жив ли процесс»)."""
    argv = ["tasklist", "/NH", "/FO", "CSV"]
    if image:
        argv += ["/FI", f"IMAGENAME eq {image}"]
    try:
        return (run(argv, timeout=15).stdout or "").strip()
    except Exception:
        return ""


def has_process(image: str) -> bool:
    return image.lower() in tasklist(image).lower()


def kill_pid(pid: int, timeout: float = 10.0) -> bool:
    try:
        r = run(["taskkill", "/PID", str(int(pid)), "/T", "/F"], timeout=timeout)
        return r.returncode == 0
    except Exception:
        return False


def kill_image(image: str, timeout: float = 10.0) -> bool:
    try:
        r = run(["taskkill", "/IM", image, "/T", "/F"], timeout=timeout)
        return r.returncode == 0
    except Exception:
        return False


def start_hidden(cmd: str, cwd: Optional[str] = None) -> bool:
    """Запустить команду/URL так, чтобы не мелькнуло окно (ShellExecute через rundll32
    не нужен: на Windows используем os.startfile, он не создаёт консоль)."""
    try:
        if NT:
            os.startfile(cmd)  # type: ignore[attr-defined]
            return True
        if sys.platform == "darwin":
            popen(["open", cmd], detach=True)
            return True
        popen(["xdg-open", cmd], detach=True)
        return True
    except Exception:
        return False

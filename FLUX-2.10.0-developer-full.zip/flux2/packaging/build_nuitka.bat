@echo off
chcp 65001 >nul
rem ============================================================================
rem  FLUX 2.0 - Nuitka build (Windows x64)
rem
rem  Why Nuitka and not PyInstaller:
rem   - IP protection: Python is compiled to C and then to a NATIVE exe. There is
rem     no .pyc bundle to unpack with pyinstxtractor, no bytecode to decompile
rem     with uncompyle/decompyle. This protects the code far better than bytecode
rem     obfuscators do.
rem   - Fewer false positives: AV heuristics flag PyInstaller onefile bundles
rem     (self-extracting to %%TEMP%%, UPX-packed sections, embedded zlib blobs).
rem     A plain compiled exe with valid VERSIONINFO and a real Authenticode
rem     signature is treated as ordinary software.
rem
rem  Requirements:  pip install nuitka ordered-set zstandard
rem  A C compiler is needed; Nuitka downloads MinGW-w64 automatically on first run.
rem ============================================================================
setlocal
cd /d "%~dp0.."

set VER=2.9.0
set COMPANY=aerotitbit
set PRODUCT=FLUX 2.0 Desktop
set DESC=FLUX 2.0 - desktop AI assistant
set COPYRIGHT=Copyright (C) 2026 aerotitbit. All rights reserved.

where python >nul 2>nul || (echo [FLUX2] python not found & exit /b 1)
python -c "import nuitka" >nul 2>nul || (
  echo [FLUX2] Installing Nuitka...
  python -m pip install --quiet nuitka ordered-set zstandard || exit /b 1
)

set COMMON=--standalone --assume-yes-for-downloads --remove-output ^
  --company-name="%COMPANY%" --product-name="%PRODUCT%" --file-version=%VER% ^
  --product-version=%VER% --file-description="%DESC%" --copyright="%COPYRIGHT%" ^
  --include-data-dir=ui=ui --include-data-dir=skills_bundled=skills_bundled ^
  --include-package=app --include-package=app.tools ^
  --nofollow-import-to=license_server ^
  --nofollow-import-to=tests ^
  --enable-plugin=multiprocessing ^
  --windows-console-mode=disable ^
  --windows-uac-uiaccess=false

echo.
echo [FLUX2] Building FluxChat.exe (windowed)...
python -m nuitka %COMMON% ^
  --output-filename=FluxChat.exe ^
  --windows-icon-from-ico=ui\flux.ico ^
  main.py
if errorlevel 1 (echo [FLUX2] FluxChat build FAILED & exit /b 1)

echo.
echo [FLUX2] Building FluxConsole.exe (with console)...
python -m nuitka %COMMON% ^
  --output-filename=FluxConsole.exe ^
  --windows-console-mode=force ^
  --windows-icon-from-ico=ui\flux.ico ^
  main.py
if errorlevel 1 (echo [FLUX2] FluxConsole build FAILED & exit /b 1)

echo.
echo [FLUX2] Done:
echo   main.build\FluxChat.dist\FluxChat.exe
echo   main.build\FluxConsole.dist\FluxConsole.exe
echo.
echo [FLUX2] Next: sign both exe files (packaging\sign.py) - an unsigned exe
echo         triggers SmartScreen and AV heuristics much more often.
endlocal
exit /b 0

# -*- coding: utf-8 -*-
"""Метаданные версии (VERSIONINFO) для сборки FLUX 2.0.

Используется PyInstaller (`--version-file packaging/version_info.py`) и дублируется
в `packaging/build_nuitka.bat` через --company-name/--product-name и т.д.

ЗАЧЕМ ЭТО НУЖНО ДЛЯ ЛОЖНЫХ СРАБАТЫВАНИЙ.
Антивирусные эвристики смотрят не только на код, но и на метаданные: файл без
VERSIONINFO, без ProductName и без LegalCopyright — «подозрительный по умолчанию».
Заполненные метаданные официального разработчика (aerotitbit) + настоящая подпись
Authenticode снижают срабатывания сильнее, чем любая обфускация (которая, наоборот,
их провоцирует).

ВАЖНО: это ШАБЛОН. Замени значения под свой реальный юридический статус:
  * CompanyName / LegalCopyright — как в сертификате кодевой подписи. Несоответствие
    имени в сертификате и в метаданных — отдельный триггер для SmartScreen.
  * OriginalFilename — должно совпадать с именем собираемого exe.
  * ProductVersion/FileVersion — держи в синхроне с app/__init__.py (__version__).
"""
from __future__ import annotations

APP_VERSION = "2.9.0"
APP_VERSION_TUPLE = (2, 9, 0, 0)
COMPANY = "aerotitbit"
PRODUCT = "FLUX 2.0 Desktop"
DESCRIPTION = "FLUX 2.0 — десктопный ИИ-ассистент"
COPYRIGHT = f"Copyright (C) 2026 {COMPANY}. All rights reserved."
TRADEMARKS = "FLUX is a trademark of aerotitbit"

VSVersionInfo(                                   # noqa: F821  (имя подставляет PyInstaller)
  ffi=FixedFileInfo(                            # noqa: F821
    filevers=APP_VERSION_TUPLE,
    prodvers=APP_VERSION_TUPLE,
    mask=0x3F,
    flags=0x0,
    OS=0x40004,          # VOS_NT_WINDOWS32
    fileType=0x1,        # VFT_APP
    subtype=0x0,
    date=(0, 0),
  ),
  kids=[
    StringFileInfo(                             # noqa: F821
      [
        StringTable(                            # noqa: F821
          "040904B0",   # en-US, Unicode
          [
            StringStruct("CompanyName", COMPANY),
            StringStruct("FileDescription", DESCRIPTION),
            StringStruct("FileVersion", APP_VERSION),
            StringStruct("InternalName", "FluxChat"),
            StringStruct("LegalCopyright", COPYRIGHT),
            StringStruct("LegalTrademarks", TRADEMARKS),
            StringStruct("OriginalFilename", "FluxChat.exe"),
            StringStruct("ProductName", PRODUCT),
            StringStruct("ProductVersion", APP_VERSION),
            StringStruct("Comments", "Build: release"),
          ],
        ),
        StringTable(                            # noqa: F821
          "041904B0",   # ru-RU, Unicode
          [
            StringStruct("CompanyName", COMPANY),
            StringStruct("FileDescription", DESCRIPTION),
            StringStruct("FileVersion", APP_VERSION),
            StringStruct("LegalCopyright", COPYRIGHT),
            StringStruct("ProductName", PRODUCT),
            StringStruct("ProductVersion", APP_VERSION),
          ],
        ),
      ]
    ),
    VarFileInfo([VarStruct("Translation", [1033, 1200, 1049, 1200])]),   # noqa: F821
  ],
)

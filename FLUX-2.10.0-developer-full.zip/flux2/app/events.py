"""Глобальная шина событий FLUX.

Зачем: таймер срабатывает в фоновом потоке, а показать уведомление/проиграть звук
нужно в UI (окно чата = SSE-клиент). Раньше события жили только внутри
`agent.run_turn()` (одноразовый SSE-ответ на одно сообщение), поэтому о сработавшем
таймере никто не узнавал, пока пользователь сам не напишет в чат.

Теперь:
  * любой поток может сделать `events.publish({...})` — безопасно (call_soon_threadsafe);
  * сервер отдаёт `GET /api/events` — бесконечный SSE-поток ВСЕХ глобальных событий;
  * последние N событий хранятся в кольце, чтобы новый клиент сразу получил состояние
    (активные таймеры, непросроченные уведомления).
"""
from __future__ import annotations

import asyncio
import collections
import itertools
import json
import time
from typing import Any, Optional

_seq = itertools.count(1)


class EventBus:
    def __init__(self, ring_size: int = 256):
        self._subs: set[asyncio.Queue] = set()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._ring: collections.deque[dict] = collections.deque(maxlen=ring_size)

    # --- привязка к event loop сервера ------------------------------------
    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def bind_current(self) -> None:
        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = None

    # --- публикация --------------------------------------------------------
    def publish(self, ev: dict) -> dict:
        """Потокобезопасная публикация. Можно звать из любого потока.

        Служебный порядковый номер кладётся в `seq`, а НЕ в `id`: у событий
        таймеров `id` — это идентификатор самого таймера, и setdefault оставил бы
        его как есть, сломав нумерацию потока.
        """
        ev = dict(ev)
        ev["seq"] = next(_seq)
        ev.setdefault("ts", time.time())
        self._ring.append(ev)
        loop = self._loop
        if loop is not None and not loop.is_closed():
            try:
                loop.call_soon_threadsafe(self._fanout, ev)
            except RuntimeError:
                pass
        else:
            self._fanout(ev)
        return ev

    def _fanout(self, ev: dict) -> None:
        dead = []
        for q in list(self._subs):
            try:
                q.put_nowait(ev)
            except asyncio.QueueFull:
                dead.append(q)
            except RuntimeError:
                dead.append(q)
        for q in dead:
            self._subs.discard(q)

    # --- подписка ----------------------------------------------------------
    async def subscribe(self, replay: int = 0, maxsize: int = 512) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subs.add(q)
        self.bind_current()
        if replay:
            for ev in list(self._ring)[-replay:]:
                try:
                    q.put_nowait(ev)
                except asyncio.QueueFull:
                    break
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subs.discard(q)

    def recent(self, n: int = 20) -> list[dict]:
        return list(self._ring)[-n:]

    @property
    def subscribers(self) -> int:
        return len(self._subs)


EVENTS = EventBus()


def publish(kind: Any, **kw: Any) -> dict:
    """Публикация события. Принимаются ОБЕ формы записи:

        events.publish({"type": "timer_fired", "id": "t1"})   # готовый словарь
        events.publish("timer_fired", id="t1", label="чай")   # kind + kwargs

    Раньше поддерживалась только вторая, а весь остальной код звал первую —
    в итоге словарь уезжал в поле `type` и получалось {"type": {...всё событие...}},
    то есть клиент не мог разобрать ни одно событие таймера.
    """
    if isinstance(kind, dict):
        if kw:
            kind = {**kind, **kw}
        return EVENTS.publish(kind)
    return EVENTS.publish({"type": kind, **kw})


def sse_line(ev: dict) -> bytes:
    return ("data: " + json.dumps(ev, ensure_ascii=False, default=str) + "\n\n").encode("utf-8")

"""Память/заметки/todo/kv — простое JSON-хранилище.

Таймеров здесь больше нет: они переехали в app/timers.py (фоновый планировщик,
звук, события в UI) — см. комментарий в конце класса.
"""
from __future__ import annotations

import json
import os
import time
import uuid

from .config import app_dir


class MemoryStore:
    def __init__(self):
        self.path = os.path.join(app_dir(), "data", "memory.json")
        self.d = {"memories": [], "notes": [], "todos": [], "kv": {}, "timers": []}
        self.load()

    def load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    self.d.update(json.load(f))
            except Exception:
                pass

    def save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    # memories
    def add_memory(self, fact: str, tag: str = "general") -> str:
        mid = uuid.uuid4().hex[:8]
        self.d["memories"].append({"id": mid, "text": fact, "tag": tag, "ts": time.time()})
        self.save()
        return mid

    def memories(self):
        return self.d["memories"]

    def recall(self, query: str, k: int = 6):
        toks = set(query.lower().split())
        scored = []
        for m in self.d["memories"]:
            mt = set(m["text"].lower().split()) | {m.get("tag", "")}
            s = len(toks & mt)
            scored.append((s, m))
        scored.sort(key=lambda x: -x[0])
        return [m for s, m in scored[:k] if s > 0] or self.d["memories"][-k:]

    def forget(self, mid: str) -> bool:
        before = len(self.d["memories"])
        self.d["memories"] = [m for m in self.d["memories"] if m["id"] != mid]
        self.save()
        return len(self.d["memories"]) != before

    # notes
    def add_note(self, title: str, body: str) -> str:
        nid = uuid.uuid4().hex[:8]
        self.d["notes"].append({"id": nid, "title": title, "body": body, "ts": time.time()})
        self.save()
        return nid

    def notes(self):
        return self.d["notes"]

    def get_note(self, nid: str):
        return next((n for n in self.d["notes"] if n["id"] == nid), None)

    def delete_note(self, nid: str) -> bool:
        before = len(self.d["notes"])
        self.d["notes"] = [n for n in self.d["notes"] if n["id"] != nid]
        self.save()
        return len(self.d["notes"]) != before

    # todos
    def todo_add(self, text: str) -> str:
        tid = uuid.uuid4().hex[:8]
        self.d["todos"].append({"id": tid, "text": text, "done": False})
        self.save()
        return tid

    def todos(self):
        return self.d["todos"]

    def todo_done(self, tid: str) -> bool:
        for t in self.d["todos"]:
            if t["id"] == tid:
                t["done"] = True
                self.save()
                return True
        return False

    def todo_remove(self, tid: str) -> bool:
        before = len(self.d["todos"])
        self.d["todos"] = [t for t in self.d["todos"] if t["id"] != tid]
        self.save()
        return len(self.d["todos"]) != before

    # kv
    def kv_set(self, k, v):
        self.d["kv"][k] = v
        self.save()

    def kv_get(self, k):
        return self.d["kv"].get(k)

    def kv_delete(self, k) -> bool:
        if k in self.d["kv"]:
            del self.d["kv"][k]
            self.save()
            return True
        return False

    def kv_keys(self):
        return list(self.d["kv"])

    # timers
    # УДАЛЕНО НАМЕРЕННО. Таймеры больше не живут в memory.json: ими владеет
    # app/timers.py (отдельный файл data/timers.json + фоновый планировщик).
    # Прежняя схема проверяла дедлайны только в начале хода чата, из-за чего
    # таймер «не срабатывал», а запись в общий JSON без блокировки терялась.
    # Ключ "timers" в memory.json остаётся только для совместимости со старыми данными.


MEM = MemoryStore()

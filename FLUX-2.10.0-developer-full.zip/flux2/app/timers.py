"""Планировщик таймеров FLUX — фоновый поток + звук + события в UI.

ПОЧЕМУ СТАРЫЙ ТАЙМЕР НЕ СРАБАТЫВАЛ (разбор по коду):
  1. Проверка `MEM.timers_due()` вызывалась ТОЛЬКО внутри `agent.run_turn()`,
     то есть лишь в момент, когда пользователь сам отправляет сообщение.
     «Поставь таймер на 10 минут» -> тишина: никто не тикал между ходами чата.
  2. Даже если ход случался, сработавший таймер попадал только в системный промпт
     модели («СРАБОТАВШИЕ ТАЙМЕРЫ: …»). Ни звука, ни тоста, ни события в UI —
     пользователь мог вообще ничего не увидеть.
  3. `timer_set(seconds: int)` принимал только целые секунды. Модель регулярно
     отдаёт строку ("300"), дробное (0.5) или человекочитаемое ("5 минут") ->
     `time.time() + seconds` падал с TypeError, и тулз возвращал ошибку.
  4. Хранилище было общим с памятью (memory.json) и писалось без блокировки из
     разных потоков -> гонка и потеря записей.
  5. Не было абсолютного времени («в 14:30»), повторов («каждые 5 минут»),
     snooze и восстановления после перезапуска приложения.

ЧТО ЗДЕСЬ:
  * отдельный daemon-поток с тиком 100 мс и `Event.wait()` — будится мгновенно
    при создании таймера, в простое не грузит CPU;
  * собственный файл `data/timers.json`, атомарная запись, `RLock`;
  * `parse_when()` понимает «300», «5 минут», «1ч30м», «14:30», «завтра 9:00»,
    «в пятницу 18:00», «каждые 10 минут»;
  * при срабатывании: звук (app.notify) + тост + событие в шину (UI рисует плашку
    и дублирует звук через Web Audio) + очередь `unacked` для следующего хода агента;
  * восстановление после рестарта: просроченные < `stale_after` с firing'аются сразу,
    более старые помечаются пропущенными (без громкой сирены среди ночи);
  * повторяющиеся таймеры считаются без накопления дрейфа (due += interval).
"""
from __future__ import annotations

import datetime as dtm
import json
import os
import re
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

from . import events, notify
from .config import app_dir

TICK = 0.1                 # период тика планировщика, с
MAX_SLEEP = 0.25           # потолок сна: даже при сбое расчёта опоздание < 0.25 с
DEFAULT_STALE = 3600.0     # старше этого просроченный таймер считается «пропущенным»
MAX_TIMERS = 500

STATE_ARMED = "armed"
STATE_PAUSED = "paused"
STATE_DONE = "done"
STATE_CANCELLED = "cancelled"


# ============================================================== парсер времени
# ВАЖНО про `\b`: в «1ч30м» после «ч» идёт цифра, а цифра — тоже \w, поэтому
# граница слова НЕ срабатывает и наивный `ч\b` такую запись не увидит.
# Используем «дальше не буква»: (?![а-яёa-z]) — тогда «1ч30м» = 1 ч + 30 мин.
_UNITS = [
    (r"мс(?![а-яёa-z])|мсек\w*|миллисекунд\w*|ms(?![a-z])", 0.001),
    (r"секунд\w*|сек\.?|с(?![а-яёa-z])|seconds?(?![a-z])|secs?(?![a-z])", 1.0),
    (r"минут\w*|мин\.?|м(?![а-яёa-z])|minutes?(?![a-z])|mins?(?![a-z])|m(?![a-z])", 60.0),
    (r"час\w*|ч(?![а-яёa-z])|hours?(?![a-z])|hrs?(?![a-z])|h(?![a-z])", 3600.0),
    (r"дней|дня|дн\.?|день|дн(?![а-яёa-z])|д(?![а-яёa-z])|days?(?![a-z])|d(?![a-z])", 86400.0),
    (r"недел\w*|нед\.?|weeks?(?![a-z])|w(?![a-z])", 604800.0),
]
_UNIT_RE = "|".join(f"(?P<u{i}>{p})" for i, (p, _) in enumerate(_UNITS))
_UNIT_MULT = {f"u{i}": m for i, (_, m) in enumerate(_UNITS)}
_DUR_RE = re.compile(rf"(\d+(?:[.,]\d+)?)\s*(?:{_UNIT_RE})", re.IGNORECASE | re.UNICODE)

# Идиомы без числительных — проверяются до числового разбора
_IDIOMS = {
    "полчаса": 1800.0, "пол-часа": 1800.0, "полминуты": 30.0,
    "полторы минуты": 90.0, "полторыминуты": 90.0,
    "четверть часа": 900.0, "минутку": 60.0, "минуту": 60.0,
    "секунду": 1.0, "секундочку": 1.0, "час": 3600.0,
    "half an hour": 1800.0, "a minute": 60.0, "an hour": 3600.0,
}

_WEEKDAYS = {
    "пн": 0, "понедельник": 0, "mon": 0, "monday": 0,
    "вт": 1, "вторник": 1, "tue": 1, "tues": 1, "tuesday": 1,
    "ср": 2, "среда": 2, "среде": 2, "wed": 2, "wednesday": 2,
    "чт": 3, "четверг": 3, "thu": 3, "thur": 3, "thursday": 3,
    "пт": 4, "пятница": 4, "пятницу": 4, "fri": 4, "friday": 4,
    "сб": 5, "суббота": 5, "субботу": 5, "sat": 5, "saturday": 5,
    "вс": 6, "воскресенье": 6, "воскресению": 6, "sun": 6, "sunday": 6,
}
_DAYPART = {"утра": 0, "ночи": 0, "дня": 12, "вечера": 12, "am": 0, "pm": 12}


@dataclass
class When:
    """Результат разбора «когда»."""
    ok: bool = False
    delay: Optional[float] = None        # секунд от сейчас (относительное)
    at: Optional[float] = None           # epoch (абсолютное)
    interval: Optional[float] = None     # секунд (повтор)
    repeats: int = 0                     # 0 = бесконечно, N = ровно N раз
    text: str = ""                       # человекочитаемое описание
    error: str = ""

    def resolve(self, now: Optional[float] = None) -> float:
        """Момент первого срабатывания (epoch)."""
        now = time.time() if now is None else now
        if self.at is not None:
            return self.at
        if self.interval is not None:
            return now + self.interval
        if self.delay is not None:
            return now + self.delay
        raise ValueError(self.error or "не удалось определить время")

    def describe(self, now: Optional[float] = None) -> str:
        if self.text:
            return self.text
        now = time.time() if now is None else now
        try:
            due = self.resolve(now)
        except Exception:
            return "?"
        return f"через {humanize(due - now)} ({dtm.datetime.fromtimestamp(due):%d.%m.%Y %H:%M:%S})"


def humanize(seconds: float) -> str:
    s = int(round(seconds))
    if s < 0:
        return f"просрочен на {humanize(-s)}"
    if s < 60:
        return f"{s} с"
    m, sec = divmod(s, 60)
    if m < 60:
        return f"{m} мин" + (f" {sec} с" if sec else "")
    h, m = divmod(m, 60)
    if h < 24:
        return f"{h} ч" + (f" {m} мин" if m else "")
    d, h = divmod(h, 24)
    return f"{d} дн" + (f" {h} ч" if h else "")


def _dur_spans(text: str) -> list[tuple[int, int, float]]:
    """Все найденные «N единиц» вместе с их позициями в строке."""
    out = []
    for m in _DUR_RE.finditer(text):
        mult = None
        for gname, gm in _UNIT_MULT.items():
            if m.group(gname):
                mult = gm
                break
        if mult is None:
            continue
        out.append((m.start(), m.end(), float(m.group(1).replace(",", ".")) * mult))
    return out


def _dur_from_matches(text: str) -> Optional[float]:
    spans = _dur_spans(text)
    return sum(s[2] for s in spans) if spans else None


def _covered(pos: int, spans: list[tuple[int, int, float]]) -> bool:
    return any(a <= pos < b for a, b, _ in spans)


def _time_of_day(text: str, dur_spans: Optional[list] = None) -> Optional[tuple[int, int, int]]:
    """Ищет HH:MM / HH:MM:SS / «в 9 вечера» -> (h, m, s).

    `dur_spans` — позиции уже распознанных длительностей. Нужно, чтобы «3 дня»
    не превращалось в «в 3 дня» (=15:00): слово «дня» одновременно и единица
    измерения, и часть суток, поэтому при конфликте приоритет у длительности.
    """
    spans = dur_spans or []
    m = re.search(r"\b(\d{1,2}):(\d{2})(?::(\d{2}))?\b", text)
    if m:
        h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
        if h <= 23 and mi <= 59 and s <= 59:
            return h, mi, s
        return None
    for pat, dpart in ((r"\b(?:в\s+)?(\d{1,2})\s*(?:час(?:ов|а|)?\b)?\s*(утра|ночи|дня|вечера|am|pm)\b", 2),
                       (r"\b(\d{1,2})\s*:\s*(\d{1,2})\s*(утра|ночи|дня|вечера|am|pm)\b", 3)):
        m = re.search(pat, text, re.IGNORECASE)
        if not m:
            continue
        if _covered(m.start(dpart), spans):      # «3 дня» — это длительность, не 15:00
            continue
        h = int(m.group(1)) % 24 + _DAYPART[m.group(dpart).lower()]
        mi = int(m.group(2)) % 60 if dpart == 3 else 0
        return h % 24, mi, 0
    return None


def _absolute_date(text: str) -> Optional[dtm.date]:
    low = text.lower()
    today = dtm.date.today()
    if "послезавтра" in low:
        return today + dtm.timedelta(days=2)
    if "завтра" in low or "tomorrow" in low:
        return today + dtm.timedelta(days=1)
    if "сегодня" in low or "today" in low:
        return today
    m = re.search(r"\b(\d{4}-\d{2}-\d{2}|\d{2}\.\d{2}\.\d{2,4}|\d{2}/\d{2}/\d{4})\b", text)
    if m:
        token = m.group(1)
        for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%d/%m/%Y"):
            try:
                return dtm.datetime.strptime(token, fmt).date()
            except ValueError:
                continue
    # Только ОТДЕЛЬНЫМ словом: иначе «всё» совпало бы с «вс» (воскресенье).
    for name, wd in _WEEKDAYS.items():
        if len(name) < 2:
            continue
        if re.search(rf"(?<![\w]){re.escape(name)}(?![\w])", low):
            return today + dtm.timedelta(days=((wd - today.weekday()) % 7) or 7)
    return None


def _idiom(text: str) -> Optional[float]:
    low = text.lower()
    for phrase, sec in sorted(_IDIOMS.items(), key=lambda kv: -len(kv[0])):
        if phrase in low:
            return sec
    return None


def parse_when(value: Any, *, now: Optional[float] = None) -> When:
    """Разобрать «когда сработать»: число, длительность, момент или интервал.

    Поддерживается:
      300 | "300" | "300с" | "5 минут" | "5м" | "1ч30м" | "1h30m" | "90 sec"
      "14:30" | "в 9 вечера" | "завтра 9:00" | "в пятницу 18:00" | "2026-10-13 09:00"
      "каждые 10 минут" | "every 5m" | "1:30:00" (длительность ч:м:с)
      "через 10 минут", "in 10 minutes"
    Соглашение по «H:MM»: две части = ВРЕМЯ ДНЯ (10:30 -> сегодня в 10:30),
    три части (1:30:00) = длительность. Иначе «напомни в 10:30» превращалось бы
    в таймер на 10 с половиной часов.
    """
    now = time.time() if now is None else now

    # --- 1) просто число -> секунды ---------------------------------------
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if value <= 0:
            return When(error="задержка должна быть больше 0")
        return When(ok=True, delay=float(value), text=f"через {humanize(value)}")
    if value is None:
        return When(error="пусто")
    raw = str(value).strip()
    if not raw:
        return When(error="пусто")
    low = raw.lower()

    # --- 2) повтор: «каждые X» / «every X» ---------------------------------
    repeat_mode = bool(re.search(r"\b(каждые|каждый|every|повтор\w*|интервал)\b", low))
    mrep = re.search(r"\b(\d+)\s*(?:раз\w*|times?|повтор\w*)\b", low)
    repeats = int(mrep.group(1)) if mrep else 0

    cleaned = re.sub(r"\b(через|in|after|каждые|каждый|every|повтор\w*|интервал|"
                     r"напомни(?:ть|те)?|напоминание|таймер|timer|remind(?:\s+me)?|"
                     r"поставь|установи|set)\b", " ", low)

    # --- 3) чистое число в строке -> секунды -------------------------------
    if re.fullmatch(r"\d+(?:[.,]\d+)?", cleaned.strip()):
        sec = float(cleaned.replace(",", "."))
        if sec <= 0:
            return When(error="задержка должна быть больше 0")
        if repeat_mode:
            return When(ok=True, interval=sec, repeats=repeats,
                        text=f"каждые {humanize(sec)}" + (f", {repeats} раз" if repeats else ""))
        return When(ok=True, delay=sec, text=f"через {humanize(sec)}")

    # --- 4) H:MM:SS -> длительность; H:MM -> время дня ---------------------
    m3 = re.search(r"\b(\d{1,2}):(\d{2}):(\d{2})\b", cleaned)
    if m3 and not repeat_mode:
        sec = int(m3.group(1)) * 3600 + int(m3.group(2)) * 60 + int(m3.group(3))
        if sec > 0:
            return When(ok=True, delay=float(sec), text=f"через {humanize(sec)}")

    spans = _dur_spans(cleaned)
    dur = sum(s[2] for s in spans) if spans else None
    if dur is None:
        dur = _idiom(cleaned)
    tod = _time_of_day(cleaned, spans)
    date = _absolute_date(low)

    # --- 5) длительность (+ возможный повтор) ------------------------------
    if dur is not None and dur > 0 and tod is None and date is None:
        if repeat_mode:
            return When(ok=True, interval=dur, repeats=repeats,
                        text=f"каждые {humanize(dur)}" + (f", {repeats} раз" if repeats else ""))
        return When(ok=True, delay=dur, text=f"через {humanize(dur)}")

    # --- 6) длительность + абсолютная дата: «завтра через 2 часа» -----------
    if dur is not None and dur > 0 and date is not None and tod is None:
        anchor = dtm.datetime.combine(date, dtm.time(0, 0)).timestamp()
        at = max(anchor + dur, now + 0.05)
        return When(ok=True, at=at, text=f"{dtm.datetime.fromtimestamp(at):%d.%m.%Y %H:%M}")

    # --- 7) время дня (+ дата/день недели) ---------------------------------
    if tod is not None:
        h, mi, s = tod
        d = date or dtm.date.today()
        target = dtm.datetime.combine(d, dtm.time(h, mi, s))
        if date is None and target.timestamp() <= now:
            target += dtm.timedelta(days=1)          # «в 14:30» уже прошло -> завтра
        at = target.timestamp()
        if repeat_mode:
            return When(ok=True, at=at, interval=86400.0, repeats=repeats,
                        text=f"ежедневно в {h:02d}:{mi:02d}")
        return When(ok=True, at=at, text=f"{target:%d.%m.%Y %H:%M}")

    # --- 7b) только дата: «завтра» -> 09:00 указанного дня ------------------
    if date is not None:
        target = dtm.datetime.combine(date, dtm.time(9, 0))
        at = target.timestamp()
        if at <= now:
            at += 60.0
        return When(ok=True, at=at, text=f"{dtm.datetime.fromtimestamp(at):%d.%m.%Y %H:%M}")

    # --- 8) ISO-дата без времени -------------------------------------------
    m = re.search(r"\b(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?)\b", raw)
    if m:
        try:
            at = dtm.datetime.fromisoformat(m.group(1)).timestamp()
            return When(ok=True, at=at, text=f"{dtm.datetime.fromtimestamp(at):%d.%m.%Y %H:%M}")
        except ValueError:
            pass

    if dur is not None and dur > 0:
        if repeat_mode:
            return When(ok=True, interval=dur, repeats=repeats, text=f"каждые {humanize(dur)}")
        return When(ok=True, delay=dur, text=f"через {humanize(dur)}")

    return When(error=f"не понял «{raw}». Примеры: 300 · 5 минут · 1ч30м · 14:30 · завтра 9:00 · каждые 10 минут")


# ================================================================== модель
@dataclass
class Timer:
    id: str
    label: str
    due: float
    created: float = field(default_factory=time.time)
    interval: float = 0.0            # >0 = повторяющийся
    repeats_left: int = -1           # -1 = бесконечно, N = осталось N срабатываний
    state: str = STATE_ARMED
    sound: bool = True
    sound_name: str = "alarm"
    sound_repeat: int = 2
    note: str = ""
    fired_count: int = 0
    last_fired: float = 0.0
    paused_left: float = 0.0
    overdue: float = 0.0
    text: str = ""                   # как сформулировал пользователь

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict) -> "Timer":
        known = {f for f in Timer.__dataclass_fields__}   # type: ignore[attr-defined]
        return Timer(**{k: v for k, v in d.items() if k in known})

    def seconds_left(self, now: Optional[float] = None) -> float:
        now = time.time() if now is None else now
        if self.state == STATE_PAUSED:
            return self.paused_left
        return max(0.0, self.due - now)

    def describe(self, now: Optional[float] = None) -> str:
        now = time.time() if now is None else now
        if self.state == STATE_PAUSED:
            return f"{self.id} | ⏸ пауза, осталось {humanize(self.paused_left)} | {self.label}"
        if self.state != STATE_ARMED:
            return f"{self.id} | {self.state} | {self.label}"
        due_txt = dtm.datetime.fromtimestamp(self.due).strftime("%d.%m %H:%M:%S")
        rep = ""
        if self.interval > 0:
            n = "∞" if self.repeats_left < 0 else str(self.repeats_left)
            rep = f" | повтор каждые {humanize(self.interval)} (осталось {n})"
        return (f"{self.id} | через {humanize(self.due - now)} (в {due_txt}){rep} "
                f"| {self.label}" + (f" | {self.note}" if self.note else ""))


# ================================================================== хранилище
class TimerStore:
    """JSON-хранилище таймеров с блокировкой и атомарной записью."""

    def __init__(self, path: Optional[str] = None):
        self.path = path or os.path.join(app_dir(), "data", "timers.json")
        self.lock = threading.RLock()
        self.timers: dict[str, Timer] = {}
        self._counter = 0
        self.load()

    # --- persistence -------------------------------------------------------
    def load(self) -> None:
        with self.lock:
            self.timers.clear()
            if not os.path.exists(self.path):
                return
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                for d in raw.get("timers", []):
                    try:
                        t = Timer.from_dict(d)
                        self.timers[t.id] = t
                    except Exception:
                        continue
                self._counter = int(raw.get("counter", len(self.timers)))
            except Exception:
                pass

    def save(self) -> None:
        with self.lock:
            data = {"version": 2, "counter": self._counter,
                    "timers": [t.to_dict() for t in self.timers.values()]}
            tmp = self.path + ".tmp"
            try:
                os.makedirs(os.path.dirname(self.path), exist_ok=True)
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=1)
                os.replace(tmp, self.path)
            except Exception:
                try:
                    os.remove(tmp)
                except Exception:
                    pass

    # --- id ----------------------------------------------------------------
    def next_id(self) -> str:
        with self.lock:
            self._counter += 1
            tid = f"t{self._counter}"
            while tid in self.timers:
                self._counter += 1
                tid = f"t{self._counter}"
            return tid

    # --- CRUD --------------------------------------------------------------
    def add(self, t: Timer) -> Timer:
        with self.lock:
            if len(self.timers) >= MAX_TIMERS:
                raise RuntimeError(f"слишком много таймеров (лимит {MAX_TIMERS})")
            self.timers[t.id] = t
            self.save()
            return t

    def get(self, tid: str) -> Optional[Timer]:
        """Точный id или однозначный префикс (t1 находит t1, но не t10/t11)."""
        tid = (tid or "").strip().lower()
        with self.lock:
            if tid in self.timers:
                return self.timers[tid]
            hits = [t for k, t in self.timers.items() if k.startswith(tid)] if tid else []
            if len(hits) == 1:
                return hits[0]
            if len(hits) > 1:
                raise KeyError(f"неоднозначный id «{tid}»: {', '.join(h.id for h in hits)}")
            by_label = [t for t in self.timers.values() if tid and tid in t.label.lower()]
            if len(by_label) == 1:
                return by_label[0]
            if len(by_label) > 1:
                raise KeyError(f"неоднозначная метка «{tid}»: {', '.join(h.id for h in by_label)}")
            return None

    def all(self) -> list[Timer]:
        with self.lock:
            return sorted(self.timers.values(), key=lambda t: (t.state != STATE_ARMED, t.due))

    def active(self) -> list[Timer]:
        return [t for t in self.all() if t.state in (STATE_ARMED, STATE_PAUSED)]

    def remove(self, tid: str) -> bool:
        with self.lock:
            existed = self.timers.pop(tid, None) is not None
            if existed:
                self.save()
            return existed

    def touch(self) -> None:
        self.save()


# ================================================================== планировщик
class Scheduler:
    def __init__(self, store: Optional[TimerStore] = None, *, tick: float = TICK,
                 stale_after: float = DEFAULT_STALE, on_fire=None):
        self.store = store or TimerStore()
        self.tick = tick
        self.stale_after = stale_after
        self.on_fire = on_fire                    # доп. колбэк (тесты/расширения)
        self._unacked: list[dict] = []
        self._unacked_lock = threading.RLock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._recovered = False
        self.stats = {"started": 0.0, "ticks": 0, "fired": 0, "missed": 0, "errors": 0}

    # --- жизненный цикл ----------------------------------------------------
    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self) -> "Scheduler":
        if self.running:
            return self
        self._stop.clear()
        self.stats["started"] = time.time()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="flux-timers")
        self._thread.start()
        return self

    def stop(self, join_timeout: float = 2.0) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread:
            self._thread.join(join_timeout)
            self._thread = None

    def wake(self) -> None:
        """Разбудить поток немедленно (после создания/отмены таймера)."""
        self._wake.set()

    # --- основной цикл ------------------------------------------------------
    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                if not self._recovered:
                    self._recover()
                    self._recovered = True
                wait = self._tick_once()
            except Exception as e:
                self.stats["errors"] += 1
                events.publish({"type": "timer_error", "text": f"{type(e).__name__}: {e}"})
                wait = self.tick
            self.stats["ticks"] += 1
            # спим до ближайшего дедлайна, но не дольше MAX_SLEEP; wake() прерывает мгновенно
            self._wake.wait(min(max(wait, self.tick), MAX_SLEEP))
            self._wake.clear()

    def _tick_once(self) -> float:
        """Обрабатывает срабатывания. Возвращает секунд до следующего дедлайна.

        ВАЖНО: next_in пересчитывается ПОСЛЕ срабатываний. Прежняя схема
        (сначала собрать список дедлайнов, потом посчитать минимум) возвращала
        `inf`, если единственный таймер уже созрел, — поток засыпал на целую
        секунду и систематически опаздывал на повторных таймерах.
        """
        now = time.time()
        # каскад: несколько созревших сразу + быстрый интервал, догнавший сам себя
        for _ in range(64):
            due = [t for t in self.store.all() if t.state == STATE_ARMED and t.due <= now]
            if not due:
                break
            for t in due:
                self._fire(t, now)
            now = time.time()
        left = [t.due - now for t in self.store.all() if t.state == STATE_ARMED]
        return max(0.0, min(left)) if left else MAX_SLEEP

    def _recover(self) -> None:
        """Что делать с таймерами, оставшимися с прошлого запуска."""
        now = time.time()
        changed = False
        for t in self.store.all():
            if t.state not in (STATE_ARMED, STATE_PAUSED):
                continue
            if t.state == STATE_PAUSED:
                t.due = now + max(t.paused_left, 1.0)
                t.state = STATE_ARMED
                changed = True
            overdue = now - t.due
            if overdue <= 0:
                continue
            if overdue > self.stale_after:
                # приложение было закрыто слишком долго — не будим пользователя сиреной
                t.state = STATE_DONE
                t.overdue = overdue
                self.stats["missed"] += 1
                changed = True
                events.publish({"type": "timer_missed", "id": t.id, "label": t.label,
                                "overdue": int(overdue)})
            elif t.interval > 0:
                t.due = self._next_interval(t, now)
                changed = True
        if changed:
            self.store.save()

    @staticmethod
    def _next_interval(t: Timer, now: float) -> float:
        """Следующий дедлайн повтора без накопления дрейфа."""
        due = t.due
        guard = 0
        while due <= now and guard < 100000:
            due += t.interval
            guard += 1
        return due if guard < 100000 else now + t.interval

    def _fire(self, t: Timer, now: Optional[float] = None) -> None:
        now = time.time() if now is None else now
        with self.store.lock:
            t.overdue = max(0.0, now - t.due)
            t.last_fired = now
            t.fired_count += 1
            repeating = t.interval > 0 and t.repeats_left != 0
            if repeating:
                if t.repeats_left > 0:
                    t.repeats_left -= 1
                t.due = self._next_interval(t, now)
                if t.repeats_left == 0:
                    t.state = STATE_DONE
            else:
                t.state = STATE_DONE
            snapshot = t.to_dict()
            self.store.save()

        self.stats["fired"] += 1
        with self._unacked_lock:
            self._unacked.append(snapshot)
            del self._unacked[:-50]

        # звук/тост/событие в UI — в отдельном потоке, чтобы не задерживать тик
        threading.Thread(target=self._deliver, args=(snapshot,), daemon=True,
                         name=f"flux-timer-{snapshot['id']}").start()
        if self.on_fire:
            try:
                self.on_fire(snapshot)
            except Exception:
                self.stats["errors"] += 1

    def _deliver(self, snapshot: dict) -> None:
        try:
            notify.timer_fired(snapshot)
        except Exception:
            pass

    # --- очередь для агента -------------------------------------------------
    def unacked(self, clear: bool = True) -> list[dict]:
        """Сработавшие таймеры, о которых ещё не сообщили модели/пользователю."""
        with self._unacked_lock:
            out = list(self._unacked)
            if clear:
                self._unacked.clear()
        return out

    def peek_unacked(self) -> list[dict]:
        return self.unacked(clear=False)

    # --- API для тулзов ------------------------------------------------------
    def set_timer(self, when: Any, label: str = "", *, sound: bool = True,
                  sound_name: str = "alarm", sound_repeat: int = 2, note: str = "",
                  tid: Optional[str] = None) -> Timer:
        w = when if isinstance(when, When) else parse_when(when)
        if not w.ok:
            raise ValueError(w.error or "не удалось разобрать время")
        now = time.time()
        due = w.resolve(now)
        if due <= now + 0.02:
            # «сейчас»/уже прошло — не даём уйти в прошлое, иначе мгновенный шквал
            due = now + max(0.5, (due - now))
        interval = float(w.interval or 0.0)
        # repeats_left: 0 = одноразовый, -1 = бесконечный повтор, N>0 = осталось N срабатываний
        if interval > 0:
            repeats_left = w.repeats if w.repeats > 0 else -1
        else:
            repeats_left = 0
        t = Timer(id=tid or self.store.next_id(), label=(label or "таймер").strip()[:200],
                  due=due, interval=interval, repeats_left=repeats_left,
                  sound=bool(sound), sound_name=sound_name or "alarm",
                  sound_repeat=int(sound_repeat), note=(note or "")[:500], text=w.describe(now))
        self.store.add(t)
        self.wake()
        events.publish({"type": "timer_set", "id": t.id, "label": t.label, "due": t.due,
                        "interval": t.interval, "text": t.text})
        return t

    def cancel(self, tid: str) -> Timer:
        t = self.store.get(tid)
        if not t:
            raise KeyError(f"таймер не найден: {tid}")
        with self.store.lock:
            t.state = STATE_CANCELLED
            self.store.save()
        self.wake()
        events.publish({"type": "timer_cancelled", "id": t.id, "label": t.label})
        return t

    def snooze(self, tid: str, seconds: Any = 300) -> Timer:
        t = self.store.get(tid)
        if not t:
            raise KeyError(f"таймер не найден: {tid}")
        w = seconds if isinstance(seconds, When) else parse_when(seconds)
        delay = w.delay if (w.ok and w.delay) else (w.interval if w.ok and w.interval else None)
        if delay is None:
            delay = float(seconds) if str(seconds).replace(".", "").isdigit() else 300.0
        with self.store.lock:
            t.state = STATE_ARMED
            t.paused_left = 0.0
            t.due = time.time() + float(delay)
            t.overdue = 0.0
            if t.interval <= 0:
                t.repeats_left = 0
            self.store.save()
        self.wake()
        events.publish({"type": "timer_snoozed", "id": t.id, "label": t.label, "due": t.due})
        return t

    def pause(self, tid: str) -> Timer:
        t = self.store.get(tid)
        if not t:
            raise KeyError(f"таймер не найден: {tid}")
        with self.store.lock:
            if t.state == STATE_ARMED:
                t.paused_left = max(0.0, t.due - time.time())
                t.state = STATE_PAUSED
                self.store.save()
        self.wake()
        return t

    def resume(self, tid: str) -> Timer:
        t = self.store.get(tid)
        if not t:
            raise KeyError(f"таймер не найден: {tid}")
        with self.store.lock:
            if t.state == STATE_PAUSED:
                t.due = time.time() + max(t.paused_left, 0.5)
                t.state = STATE_ARMED
                self.store.save()
        self.wake()
        return t

    def clear_finished(self) -> int:
        with self.store.lock:
            dead = [k for k, t in self.store.timers.items() if t.state in (STATE_DONE, STATE_CANCELLED)]
            for k in dead:
                del self.store.timers[k]
            if dead:
                self.store.save()
        return len(dead)

    def next_fire(self) -> Optional[dict]:
        armed = [t for t in self.store.all() if t.state == STATE_ARMED]
        if not armed:
            return None
        t = min(armed, key=lambda x: x.due)
        return {"id": t.id, "label": t.label, "due": t.due, "in": round(t.due - time.time(), 1)}

    def snapshot(self) -> dict:
        return {"running": self.running, "stats": dict(self.stats),
                "next": self.next_fire(),
                "timers": [t.to_dict() for t in self.store.all()],
                "unacked": self.peek_unacked()}


SCHED = Scheduler()


def start() -> Scheduler:
    """Идемпотентный запуск планировщика (зовётся из main.py и из сервера)."""
    return SCHED.start()


def stop() -> None:
    SCHED.stop()


def new_timer_id() -> str:
    return uuid.uuid4().hex[:8]

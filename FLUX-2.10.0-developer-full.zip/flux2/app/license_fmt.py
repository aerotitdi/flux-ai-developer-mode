"""Формат лицензионного ключа FLUX — ЕДИНСТВЕННЫЙ источник правды.

Живёт в `app/` (а не в `license_server/`) нарочно: этот пакет попадает в клиентскую
поставку, а `license_server` — нет. Клиент обязан уметь привести введённый ключ к
каноническому виду и объяснить опечатку, не имея доступа к серверному коду.
`license_server/crypto.py` импортирует функции отсюда, поэтому формат не может
«разъехаться» между клиентом и сервером.

Формат:  FLX2-XXXXX-XXXXX-XXXXX-XXXXX
  * алфавит — Crockford base32 без неоднозначных символов (0, 1, I, L, O, U);
  * 19 случайных символов + 1 контрольный (ловит опечатку при вводе);
  * ключ сам по себе ничего не доказывает клиенту — его проверяет сервер по
    sha256-хешу. Вытащить из exe «генератор ключей» нельзя: его там нет.
"""
from __future__ import annotations

import hashlib
import secrets
from typing import Optional

ALPHABET = "23456789ABCDEFGHJKMNPQRSTVWXYZ"      # 30 символов, без 0 1 I L O U
KEY_BODY_LEN = 20                                 # 19 случайных + 1 контрольный
KEY_PREFIX = "FLX2"
GROUP = 5

# символы, которые пользователь вводит по ошибке вместо допустимых
_LOOKALIKE = {"0": "O", "O": "O", "1": "I", "I": "I", "L": "L", "U": "V"}
# но O, I, L, U в алфавите нет — их мы не «чиним», а честно показываем как ошибку.
# Чиним только то, что однозначно отображается в допустимый символ:
_FIXABLE = {"0": "Q", "1": "I"}        # не используется: см. нормализацию ниже


def _check_char(body: str) -> str:
    """Контрольный символ: взвешенная сумма позиций по модулю размера алфавита."""
    total = 0
    for i, ch in enumerate(body):
        idx = ALPHABET.find(ch)
        if idx < 0:
            return "?"                  # мусор: контрольный символ заведомо не совпадёт
        total += (idx + 1) * (i + 3)
    return ALPHABET[total % len(ALPHABET)]


def make_key(prefix: str = KEY_PREFIX) -> str:
    """Сгенерировать новый ключ (используется только админ-утилитой)."""
    body = "".join(secrets.choice(ALPHABET) for _ in range(KEY_BODY_LEN - 1))
    body += _check_char(body)
    return prefix + "-" + "-".join(body[i:i + GROUP] for i in range(0, len(body), GROUP))


def strip_prefix(s: str) -> str:
    """Снять префикс и всё, что не является буквой/цифрой."""
    s = "".join(ch for ch in (s or "").strip().upper() if ch.isalnum())
    for pref in (KEY_PREFIX, "FLUX2", "FLUX", "FLX"):
        if s.startswith(pref):
            return s[len(pref):]
    return s


def normalize_key(raw: str) -> Optional[str]:
    """Привести введённое к каноническому виду или None, если это не наш ключ.

    Терпит: пробелы, дефисы, подчёркивания, строчные буквы, отсутствие/лишний
    префикс. Не пытается «угадывать» неоднозначные символы — их просто нет в
    алфавите, поэтому 0/1/I/L/O/U всегда ошибка, и мы о ней говорим.
    """
    if not raw:
        return None
    s = strip_prefix(raw)
    if len(s) != KEY_BODY_LEN:
        return None
    if any(ch not in ALPHABET for ch in s):
        return None
    if _check_char(s[:-1]) != s[-1]:
        return None
    return KEY_PREFIX + "-" + "-".join(s[i:i + GROUP] for i in range(0, len(s), GROUP))


def key_hint(raw: str) -> str:
    """Почему ключ не подошёл — чтобы пользователь не гадал.

    ВАЖНО: `str.isalnum()` в Python возвращает True и для кириллицы, поэтому
    фильтрация идёт по принадлежности алфавиту, а не по isalnum.
    """
    if not raw or not raw.strip():
        return "пусто"
    s = strip_prefix(raw)
    bad = sorted({ch for ch in s if ch not in ALPHABET})
    if bad:
        return ("недопустимые символы: " + " ".join(bad)
                + ". Алфавит ключа: " + ALPHABET + " (в нём нет 0 1 I L O U)")
    if len(s) != KEY_BODY_LEN:
        return (f"длина {len(s)}, нужно {KEY_BODY_LEN} символов. "
                f"Формат: FLX2-XXXXX-XXXXX-XXXXX-XXXXX")
    if _check_char(s[:-1]) != s[-1]:
        return ("опечатка: контрольный символ не сходится. Чаще всего путают "
                "8/B, Z/2, S/5, V/Y, Q/O — проверь группы заново")
    return "ключ выглядит корректно (проблема на стороне сервера или статуса лицензии)"


def key_hash(key: str) -> str:
    """Хеш ключа для хранения в БД: при утечке базы ключи не восстанавливаются."""
    return hashlib.sha256(("flux2::" + key).encode("utf-8")).hexdigest()


def key_id(key: str) -> str:
    """Короткий публичный идентификатор (логи, админка, тикеты)."""
    src = key.strip()
    if src.startswith("-----BEGIN"):          # передали PEM — считаем отпечаток от него
        return key_hash(src)[:12].upper()
    norm = normalize_key(src) or src
    return key_hash(norm)[:12].upper()


def mask_key(key: str) -> str:
    """FLX2-ABCDE-*****-*****-VWXYZ — для логов и интерфейса."""
    k = normalize_key(key) or (key or "")
    parts = k.split("-")
    if len(parts) != 5:
        return k[:4] + "…"
    return "-".join([parts[0], parts[1], "*****", "*****", parts[4]])


def looks_like_key(raw: str) -> bool:
    """Быстрая проверка «похоже ли на наш ключ» — для валидации форм."""
    return normalize_key(raw) is not None

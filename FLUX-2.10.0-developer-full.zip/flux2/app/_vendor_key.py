"""Публичный ключ вендора FLUX. СГЕНЕРИРОВАН АВТОМАТИЧЕСКИ — не правь руками.

Источник: license_server/keys.py (команда `python -m license_server.keygen init`).
Этим ключом клиент проверяет подписи билетов активации (app/licensing.py).
Подделать билет, не имея приватного ключа вендора, нельзя; замена этого файла
своим ключом потребует пересборки приложения, а не правки конфига.
"""
VENDOR_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAiJSSfkvMdz6dFtiV8gaeAmJAsWa/ZcJa/bzWlultlfM=
-----END PUBLIC KEY-----"""

VENDOR_KEY_FINGERPRINT = "931F4BA7E675"
GENERATED_AT = "2026-10-12 16:43:53"

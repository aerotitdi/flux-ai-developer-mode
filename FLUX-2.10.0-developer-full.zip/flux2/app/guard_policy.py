"""Политика безопасности для привилегированных действий «стража ПК».

ЗАЧЕМ ЭТОТ СЛОЙ. Агент с доступом к реестру, процессам и файловой системе,
который действует автономно, — это риск сломать систему на одной галлюцинации
модели. Поэтому каждое действие проходит три проверки ДО выполнения:

  1. **ЗАПРЕЩЕНО (deny)** — не выполняется НИКОГДА, ни в каком режиме,
     ни по какому токену. Список закрытый и консервативный: нельзя трогать
     антивирусы и Defender, нельзя выключать UAC/SmartScreen/брандмауэр,
     нельзя менять Winlogon\\Shell|Userinit, нельзя удалять что-либо в
     системных каталогах, нельзя блокировать запуск системных и защитных
     программ, нельзя форматировать диски и удалять теневые копии.
     Отдельно: **нельзя УСТАНАВЛИВАТЬ ограничения** (DisableTaskMgr и т.п.) —
     только снимать. Асимметрия намеренная: модуль пригоден для лечения
     машины и непригоден для её блокировки.

  2. **ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ (confirm)** — завершение процесса, карантин файла,
     блокировка запуска, снятие политик, удаление записи автозапуска,
     отключение службы. Схема «человек в контуре»:
       тулз без токена  -> создаётся запрос + SSE-событие guard_confirm
                          -> окно чата показывает «Разрешить / Запретить»
       пользователь жмёт -> POST /api/guard/confirm -> запрос одобрен
       модель повторяет вызов с confirm_token=<id> -> действие выполняется
     Токен одноразовый, живёт 120 с, привязан к паре (действие, цель).

  3. **ЧИТАЙ СКОЛЬКО ХОЧЕШЬ (read)** — инвентаризация автозапуска, статус
     политик, список процессов, хеши. Без подтверждения: чтение ничего не ломает.

Всё пишется в аудит-лог `data/guard_audit.jsonl` — кто, что, когда, чем кончилось.

Режим `guard_mode` в настройках:
  confirm (по умолчанию) — как описано выше;
  auto                   — подтверждения выдаются автоматически. ОПАСНО,
                           включаете осознанно; запретный список действует всё равно;
  off                    — привилегированные действия отключены, только чтение.
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

from . import events
from .config import CONFIG, app_dir

TIER_READ = "read"
TIER_CONFIRM = "confirm"
TIER_DENY = "deny"

CONFIRM_TTL = 120.0
AUDIT_PATH = lambda: os.path.join(app_dir(), "data", "guard_audit.jsonl")

# ---------------------------------------------------------------- запретный список
# Антивирусы / защитные подсистемы: их нельзя ни убивать, ни отключать, ни блокировать.
_PROTECTED_NAMES = (
    "msmpeng", "msmpsrv", "nisrv", "windefend", "waaasmedicsvc", "securityhealthservice",
    "securityhealthsystray", "sgrmbroker", "sense", "sensecncproxy", "wscsvc", "wscui",
    "mpsvc", "msascui", "smartscreen", "wuauserv", "bits", "bfe", "mpssvc",
    # сторонние АВ/EDR
    "avp", "avpsus", "klnagent", "fsma", "fsdfwd", "fshoster", "avgui", "avgsvc",
    "bdagent", "vsserv", "epsec", "ekrn", "egui", "mbamservice", "mbamtray",
    "mcshield", "mfevtps", "savservice", "sophos", "sentinelagent", "carbonblack",
    "cylance", "crowdstrike", "falcon", "titanagent", "eset", "kaspersky", "drweb",
    "360tray", "360safe", "qqpcmgr", "hipsdaemon", "usysdiag",
)
_PROTECTED_PATHS = (
    r"%systemroot%\system32", r"c:\windows\system32", r"c:\windows\syswow64",
    r"c:\windows", r"c:\program files\windows defender",
    r"c:\program files\windowsapps", r"c:\programdata\microsoft\windows defender",
)
# Значения реестра, которые мы имеем право ТОЛЬКО УДАЛЯТЬ (снятие блокировок).
# Запись в них запрещена всегда — иначе модуль превратился бы в инструмент блокировки ПК.
_RESTRICTION_VALUES = (
    r"software\microsoft\windows\currentversion\policies\system",
    r"software\microsoft\windows\currentversion\policies\explorer",
    r"software\microsoft\windows\currentversion\policies\activedesktop",
    r"software\policies\microsoft\windows\safer",
    r"software\policies\microsoft\windows defender",
)
_FORBIDDEN_COMMANDS = (
    "format", "diskpart", "vssadmin delete", "vssadmin remove", "wmic shadowcopy delete",
    "bcdedit", "shutdown /s /t 0", "shutdown /r /t 0", "cipher /w", "reg unload",
    "reg save", "sc config windefend", "sc stop windefend", "net stop windefend",
    "net stop mpssvc", "sc stop mpssvc", "set-mppreference -disable", "add-mppreference",
    "regsvr32 /i:http", "mshta ", "rundll32.exe javascript", "certutil -urlcache",
)


def _norm(target: str) -> str:
    """Нормализация ПУТИ: к обратным слэшам (Windows-вид)."""
    return (target or "").strip().lower().replace("/", "\\")


def _norm_cmd(target: str) -> str:
    """Нормализация КОМАНДНОЙ СТРОКИ: к прямым слэшам.

    Отдельная от _norm — иначе «shutdown /s /t 0» превращалась в «shutdown \\s \\t 0»
    и не совпадала с запретным списком.
    """
    t = (target or "").strip().lower().replace("\\", "/")
    return re.sub(r"\s+", " ", t)


def _is_protected_name(target: str) -> bool:
    t = _norm(target)
    base = re.sub(r"\.(exe|sys|dll|svc)$", "", t.replace("\\", "/").split("/")[-1])
    return base in _PROTECTED_NAMES or any(p in base for p in ("defender", "antivirus", "edr"))


def _is_protected_path(target: str) -> bool:
    t = _norm(target)
    return any(p in t for p in _PROTECTED_PATHS)


@dataclass
class Decision:
    allowed: bool
    tier: str
    reason: str = ""
    request_id: str = ""

    def as_text(self) -> str:
        return self.reason


@dataclass
class ConfirmRequest:
    id: str
    action: str
    target: str
    reason: str
    created: float = field(default_factory=time.time)
    expires: float = 0.0
    approved: Optional[bool] = None
    used: bool = False
    detail: dict = field(default_factory=dict)

    def expired(self) -> bool:
        return time.time() > self.expires

    def to_dict(self) -> dict:
        return {"id": self.id, "action": self.action, "target": self.target,
                "reason": self.reason, "expires_in": round(max(0, self.expires - time.time())),
                "approved": self.approved, "used": self.used, "detail": self.detail}


class Policy:
    def __init__(self):
        self.lock = threading.RLock()
        self.pending: dict[str, ConfirmRequest] = {}

    # --- режим ------------------------------------------------------------
    @property
    def mode(self) -> str:
        return (CONFIG.settings.get("guard_mode") or "confirm").lower()

    # --- аудит ------------------------------------------------------------
    def audit(self, action: str, target: str, decision: str, detail: str = "",
              tier: str = "", token: str = "") -> None:
        rec = {"ts": round(time.time(), 3),
               "time": time.strftime("%Y-%m-%d %H:%M:%S"),
               "action": action, "target": (target or "")[:400],
               "tier": tier, "decision": decision, "token": token,
               "mode": self.mode, "detail": detail[:600],
               "user": os.environ.get("USERNAME") or os.environ.get("USER") or ""}
        try:
            os.makedirs(os.path.dirname(AUDIT_PATH()), exist_ok=True)
            with open(AUDIT_PATH(), "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass
        events.publish({"type": "guard_audit", **rec})

    def read_audit(self, limit: int = 100, only: str = "") -> list[dict]:
        path = AUDIT_PATH()
        if not os.path.exists(path):
            return []
        out = []
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except Exception:
                        continue
                    if only and only.lower() not in json.dumps(rec, ensure_ascii=False).lower():
                        continue
                    out.append(rec)
        except Exception:
            pass
        return out[-limit:]

    # --- классификация ------------------------------------------------------
    def classify(self, action: str, target: str = "") -> Decision:
        a = (action or "").lower().strip()
        t = target or ""

        if self.mode == "off" and not is_read_action(a):
            return Decision(False, TIER_DENY,
                            "страж в режиме off: привилегированные действия отключены, "
                            "доступна только инвентаризация")

        # --- жёсткие запреты (действуют в любом режиме) --------------------
        if a.startswith(("set_policy", "enable_restriction", "restrict", "block_user")):
            self.audit(a, t, "DENY", "попытка УСТАНОВИТЬ ограничение — модуль только снимает их",
                       TIER_DENY)
            return Decision(False, TIER_DENY,
                            "FLUX умеет только СНЕМАТЬ блокировки (лечить), но не устанавливать их. "
                            "Установка DisableTaskMgr/DisableRegistryTools запрещена намеренно.")

        cmd_norm = _norm_cmd(t)
        cmd_hit = next((c for c in _FORBIDDEN_COMMANDS if _norm_cmd(c) in cmd_norm), None)
        if cmd_hit:
            self.audit(a, t, "DENY", f"запрещённая команда: {cmd_hit}", TIER_DENY)
            return Decision(False, TIER_DENY,
                            f"команда «{cmd_hit}» в запретном списке (необратимое повреждение системы)")

        if a in ("process_kill", "kill") and _is_protected_name(t):
            self.audit(a, t, "DENY", "защищённый процесс (АВ/система)", TIER_DENY)
            return Decision(False, TIER_DENY,
                            f"«{t}» — антивирус или системный компонент. Завершать нельзя: "
                            f"машину защищает именно он.")

        if a in ("block_launch", "unblock_launch") and (_is_protected_name(t) or _is_protected_path(t)):
            self.audit(a, t, "DENY", "защищённый образ/путь", TIER_DENY)
            return Decision(False, TIER_DENY,
                            f"блокировка запуска «{t}» запрещена: это системный или защитный образ.")

        if a in ("file_delete", "quarantine", "delete") and _is_protected_path(t):
            self.audit(a, t, "DENY", "системный каталог", TIER_DENY)
            return Decision(False, TIER_DENY,
                            f"«{t}» лежит в системном каталоге. Удалять/карантинить нельзя.")

        if a == "file_delete":
            self.audit(a, t, "DENY", "удаление запрещено, используйте карантин", TIER_DENY)
            return Decision(False, TIER_DENY,
                            "FLUX не удаляет файлы безвозвратно — только перемещает в карантин "
                            "(guard_file_quarantine), откуда их можно вернуть.")

        if a == "autostart_remove":
            # Winlogon Shell/Userinit — критично: трогать нельзя ни в какую сторону
            if re.search(r"winlogon[\\/]?(shell|userinit|notify)", _norm(t)):
                self.audit(a, t, "DENY", "критичный ключ Winlogon", TIER_DENY)
                return Decision(False, TIER_DENY,
                                f"«{t}» — критичный параметр входа в Windows. "
                                f"Его изменение ломает загрузку профиля; править нельзя.")

        if a in ("service_disable", "service_stop") and _is_protected_name(t):
            self.audit(a, t, "DENY", "защищённая служба", TIER_DENY)
            return Decision(False, TIER_DENY, f"службу «{t}» отключать нельзя (защита/система).")

        if a == "policy_restore" and _is_protected_path(t):
            return Decision(False, TIER_DENY, "путь вне разрешённых веток политик")

        # --- чтение всегда разрешено ---------------------------------------
        if is_read_action(a):
            return Decision(True, TIER_READ, "чтение")

        # --- всё остальное: подтверждение -----------------------------------
        if self.mode == "auto":
            return Decision(True, TIER_CONFIRM, "подтверждено автоматически (guard_mode=auto)")
        return self._request(a, t)

    # --- подтверждение -------------------------------------------------------
    def _request(self, action: str, target: str,
                 detail: Optional[dict] = None) -> Decision:
        rid = uuid.uuid4().hex[:10]
        req = ConfirmRequest(id=rid, action=action, target=target,
                             reason=_why(action, target),
                             expires=time.time() + CONFIRM_TTL,
                             detail=detail or {})
        with self.lock:
            self._gc()
            self.pending[rid] = req
        events.publish({"type": "guard_confirm", **req.to_dict()})
        self.audit(action, target, "PENDING", req.reason, TIER_CONFIRM, rid)
        return Decision(False, TIER_CONFIRM,
                        f"нужно твоё разрешение: {req.reason}\n"
                        f"Запрос {rid} отправлен в окно FLUX (кнопки «Разрешить» / «Запретить», "
                        f"действует {int(CONFIRM_TTL)} с). После одобрения повтори вызов с "
                        f"confirm_token={rid}.",
                        request_id=rid)

    def _gc(self) -> None:
        dead = [k for k, v in self.pending.items() if v.expired() and v.used]
        for k in dead:
            self.pending.pop(k, None)
        if len(self.pending) > 200:
            for k in sorted(self.pending, key=lambda x: self.pending[x].created)[:-200]:
                self.pending.pop(k, None)

    def approve(self, rid: str, allow: bool, note: str = "") -> dict:
        with self.lock:
            req = self.pending.get(rid)
            if not req:
                return {"ok": False, "error": f"запрос {rid} не найден или истёк"}
            if req.expired():
                return {"ok": False, "error": f"запрос {rid} истёк — вызови действие заново"}
            if req.used:
                return {"ok": False, "error": f"запрос {rid} уже использован"}
            req.approved = bool(allow)
            if not allow:
                req.used = True
                self.audit(req.action, req.target, "REJECTED", note or "пользователь запретил",
                           TIER_CONFIRM, rid)
                return {"ok": True, "approved": False, "request": req.to_dict()}
        self.audit(req.action, req.target, "APPROVED", note or "пользователь разрешил",
                   TIER_CONFIRM, rid)
        return {"ok": True, "approved": True, "token": rid, "request": req.to_dict()}

    def consume(self, token: str, action: str, target: str) -> Decision:
        """Проверить и погасить токен подтверждения."""
        if not token:
            return Decision(False, TIER_CONFIRM, "нет токена подтверждения")
        with self.lock:
            req = self.pending.get(token.strip())
            if not req:
                return Decision(False, TIER_CONFIRM, f"токен {token} не найден или истёк")
            if req.expired():
                self.pending.pop(token, None)
                return Decision(False, TIER_CONFIRM, f"токен {token} истёк ({int(CONFIRM_TTL)} с)")
            if req.used:
                return Decision(False, TIER_CONFIRM, f"токен {token} уже использован (одноразовый)")
            if req.approved is not True:
                return Decision(False, TIER_CONFIRM, f"запрос {token} ещё не одобрен пользователем")
            if req.action != action or _norm(req.target) != _norm(target):
                return Decision(False, TIER_CONFIRM,
                                f"токен выдан для другого действия: {req.action} «{req.target}», "
                                f"а просят {action} «{target}»")
            req.used = True
        return Decision(True, TIER_CONFIRM, "подтверждено пользователем", request_id=token)

    def pending_list(self) -> list[dict]:
        with self.lock:
            self._gc()
            return [r.to_dict() for r in self.pending.values()
                    if not r.used and not r.expired()]


# Действия, которые ничего не меняют. В режиме guard_mode=off разрешены только они.
READ_ACTIONS = frozenset({
    "autostart_list", "autostart_scan", "policy_status", "process_list", "process_info",
    "file_hash", "file_info", "quarantine_list", "audit_log", "report", "scan", "status",
    "info", "list", "read", "ext_list", "ext_find", "ext_risk_report", "ext_shortcuts",
})


def is_read_action(action: str) -> bool:
    a = (action or "").lower().strip()
    if a in READ_ACTIONS:
        return True
    return a.startswith(("list_", "status_", "info_", "scan_", "read_", "report_")) \
        and not a.endswith(("_remove", "_kill", "_restore", "_quarantine", "_block"))


def _why(action: str, target: str) -> str:
    return {
        "process_kill": f"завершить процесс «{target}»",
        "quarantine": f"переместить в карантин «{target}»",
        "file_quarantine": f"переместить в карантин «{target}»",
        "block_launch": f"запретить запуск «{target}»",
        "unblock_launch": f"разрешить запуск «{target}»",
        "policy_restore": "снять блокировки Windows (диспетчер задач / реестр / cmd и т.п.)",
        "autostart_remove": f"удалить запись автозапуска «{target}»",
        "service_disable": f"отключить службу «{target}»",
        "file_restore": f"вернуть из карантина «{target}»",
    }.get(action, f"{action}: {target}")


POLICY = Policy()


def check(action: str, target: str = "", token: str = "") -> Decision:
    """Единая точка проверки. Сначала запретный список, потом токен, потом запрос."""
    d = POLICY.classify(action, target)
    if d.tier != TIER_CONFIRM or d.allowed:
        return d
    if token:
        return POLICY.consume(token, action, target)
    return d


def audit(action: str, target: str, decision: str, detail: str = "") -> None:
    POLICY.audit(action, target, decision, detail)

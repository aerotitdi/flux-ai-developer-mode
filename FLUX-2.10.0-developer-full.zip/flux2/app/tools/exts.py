"""Расширения браузера: инвентаризация УЖЕ УСТАНОВЛЕННЫХ и работа с ними.

ЧЕСТНО О ВОЗМОЖНОСТЯХ. Извне нельзя «вызвать API чужого расширения»: Chrome не
даёт внешнему процессу обратиться к `chrome.*` другого экстеншена. Что реально
работает — и что здесь сделано:

  1. **Инвентаризация**: читаем `manifest.json` из профилей Chrome/Edge/Brave/Vivaldi
     (и `extensions.json` у Firefox) — имя, версия, разрешения, хосты, content_scripts,
     popup. Это же закрывает задачу «стража ПК»: расширение с `<all_urls>` + `webRequest`
     + `cookies` — типичный признак шпионского аддона.
  2. **Запуск страниц расширения**: `chrome-extension://<id>/<popup|options>.html`
     открывается как обычная ВКЛАДКА, и дальше её ведут штатные browser_page_snapshot /
     browser_act. Для большинства расширений с UI этого достаточно.
  3. **Горячие клавиши**: `chrome://extensions/shortcuts` — можно увидеть и нажать
     комбинацию, которой расширение слушает (единственный легальный способ
     «дёрнуть» расширение без его собственного API).
  4. **Своё расширение FLUX Bridge** (`extension/`) — вот оно даёт полноценный
     привилегированный доступ (chrome.debugger) к живому Chrome без перезапуска.
     Это и есть основной транспорт, а не чужие аддоны.

Разрешения ранжируются по уровню риска, чтобы «страж» мог подсветить опасные.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Optional

from ..config import CONFIG
from .registry import P, REG, ToolResult

C = "extensions"
T = REG.tool

NT = sys.platform == "win32"
MAC = sys.platform == "darwin"

# браузер -> (корень профилей, список имён каталогов)
BROWSERS = {
    "chrome": {"win": r"{local}\Google\Chrome\User Data",
               "mac": "~/Library/Application Support/Google/Chrome",
               "linux": "~/.config/google-chrome"},
    "edge": {"win": r"{local}\Microsoft\Edge\User Data",
             "mac": "~/Library/Application Support/Microsoft Edge",
             "linux": "~/.config/microsoft-edge"},
    "brave": {"win": r"{local}\BraveSoftware\Brave-Browser\User Data",
              "mac": "~/Library/Application Support/BraveSoftware/Brave-Browser",
              "linux": "~/.config/BraveSoftware/Brave-Browser"},
    "vivaldi": {"win": r"{local}\Vivaldi\User Data",
                "mac": "~/Library/Application Support/Vivaldi",
                "linux": "~/.config/vivaldi"},
    "chromium": {"win": "", "mac": "~/Library/Application Support/Chromium",
                 "linux": "~/.config/chromium"},
    "yandex": {"win": r"{local}\Yandex\YandexBrowser\User Data",
               "mac": "", "linux": ""},
    "opera": {"win": r"{roaming}\Opera Software\Opera Stable",
              "mac": "~/Library/Application Support/com.operasoftware.Opera",
              "linux": "~/.config/opera"},
}
PROFILE_DIRS = ("Default", "Profile 1", "Profile 2", "Profile 3", "Profile 4",
                "Profile 5", "Guest Profile", "System Profile")

# Чем опасно разрешение. Уровень 3 = почти всегда повод насторожиться.
RISK = {
    "debugger": (3, "полный контроль над вкладками (chrome.debugger)"),
    "<all_urls>": (3, "доступ ко всем сайтам"),
    "webRequest": (2, "видит и меняет сетевые запросы"),
    "webRequestBlocking": (3, "блокирует/подменяет запросы на лету"),
    "cookies": (3, "читает cookie — включая сессии банков и почты"),
    "history": (3, "читает историю посещений"),
    "bookmarks": (2, "читает и меняет закладки"),
    "downloads": (2, "управляет загрузками"),
    "nativeMessaging": (3, "связь с программой на диске — классический мост для малвари"),
    "management": (3, "управляет другими расширениями (может отключать защитники)"),
    "tabs": (1, "видит URL и заголовки вкладок"),
    "tabCapture": (3, "записывает содержимое вкладки"),
    "desktopCapture": (3, "записывает экран"),
    "clipboardRead": (2, "читает буфер обмена"),
    "clipboardWrite": (1, "пишет в буфер обмена"),
    "proxy": (3, "подменяет прокси — перехват трафика"),
    "privacy": (2, "меняет настройки приватности"),
    "sessions": (2, "доступ к закрытым сессиям"),
    "unlimitedStorage": (0, ""),
    "storage": (0, ""),
    "notifications": (1, "показывает уведомления"),
    "alarms": (0, ""),
    "activeTab": (0, "доступ только к текущей вкладке по клику"),
    "scripting": (2, "внедряет скрипты в страницы"),
    "declarativeNetRequest": (2, "перехватывает/переписывает запросы"),
    "idle": (1, "следит за активностью пользователя"),
    "geolocation": (2, "геолокация"),
    "tts": (1, "озвучка"),
    "contextMenus": (0, ""),
}


def _expand(path: str) -> str:
    if not path:
        return ""
    path = path.replace("{local}", os.environ.get("LOCALAPPDATA", ""))
    path = path.replace("{roaming}", os.environ.get("APPDATA", ""))
    return os.path.expanduser(path)


def browser_roots() -> dict[str, str]:
    key = {"win32": "win", "darwin": "mac"}.get(sys.platform, "linux")
    return {b: _expand(cfg[key]) for b, cfg in BROWSERS.items() if cfg.get(key)}


def _read_json(path: str) -> Optional[dict]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _resolve_msg(ext_dir: str, value: str, default_locale: str = "en") -> str:
    """__MSG_name__ -> строка из _locales/<locale>/messages.json."""
    if not value.startswith("__MSG_"):
        return value
    key = value[6:-2]
    for loc in (default_locale, "en", "ru", "en_US"):
        p = os.path.join(ext_dir, "_locales", loc, "messages.json")
        d = _read_json(p)
        if not d:
            continue
        for k, v in d.items():
            if k.lower() == key.lower() and isinstance(v, dict):
                return str(v.get("message", value))
    return value


def scan_extensions(browsers: Optional[list] = None) -> list[dict]:
    """Полная инвентаризация установленных расширений (только чтение)."""
    out: list[dict] = []
    roots = browser_roots()
    wanted = set(browsers) if browsers else None
    for browser, root in roots.items():
        if wanted and browser not in wanted:
            continue
        if not root or not os.path.isdir(root):
            continue
        for prof in PROFILE_DIRS:
            pdir = os.path.join(root, prof)
            if not os.path.isdir(pdir):
                continue
            ext_root = os.path.join(pdir, "Extensions")
            if os.path.isdir(ext_root):
                for eid in sorted(os.listdir(ext_root)):
                    epath = os.path.join(ext_root, eid)
                    if not os.path.isdir(epath) or len(eid) != 32:
                        continue
                    try:
                        versions = sorted(os.listdir(epath))
                    except OSError:
                        continue
                    for ver in reversed(versions):
                        mf = _read_json(os.path.join(epath, ver, "manifest.json"))
                        if mf:
                            out.append(_describe(mf, epath, eid, ver, browser, prof))
                            break
            # Firefox-style: один extensions.json на профиль
            fjson = _read_json(os.path.join(pdir, "extensions.json"))
            if fjson and isinstance(fjson.get("addons"), list):
                for a in fjson["addons"]:
                    if a.get("type") != "extension":
                        continue
                    out.append({
                        "browser": browser, "profile": prof, "id": a.get("id", ""),
                        "name": a.get("defaultLocale", {}).get("name") or a.get("id", ""),
                        "version": a.get("version", ""), "path": a.get("path", ""),
                        "permissions": sorted({p for p in (a.get("userPermissions") or {}).get("permissions", [])}),
                        "hosts": (a.get("userPermissions") or {}).get("origins", []),
                        "active": bool(a.get("active")), "risk": 0, "risk_notes": [],
                        "popup": "", "options": "", "manifest_version": 0,
                    })
    return out


def _describe(mf: dict, epath: str, eid: str, ver: str, browser: str, prof: str) -> dict:
    ext_dir = os.path.join(epath, ver)
    locale = mf.get("default_locale") or "en"
    name = _resolve_msg(ext_dir, str(mf.get("name") or eid), locale)
    desc = _resolve_msg(ext_dir, str(mf.get("description") or ""), locale)

    perms = list(mf.get("permissions") or [])
    hosts = list(mf.get("host_permissions") or [])
    # MV2 держит хосты прямо в permissions
    for p in list(perms):
        if isinstance(p, str) and ("://" in p or p.startswith("<")):
            hosts.append(p)
    perms = [p for p in perms if not (isinstance(p, str) and ("://" in p or p.startswith("<")))]

    risk, notes = 0, []
    for item in set(perms) | set(hosts):
        lvl, why = RISK.get(item, (0, ""))
        if lvl >= 2:
            notes.append(f"{item}: {why}" if why else item)
        risk = max(risk, lvl)
    if mf.get("background", {}).get("scripts") and mf.get("manifest_version") == 2:
        notes.append("MV2 background-скрипт (постоянно активен)")

    popup = ((mf.get("action") or mf.get("browser_action") or {}).get("default_popup") or "")
    options = mf.get("options_page") or (mf.get("options_ui") or {}).get("page") or ""
    return {"browser": browser, "profile": prof, "id": eid, "version": ver,
            "name": name, "description": desc[:160], "path": ext_dir,
            "manifest_version": mf.get("manifest_version", 0),
            "permissions": sorted(set(perms)), "hosts": sorted(set(hosts))[:20],
            "popup": popup, "options": options,
            "content_scripts": [m for cs in (mf.get("content_scripts") or [])
                                 for m in (cs.get("matches") or [])][:10],
            "risk": risk, "risk_notes": sorted(set(notes))[:8]}


def _fmt(e: dict, verbose: bool) -> str:
    flag = {3: "🔴", 2: "🟠", 1: "🟡", 0: "🟢"}.get(e.get("risk", 0), "⚪")
    line = (f"{flag} {e['name']} v{e['version']} [{e['browser']}/{e['profile']}] id={e['id']}"
            + ("  НЕАКТИВНО" if e.get("active") is False else ""))
    if verbose:
        if e.get("description"):
            line += f"\n    {e['description']}"
        if e.get("permissions"):
            line += "\n    разрешения: " + ", ".join(e["permissions"][:12])
        if e.get("hosts"):
            line += "\n    хосты: " + ", ".join(e["hosts"][:6])
        if e.get("content_scripts"):
            line += "\n    внедряется на: " + ", ".join(e["content_scripts"][:4])
        if e.get("popup"):
            line += f"\n    popup: chrome-extension://{e['id']}/{e['popup']}"
        if e.get("risk_notes"):
            line += "\n    РИСК: " + "; ".join(e["risk_notes"])
    return line


# ============================================================== ТУЛЗЫ
@T("ext_list",
   "Список УЖЕ УСТАНОВЛЕННЫХ расширений браузера (Chrome/Edge/Brave/Vivaldi/Opera/Яндекс): "
   "имя, версия, разрешения, хосты, уровень риска. Только чтение — ничего не устанавливает.",
   [P("browser", desc="chrome|edge|brave|vivaldi|opera|yandex (пусто = все)", required=False, default=""),
    P("risky_only", "boolean", desc="только с разрешениями уровня риска 2+", required=False, default=False),
    P("verbose", "boolean", desc="подробно: разрешения, хосты, popup", required=False, default=True)], C, core=True)
def _(ctx, browser, risky_only, verbose):
    exts = scan_extensions([browser.strip()] if browser.strip() else None)
    if risky_only:
        exts = [e for e in exts if e.get("risk", 0) >= 2]
    if not exts:
        roots = browser_roots()
        return ToolResult(True, "расширений не найдено. Проверены каталоги:\n"
                                + "\n".join(f"  {b}: {p} ({'есть' if os.path.isdir(p) else 'нет'})"
                                            for b, p in roots.items()))
    exts.sort(key=lambda e: (-e.get("risk", 0), e["name"].lower()))
    head = f"установлено расширений: {len(exts)}"
    risky = [e for e in exts if e.get("risk", 0) >= 2]
    if risky:
        head += f" · из них с повышенными разрешениями: {len(risky)}"
    return head + "\n" + "\n".join(_fmt(e, bool(verbose)) for e in exts[:60])


@T("ext_find",
   "Найти расширение, подходящее под задачу (по имени/описанию/разрешениям). "
   "Например «какой аддон умеет переводить страницы» или «чем снять видео с экрана».",
   [P("query", desc="что должно уметь расширение")], C)
def _(ctx, query):
    q = (query or "").lower()
    exts = scan_extensions()
    scored = []
    for e in exts:
        hay = " ".join([e["name"], e.get("description", ""), " ".join(e.get("permissions", [])),
                        " ".join(e.get("hosts", [])), " ".join(e.get("content_scripts", []))]).lower()
        s = sum(1 for tok in q.replace(",", " ").split() if len(tok) > 2 and tok in hay)
        if s:
            scored.append((s, e))
    scored.sort(key=lambda x: -x[0])
    if not scored:
        return ToolResult(False, f"под «{query}» не подошло ни одно из {len(exts)} установленных. "
                                 f"Полный список — ext_list.")
    out = [f"под «{query}» подходят:"]
    out += [_fmt(e, True) for _, e in scored[:6]]
    out.append("\nКак использовать: ext_open(id=...) откроет страницу расширения во вкладке, "
               "дальше веди её через browser_page_snapshot / browser_act.")
    return "\n".join(out)


@T("ext_open",
   "Открыть страницу расширения (popup или настройки) как обычную вкладку — после этого её "
   "можно вести штатными инструментами браузера. Единственный способ «нажать» чужой аддон "
   "снаружи: Chrome не даёт вызывать API чужого расширения.",
   [P("id", desc="id расширения (32 буквы из ext_list)"),
    P("page", desc="popup|options|auto", required=False, default="auto",
      enum=["popup", "options", "auto"]),
    P("browser", desc="chrome|edge (для формирования URL)", required=False, default="")], C)
async def _(ctx, id, page, browser):
    exts = scan_extensions([browser.strip()] if browser.strip() else None)
    hit = next((e for e in exts if e["id"] == id.strip()), None)
    if not hit:
        hits = [e for e in exts if id.strip().lower() in e["name"].lower()]
        if len(hits) == 1:
            hit = hits[0]
        else:
            return ToolResult(False, f"расширение «{id}» не найдено. Список — ext_list.")
    target = ""
    if page in ("popup", "auto"):
        target = hit.get("popup") or ""
    if not target and page in ("options", "auto"):
        target = hit.get("options") or ""
    if not target:
        return ToolResult(False, f"у «{hit['name']}» нет ни popup, ни страницы настроек в манифесте. "
                                 f"Разрешения: {', '.join(hit.get('permissions', [])) or 'нет'}. "
                                 f"Такое расширение управляется только своей горячей клавишей — "
                                 f"см. ext_shortcuts.")
    url = f"chrome-extension://{hit['id']}/{target.lstrip('/')}"
    try:
        from .. import browserbus as bus
        tab = await bus.new_tab(url)
        return ToolResult(True, f"открыта страница расширения «{hit['name']}»: {url}\n"
                                f"вкладка {tab}. Дальше: browser_page_snapshot(tab={tab}) "
                                f"-> browser_act(index=N).",
                          data={"tab": str(tab), "url": url, "ext": hit["id"]})
    except Exception as e:
        return ToolResult(False, f"не удалось открыть {url}: {type(e).__name__}: {e}")


@T("ext_shortcuts",
   "Горячие клавиши расширений: какие команды назначены в профилях браузера. "
   "Нажатие комбинации дёргает расширение — это единственный способ вызвать чужой аддон "
   "без его API. Сама страница chrome://extensions/shortcuts CDP не открывается "
   "(Chrome запрещает навигацию на служебные страницы извне) — её нужно открыть руками.",
   [P("browser", desc="chrome|edge|brave (пусто = все)", required=False, default="")], C)
def _(ctx, browser):
    roots = browser_roots()
    if browser.strip():
        roots = {k: v for k, v in roots.items() if k == browser.strip()}
    known: list[str] = []
    scanned = 0
    for bname, root in roots.items():
        for prof in PROFILE_DIRS:
            p = os.path.join(root, prof, "Preferences")
            d = _read_json(p)
            if not d:
                continue
            scanned += 1
            cmds = ((d.get("extensions") or {}).get("commands") or {})
            for name, c in cmds.items():
                acc = (c or {}).get("accelerator") or ""
                if acc:
                    pretty = name.lstrip("_").replace("_", " ")
                    known.append(f"{bname}/{prof}: {pretty or name} -> {acc}")
    if not known:
        return (f"проверено профилей: {scanned}. Назначенных горячих клавиш не найдено — "
                f"значит расширения командами с клавиатуры не вызываются.\n"
                f"Список и назначение клавиш виден на chrome://extensions/shortcuts "
                f"(открой её вручную: CDP не пускают на служебные страницы Chrome).")
    return (f"проверено профилей: {scanned} · комбинаций: {len(known)}\n"
            + "\n".join("  " + k for k in known[:40])
            + "\n\nПолный список и переназначение — chrome://extensions/shortcuts. "
              "Нажать комбинацию от имени ОС можно тулзом keyboard_hotkey.")


@T("ext_risk_report",
   "Отчёт «стража ПК» по расширениям: какие аддоны имеют опасные разрешения "
   "(чтение cookie, истории, всех сайтов, перехват запросов, nativeMessaging, debugger) "
   "и что это значит. Ничего не удаляет и не отключает.",
   [P("min_risk", "integer", desc="минимальный уровень риска 0-3", required=False, default=2)], C, core=True)
def _(ctx, min_risk):
    exts = scan_extensions()
    lvl = max(0, min(3, int(min_risk or 2)))
    flagged = [e for e in exts if e.get("risk", 0) >= lvl]
    flagged.sort(key=lambda e: -e.get("risk", 0))
    head = (f"всего расширений: {len(exts)} · с риском >={lvl}: {len(flagged)}\n")
    if not flagged:
        return head + "опасных разрешений не найдено."
    lines = [head]
    for e in flagged:
        lines.append(_fmt(e, True))
    lines.append("\nЧто делать: отключить подозрительное расширение можно на "
                 "chrome://extensions (снимок + клик через browser_page_snapshot). "
                 "Удалять автоматически я не буду — это действие требует твоего решения.")
    return "\n".join(lines)

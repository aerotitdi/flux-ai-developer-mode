"""Тулзы таймеров и напоминаний (модуль 3 из ТЗ).

Раньше таймеры жили в app/tools/memory.py и лишь клали запись в memory.json —
срабатывание проверялось только в начале хода чата, поэтому «таймер не срабатывал».
Теперь всё ходит через app.timers.SCHED (фоновый поток), а при срабатывании:
звук + тост + SSE-событие в окно чата + очередь для следующего хода агента.

Инструменты (категория `timers`):
  timer_set        — универсальный: «300», «5 минут», «1ч30м», «14:30», «завтра 9:00»
  timer_at         — к конкретному моменту
  timer_every      — повторяющийся
  timer_list       — активные + недавние завершённые
  timer_next       — что сработает следующим и через сколько
  timer_cancel     — отменить
  timer_snooze     — отложить
  timer_pause      — пауза / timer_resume — снять с паузы
  timer_stop_sound — немедленно заглушить сирену
  timer_test_sound — проверка звукового канала
  notify_show      — показать уведомление (звук + тост) без таймера
"""
from __future__ import annotations

import datetime as dtm
import json
import time

from .. import notify, timers as TM
from .registry import P, REG, ToolResult

C = "timers"
T = REG.tool

_SOUNDS = ["alarm", "chime", "done", "error", "tick"]


def _ensure() -> TM.Scheduler:
    """Планировщик должен крутиться всегда — стартуем лениво, если main.py его не поднял."""
    if not TM.SCHED.running:
        TM.SCHED.start()
    return TM.SCHED


def _fmt(t: TM.Timer) -> str:
    return t.describe()


@T("timer_set",
   "Поставить таймер/напоминание. `when` понимает: 300 | '5 минут' | '1ч30м' | '14:30' | "
   "'завтра 9:00' | 'в пятницу 18:00' | 'каждые 10 минут'. При срабатывании — звук + окно уведомления. "
   "Используй для ЛЮБОЙ просьбы «напомни/засеки/поставь таймер/через N минут».",
   [P("label", desc="о чём напомнить (коротко, словами пользователя)"),
    P("when", desc="когда: '300', '5 минут', '1ч30м', '14:30', 'завтра 9:00', 'каждые 10 минут'",
      required=False, default=""),
    P("seconds", "integer", desc="задержка в секундах (если when не задан)", required=False, default=None),
    P("sound", "boolean", desc="звук при срабатывании", required=False, default=True),
    P("note", desc="доп. текст уведомления", required=False, default="")],
   C, core=True)
def _(ctx, label, when, seconds, sound, note):
    sched = _ensure()
    value = when if str(when).strip() else seconds
    if value in (None, "", 0):
        return ToolResult(False, "не указано время. Примеры: '300', '5 минут', '14:30', 'завтра 9:00'")
    w = TM.parse_when(value)
    if not w.ok:
        return ToolResult(False, w.error)
    try:
        t = sched.set_timer(w, label or "таймер", sound=bool(sound), note=note or "")
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    due = dtm.datetime.fromtimestamp(t.due)
    rep = f" (повтор каждые {TM.humanize(t.interval)})" if t.interval > 0 else ""
    return (f"таймер {t.id} поставлен: {t.label}\nсработает {due:%d.%m.%Y %H:%M:%S} "
            f"({TM.humanize(max(0, t.due - time.time()))}){rep}\n"
            f"звук: {'вкл' if t.sound else 'выкл'}. Я сам сообщу и проиграю звук, когда время придёт — "
            f"спрашивать «сработал ли» не нужно.")


@T("timer_at", "Поставить таймер на конкретный момент времени/дату",
   [P("label", desc="о чём напомнить"),
    P("at", desc="когда: '14:30', '2026-10-13 09:00', 'завтра 9:00', 'в пятницу 18:00', 'в 9 вечера'"),
    P("sound", "boolean", desc="звук при срабатывании", required=False, default=True)], C)
def _(ctx, label, at, sound):
    sched = _ensure()
    w = TM.parse_when(at)
    if not w.ok:
        return ToolResult(False, w.error)
    if w.delay is not None and w.at is None:
        return ToolResult(False, f"«{at}» похоже на длительность, а не на момент времени. "
                                 f"Используй timer_set или формат '14:30' / '2026-10-13 09:00'.")
    t = sched.set_timer(w, label or "таймер", sound=bool(sound))
    return f"таймер {t.id} на {dtm.datetime.fromtimestamp(t.due):%d.%m.%Y %H:%M:%S}: {t.label}"


@T("timer_every", "Повторяющийся таймер (будет срабатывать через равные интервалы)",
   [P("label", desc="о чём напоминать"),
    P("every", desc="интервал: '5 минут', '1ч', '30с'"),
    P("times", "integer", desc="сколько раз сработать (0 = бесконечно)", required=False, default=0),
    P("sound", "boolean", desc="звук", required=False, default=True)], C)
def _(ctx, label, every, times, sound):
    sched = _ensure()
    w = TM.parse_when(every)
    interval = w.interval or w.delay
    if not interval or interval <= 0:
        return ToolResult(False, f"не понял интервал «{every}». Примеры: '5 минут', '1ч', '30с'")
    w = TM.When(ok=True, interval=float(interval), repeats=int(times or 0),
                text=f"каждые {TM.humanize(interval)}")
    t = sched.set_timer(w, label or "таймер", sound=bool(sound))
    n = "бесконечно" if t.repeats_left < 0 else f"{t.repeats_left + 1} раз"
    return f"повторяющийся таймер {t.id}: {t.label} каждые {TM.humanize(t.interval)}, {n}"


@T("timer_list", "Список таймеров: активные (сколько осталось), на паузе и недавно сработавшие", [], C, core=True)
def _(ctx):
    _ensure()
    rows = [_fmt(t) for t in TM.SCHED.store.all()][-40:]
    if not rows:
        return "таймеров нет"
    nxt = TM.SCHED.next_fire()
    head = f"следующий: {nxt['id']} «{nxt['label']}» через {TM.humanize(nxt['in'])}" if nxt else "активных нет"
    return head + "\n" + "\n".join(rows)


@T("timer_next", "Что сработает следующим и через сколько", [], C)
def _(ctx):
    _ensure()
    nxt = TM.SCHED.next_fire()
    if not nxt:
        return "активных таймеров нет"
    return (f"{nxt['id']} «{nxt['label']}» сработает через {TM.humanize(nxt['in'])} "
            f"({dtm.datetime.fromtimestamp(nxt['due']):%d.%m.%Y %H:%M:%S})")


@T("timer_cancel", "Отменить таймер по id (или по части подписи)",
   [P("timer_id", desc="id таймера (t1, t2…) или часть подписи; 'all' = все активные")], C, core=True)
def _(ctx, timer_id):
    sched = _ensure()
    key = (timer_id or "").strip().lower()
    if key in ("all", "все", "*"):
        ids = [t.id for t in sched.store.active()]
        for i in ids:
            try:
                sched.cancel(i)
            except Exception:
                pass
        return f"отменено {len(ids)}: {', '.join(ids)}" if ids else "активных таймеров нет"
    try:
        t = sched.cancel(key)
    except KeyError as e:
        return ToolResult(False, str(e))
    return f"отменён {t.id}: {t.label}"


@T("timer_snooze", "Отложить сработавший/активный таймер",
   [P("timer_id", desc="id таймера"),
    P("delay", desc="на сколько отложить: '5 минут', '300', '1ч'", required=False, default="5 минут")], C)
def _(ctx, timer_id, delay):
    sched = _ensure()
    try:
        t = sched.snooze(timer_id, delay)
    except KeyError as e:
        return ToolResult(False, str(e))
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    return f"{t.id} отложен до {dtm.datetime.fromtimestamp(t.due):%H:%M:%S}: {t.label}"


@T("timer_pause", "Поставить таймер на паузу (остаток времени запоминается)",
   [P("timer_id", desc="id таймера")], C)
def _(ctx, timer_id):
    sched = _ensure()
    try:
        t = sched.pause(timer_id)
    except KeyError as e:
        return ToolResult(False, str(e))
    return f"{t.id} на паузе, осталось {TM.humanize(t.paused_left)}: {t.label}"


@T("timer_resume", "Снять таймер с паузы", [P("timer_id", desc="id таймера")], C)
def _(ctx, timer_id):
    sched = _ensure()
    try:
        t = sched.resume(timer_id)
    except KeyError as e:
        return ToolResult(False, str(e))
    return f"{t.id} снова идёт, сработает через {TM.humanize(max(0, t.due - time.time()))}"


@T("timer_stop_sound", "Немедленно выключить звук уведомления/сирены таймера", [], C)
def _(ctx):
    ok = notify.stop_sound()
    return "звук выключен" if ok else "звук и так не играл (или канал недоступен)"


@T("timer_test_sound", "Проиграть тестовый звук уведомления (проверка аудио-канала)",
   [P("sound", desc="alarm|chime|done|error|tick", required=False, default="alarm", enum=_SOUNDS)], C)
def _(ctx, sound):
    _ensure()
    path = notify.sound_path(sound)
    ch = notify.play(sound or "alarm", repeat=1, force=True)
    info = notify.selftest()
    return json.dumps({"sound": sound, "channel": ch, "wav": path, "diag": info},
                      ensure_ascii=False, default=str)


@T("notify_show", "Показать уведомление пользователю (плашка в окне + звук), без таймера",
   [P("title", desc="заголовок"),
    P("body", desc="текст", required=False, default=""),
    P("sound", desc="alarm|chime|done|error|tick|none", required=False, default="chime")], C)
def _(ctx, title, body, sound):
    silent = (sound or "").lower() in ("none", "off", "", "нет")
    ev = notify.notify("manual", title, body, sound="chime" if not silent else "alarm",
                       repeat=1, silent=silent)
    return f"уведомление показано (канал: {ev.get('channel')})"


@T("timer_status", "Диагностика подсистемы таймеров: поток жив, тики, срабатывания, каналы звука",
   [], C)
def _(ctx):
    sched = _ensure()
    snap = sched.snapshot()
    return json.dumps({
        "running": snap["running"],
        "stats": snap["stats"],
        "next": snap["next"],
        "timers": len(snap["timers"]),
        "unacked": len(snap["unacked"]),
        "storage": sched.store.path,
        "notify": notify.selftest(),
    }, ensure_ascii=False, default=str)

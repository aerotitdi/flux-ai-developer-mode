"""Чтение страницы: нумерованная карта интерактивных элементов + действие по индексу.

ЗАЧЕМ. Прежние browser_tab_click/type требовали от модели CSS-селектор, которого она
не знала и не могла угадать. Поэтому агент открывал страницу и вставал: «дальше»
означало «придумай селектор», а придумать его было неоткуда. Отсюда ровно тот симптом,
что описан в задаче — «открывает канал и не больше».

ЗДЕСЬ: `browser_page_snapshot` возвращает список вида
    [12] button "Пауза"  (виден)  y=412
    [13] link "MrMarmok — Охота на Разумных Животных"  href=/watch?v=...
а `browser_act(index=13)` жмёт именно этот элемент. Модель видит страницу как
понятный перечень кнопок и делает следующий шаг.

ТЕХНИЧЕСКИ:
  * элементы хранятся в `window.__fluxEls[idx]` — прямая ссылка на DOM-узел.
    Это надёжнее генерации CSS-селектора и работает ВНУТРИ shadow DOM
    (YouTube, Discord, VK — почти всё в кастомных элементах с теневыми корнями,
    куда `document.querySelector` не заглядывает);
  * обход рекурсивный по shadow roots (глубина до 6, лимит 12000 узлов);
  * перед каждым действием проверяется `el.isConnected` — если SPA перерисовала
    DOM, тулз честно скажет «элемент исчез, сделай новый снимок», а не кликнет в пустоту;
  * индексы живут до навигации. Это правильно: после перехода страница другая,
    и снимок надо снять заново (правило вписано в системный промпт агента).
"""
from __future__ import annotations

import json
import os
import time
from typing import Optional

from ..config import CONFIG
from .registry import P, REG, ToolResult

C = "page"
T = REG.tool

# ------------------------------------------------------------------ JS-ядро
_SNAPSHOT_JS = r"""
(() => {
  const MAX = __MAX__;
  const SHADOW = __SHADOW__;
  const vw = window.innerWidth, vh = window.innerHeight;
  const SEL = 'a[href],button,input:not([type=hidden]),select,textarea,summary,' +
              '[role],[onclick],[tabindex],[contenteditable="true"],label[for],[data-testid]';
  const SKIP_ROLE = new Set(['presentation','none','separator','generic']);
  const store = {};
  const items = [];
  let scanned = 0, truncated = false;

  const norm = s => (s || '').replace(/\s+/g, ' ').trim();

  function label(el) {
    let t = norm(el.getAttribute && (el.getAttribute('aria-label') ||
              el.getAttribute('title') || el.getAttribute('alt') ||
              el.getAttribute('placeholder') || el.getAttribute('name')));
    if (!t && el.value && typeof el.value === 'string') t = norm(el.value);
    if (!t) t = norm(el.textContent);
    if (!t && el.shadowRoot) t = norm(el.shadowRoot.textContent);
    return t.slice(0, 70);
  }

  function consider(el) {
    if (truncated || items.length >= MAX) { truncated = true; return; }
    let ok = false;
    try { ok = el.matches(SEL); } catch (e) { return; }
    if (!ok) return;
    const role = (el.getAttribute('role') || '').toLowerCase();
    if (SKIP_ROLE.has(role)) return;
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return;
    let r;
    try { r = el.getBoundingClientRect(); } catch (e) { return; }
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || parseFloat(st.opacity) === 0) return;
    const w = r.width, h = r.height;
    if (w < 1 || h < 1) return;
    const inVp = r.bottom > 0 && r.top < vh && r.right > 0 && r.left < vw;
    const idx = items.length + 1;
    try { el.setAttribute('data-flux-id', String(idx)); } catch (e) {}
    store[idx] = el;
    const tag = (el.tagName || '').toLowerCase();
    const it = {
      i: idx,
      tag: tag,
      role: role || (tag === 'a' ? 'link' : tag === 'button' ? 'button' :
                     tag === 'input' ? 'input' : tag === 'select' ? 'select' :
                     tag === 'textarea' ? 'textarea' : ''),
      type: el.getAttribute('type') || '',
      text: label(el),
      href: (tag === 'a' && el.getAttribute('href')) ? el.getAttribute('href').slice(0, 110) : '',
      vis: inVp,
      y: Math.round(r.top + window.scrollY),
      x: Math.round(r.left),
      w: Math.round(w), h: Math.round(h)
    };
    if (tag === 'input' || tag === 'textarea') {
      it.value = norm(el.value).slice(0, 40);
      it.ph = norm(el.getAttribute('placeholder')).slice(0, 40);
      if (!it.text && it.ph) it.text = it.ph;
      else if (it.ph && it.text && it.text.indexOf(it.ph) < 0) it.text += ' · ' + it.ph;
    }
    if (tag === 'video' || tag === 'audio') it.media = true;
    items.push(it);
  }

  // Медиа собирается ВО ВРЕМЯ обхода: document.querySelectorAll('video') не видит
  // плеер внутри shadow root, а именно так устроен плеер YouTube (ytd-player).
  const media = [];
  function noteMedia(el) {
    if (media.length >= 8) return;
    let r;
    try { r = el.getBoundingClientRect(); } catch (e) { r = {width: 0, height: 0}; }
    media.push({tag: el.tagName.toLowerCase(), paused: el.paused, ended: el.ended,
                muted: el.muted, volume: Math.round((el.volume || 0) * 100),
                t: Math.round(el.currentTime || 0), dur: Math.round(el.duration || 0),
                rate: el.playbackRate || 1, ready: el.readyState,
                src: (el.currentSrc || el.src || '').slice(0, 120),
                w: Math.round(r.width || 0), h: Math.round(r.height || 0)});
  }

  function walk(root, depth) {
    if (truncated || depth > 6) return;
    let els;
    try { els = root.querySelectorAll('*'); } catch (e) { return; }
    for (const el of els) {
      if (++scanned > 12000) { truncated = true; return; }
      consider(el);
      const tn = (el.tagName || '').toUpperCase();
      if (tn === 'VIDEO' || tn === 'AUDIO') noteMedia(el);
      if (SHADOW && el.shadowRoot) walk(el.shadowRoot, depth + 1);
      if (truncated) return;
    }
  }

  walk(document, 0);
  window.__fluxEls = store;
  let session = null;
  try {
    const ms = navigator.mediaSession;
    if (ms && ms.metadata) session = {state: ms.playbackState,
      title: ms.metadata.title || '', artist: ms.metadata.artist || '',
      album: ms.metadata.album || ''};
  } catch (e) {}

  const heads = [];
  for (const h of document.querySelectorAll('h1,h2,h3')) {
    const t = norm(h.textContent);
    if (t && heads.length < 14) heads.push(h.tagName.toLowerCase() + ': ' + t.slice(0, 80));
  }

  return {
    url: location.href, title: document.title,
    scroll: {y: Math.round(window.scrollY), max: Math.round(
      Math.max(0, (document.documentElement.scrollHeight || 0) - vh))},
    viewport: {w: vw, h: vh},
    counts: {elements: items.length, scanned: scanned, truncated: truncated,
             text: (document.body && document.body.innerText || '').length},
    headings: heads, media: media, mediaSession: session, items: items
  };
})()
"""


def _snap_js() -> str:
    return (_SNAPSHOT_JS
            .replace("__MAX__", str(int(CONFIG.settings.get("page_snapshot_max") or 220)))
            .replace("__SHADOW__", "true" if CONFIG.settings.get("page_shadow_dom", True) else "false"))


# ------------------------------------------------------------------ JS-действия
_ACT_JS = r"""
(async () => {
  const IDX = __IDX__;
  const ACT = __ACT__;
  const TEXT = __TEXT__;
  const KEY = __KEY__;
  const store = window.__fluxEls || {};
  const el = store[IDX];
  if (!el) return {ok: false, err: 'нет элемента с индексом ' + IDX +
                   ' — сделай browser_page_snapshot заново'};
  if (!el.isConnected) return {ok: false, err: 'элемент ' + IDX +
                   ' исчез из DOM (страница перерисовалась) — сделай снимок заново'};
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const describe = () => norm(el.getAttribute('aria-label') || el.title ||
                              el.textContent || el.tagName).slice(0, 60);

  try { el.scrollIntoView({block: 'center', inline: 'center'}); } catch (e) {}
  await new Promise(r => setTimeout(r, 60));

  if (ACT === 'click') {
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
      try {
        el.dispatchEvent(new MouseEvent(type, {bubbles: true, cancelable: true,
          view: window, clientX: x, clientY: y, button: 0}));
      } catch (e) {}
    }
    // часть сайтов слушает только реальный ввод — добиваем через CDP снаружи
    return {ok: true, act: 'click', el: describe(), needRealClick: true,
            x: Math.round(x), y: Math.round(y)};
  }
  if (ACT === 'type') {
    el.focus();
    if (TEXT === '' || TEXT === null) return {ok: false, err: 'пустой текст для ввода'};
    const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype
                                             : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value');
    if (setter && setter.set) setter.set.call(el, TEXT); else el.value = TEXT;
    el.dispatchEvent(new Event('input', {bubbles: true}));
    el.dispatchEvent(new Event('change', {bubbles: true}));
    return {ok: true, act: 'type', el: describe(), len: TEXT.length};
  }
  if (ACT === 'append') {
    el.focus();
    el.value = (el.value || '') + TEXT;
    el.dispatchEvent(new Event('input', {bubbles: true}));
    return {ok: true, act: 'append', el: describe(), value: norm(el.value).slice(0, 60)};
  }
  if (ACT === 'clear') {
    el.focus(); el.value = '';
    el.dispatchEvent(new Event('input', {bubbles: true}));
    el.dispatchEvent(new Event('change', {bubbles: true}));
    return {ok: true, act: 'clear', el: describe()};
  }
  if (ACT === 'select') {
    const opts = [...el.options || []].map(o => ({v: o.value, t: norm(o.textContent)}));
    const hit = opts.find(o => o.v === TEXT || o.t.toLowerCase() === (TEXT || '').toLowerCase())
             || opts.find(o => (TEXT || '').toLowerCase() && o.t.toLowerCase().includes((TEXT || '').toLowerCase()));
    if (!hit) return {ok: false, err: 'нет варианта «' + TEXT + '»', options: opts.slice(0, 20)};
    el.value = hit.v;
    el.dispatchEvent(new Event('change', {bubbles: true}));
    return {ok: true, act: 'select', el: describe(), picked: hit};
  }
  if (ACT === 'press') {
    el.focus();
    const k = KEY || 'Enter';
    const code = k.length === 1 ? 'Key' + k.toUpperCase() : k;
    for (const type of ['keydown', 'keypress', 'keyup']) {
      el.dispatchEvent(new KeyboardEvent(type, {bubbles: true, cancelable: true,
        key: k, code: code, keyCode: k === 'Enter' ? 13 : 0}));
    }
    return {ok: true, act: 'press', el: describe(), key: k};
  }
  if (ACT === 'focus' || ACT === 'hover') {
    el.focus();
    el.dispatchEvent(new MouseEvent('mouseover', {bubbles: true}));
    el.dispatchEvent(new MouseEvent('mouseenter', {bubbles: true}));
    return {ok: true, act: ACT, el: describe()};
  }
  if (ACT === 'media') {
    if (el.tagName !== 'VIDEO' && el.tagName !== 'AUDIO')
      return {ok: false, err: 'элемент ' + IDX + ' не медиа (' + el.tagName + ')'};
    const cmd = (KEY || 'toggle').toLowerCase();
    if (cmd === 'play') el.play();
    else if (cmd === 'pause') el.pause();
    else if (cmd === 'toggle') { el.paused ? el.play() : el.pause(); }
    else if (cmd === 'mute') el.muted = !el.muted;
    else if (cmd === 'restart') el.currentTime = 0;
    else if (cmd.startsWith('vol')) {
      const v = parseInt(cmd.replace(/\D/g, ''), 10);
      if (!isNaN(v)) el.volume = Math.max(0, Math.min(1, v / 100));
    }
    else if (cmd.startsWith('seek')) {
      const s = parseFloat(cmd.replace(/[^0-9.\-]/g, ''));
      if (!isNaN(s)) el.currentTime = Math.max(0, (el.currentTime || 0) + s);
    }
    return {ok: true, act: 'media', cmd: cmd, el: describe(),
            paused: el.paused, t: Math.round(el.currentTime), dur: Math.round(el.duration || 0),
            volume: Math.round(el.volume * 100), muted: el.muted};
  }
  return {ok: false, err: 'неизвестное действие: ' + ACT};
})()
"""

_FIND_JS = r"""
(() => {
  const NEEDLE = __NEEDLE__;
  const WANT = __WANT__;
  const store = window.__fluxEls || {};
  const n = NEEDLE.toLowerCase();
  const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const scored = [];
  for (const k of Object.keys(store)) {
    const el = store[k];
    if (!el || !el.isConnected) continue;
    const hay = [norm(el.textContent), norm(el.getAttribute('aria-label')),
                 norm(el.getAttribute('title')), norm(el.getAttribute('placeholder')),
                 norm(el.getAttribute('alt')), norm(el.value),
                 norm(el.getAttribute('href'))].filter(Boolean).join(' | ');
    if (!hay.includes(n)) continue;
    let s = 0;
    if (hay.startsWith(n)) s += 4;
    if (hay === n) s += 6;
    if (WANT && hay.includes(WANT.toLowerCase())) s += 3;
    s += Math.max(0, 4 - Math.abs(norm(el.textContent).length - n.length) / 12);
    scored.push({i: parseInt(k, 10), s: s, text: norm(el.textContent).slice(0, 60),
                 tag: el.tagName.toLowerCase()});
  }
  scored.sort((a, b) => b.s - a.s || a.i - b.i);
  return scored.slice(0, 8);
})()
"""


# ------------------------------------------------------------------ хелперы
async def _resolve_tab(tab: str, active: bool = False) -> tuple[str, dict]:
    """tab -> (id, target). Принимает id, часть URL, часть заголовка или active=true."""
    from .. import browserbus as bus
    from .. import browser_cdp as cdp
    if not await bus.ensure():
        raise RuntimeError(cdp.FRIENDLY_HINT)
    targets = await bus.targets()
    if not targets:
        raise RuntimeError("вкладок нет — открой страницу (browser_tab_open)")
    if active:
        t = next((x for x in targets if x.get("active")), targets[0])
        return str(t["id"]), t
    key = (tab or "").strip()
    if not key:
        t = next((x for x in targets if x.get("active")), targets[0])
        return str(t["id"]), t
    for t in targets:
        if str(t.get("id")) == key:
            return str(t["id"]), t
    kl = key.lower()
    hits = [t for t in targets if kl in (t.get("title") or "").lower()
            or kl in (t.get("url") or "").lower()]
    if len(hits) == 1:
        return str(hits[0]["id"]), hits[0]
    if len(hits) > 1:
        lst = "\n".join(f"  {t['id']} | {(t.get('title') or '')[:45]} | "
                        f"{(t.get('url') or '')[:70]}" for t in hits[:12])
        raise RuntimeError(f"по «{key}» найдено несколько вкладок — уточни id:\n{lst}")
    raise RuntimeError(f"вкладка не найдена: {key}")


async def _eval(tab: str, expr: str):
    from .. import browserbus as bus
    return await bus.evaluate(str(tab), expr)


def _fmt_snapshot(d: dict, limit: int) -> str:
    """JSON-снапшот -> компактный текст для модели (экономим токены)."""
    out = [f"СТРАНИЦА: {d.get('title', '')[:90]}", f"URL: {d.get('url', '')[:140]}"]
    c = d.get("counts", {})
    sc = d.get("scroll", {})
    out.append(f"прокрутка: {sc.get('y', 0)}/{sc.get('max', 0)} "
               f"({'вверху' if sc.get('y', 0) < 40 else 'внизу' if sc.get('y', 0) >= sc.get('max', 0) - 40 else 'середина'})"
               f" | вьюпорт {d.get('viewport', {}).get('w')}x{d.get('viewport', {}).get('h')}"
               f" | элементов {c.get('elements')} (обозрено {c.get('scanned')}"
               f"{', ОБРЕЗАНО' if c.get('truncated') else ''})")
    heads = d.get("headings") or []
    if heads:
        out.append("ЗАГОЛОВКИ: " + " · ".join(heads[:8]))

    media = d.get("media") or []
    if media:
        rows = []
        for m in media[:4]:
            st = "ПАУЗА" if m.get("paused") else ("КОНЕЦ" if m.get("ended") else "ИГРАЕТ")
            rows.append(f"{m.get('tag')} {st} {m.get('t', 0)}/{m.get('dur', 0)}с "
                        f"громк.{m.get('volume', 0)}%{' БЕЗ ЗВУКА' if m.get('muted') else ''}"
                        f" {m.get('w', 0)}x{m.get('h', 0)}")
        out.append("МЕДИА НА СТРАНИЦЕ: " + " | ".join(rows))
    ms = d.get("mediaSession")
    if ms and (ms.get("title") or ms.get("state")):
        out.append(f"МЕДИА-СЕССИЯ ОС: {ms.get('state', '?')} — {ms.get('title', '')} "
                   f"{ms.get('artist', '')}".strip())

    items = d.get("items") or []
    if not items:
        out.append("КЛИКАБЕЛЬНЫХ ЭЛЕМЕНТОВ НЕ НАЙДЕНО (страница пустая или нужен скролл)")
        return "\n".join(out)

    out.append(f"ЭЛЕМЕНТЫ (жми browser_act(index=N)):")
    shown = 0
    for it in items:
        if shown >= limit:
            out.append(f"… и ещё {len(items) - shown} (увеличь limit или прокрути страницу)")
            break
        bits = [f"[{it['i']}]", it.get("role") or it.get("tag")]
        if it.get("type"):
            bits.append(f"type={it['type']}")
        if it.get("text"):
            bits.append(f'"{it["text"]}"')
        if it.get("ph"):
            bits.append(f"placeholder=\"{it['ph']}\"")
        if it.get("value"):
            bits.append(f"value=\"{it['value']}\"")
        if it.get("href"):
            bits.append(f"-> {it['href']}")
        if not it.get("vis"):
            bits.append("(вне экрана)")
        bits.append(f"y={it.get('y')}")
        out.append("  " + " ".join(bits))
        shown += 1
    return "\n".join(out)


_MEDIA_JS = r"""
(() => {
  const CMD = __CMD__;
  // ВАЖНО: обходим shadow roots. Плеер YouTube/VK лежит внутри кастомного
  // элемента, и document.querySelectorAll('video') его не видит вовсе.
  const all = [];
  (function collect(root, depth) {
    if (depth > 6) return;
    let els; try { els = root.querySelectorAll('*'); } catch (e) { return; }
    for (const el of els) {
      const tn = (el.tagName || '').toUpperCase();
      if (tn === 'VIDEO' || tn === 'AUDIO') all.push(el);
      if (el.shadowRoot) collect(el.shadowRoot, depth + 1);
    }
  })(document, 0);
  const vids = all.filter(m => { try { return m.readyState > 0 || m.currentSrc || m.src }
                                 catch (e) { return false } })
    .sort((a, b) => {
      let ra = {width: 0, height: 0}, rb = {width: 0, height: 0};
      try { ra = a.getBoundingClientRect(); rb = b.getBoundingClientRect(); } catch (e) {}
      return (rb.width * rb.height) - (ra.width * ra.height);
    });
  const m = vids[0];
  const rep = () => m ? {found: true, tag: m.tagName.toLowerCase(), paused: m.paused,
                         t: Math.round(m.currentTime), dur: Math.round(m.duration || 0),
                         volume: Math.round(m.volume * 100), muted: m.muted, rate: m.playbackRate}
                      : {found: false};
  let sessionAct = null;
  try {
    const map = {play:'play', pause:'pause', toggle: null, next:'nexttrack',
                 prev:'previoustrack', stop:'stop'};
    if (map[CMD] !== undefined && navigator.mediaSession && navigator.mediaSession.setActionHandler)
      sessionAct = map[CMD];
  } catch (e) {}
  if (!m) return {...rep(), sessionAct, err: 'на странице нет media-элемента'};
  const base = CMD.replace(/[^0-9.\\-]/g, '');
  if (CMD === 'play') m.play();
  else if (CMD === 'pause') m.pause();
  else if (CMD === 'stop') { m.pause(); try { m.currentTime = 0 } catch (e) {} }
  else if (CMD === 'toggle') { m.paused ? m.play() : m.pause(); }
  else if (CMD === 'mute') m.muted = true;
  else if (CMD === 'unmute') m.muted = false;
  else if (CMD.startsWith('vol')) {
    const v = parseInt(base, 10); if (!isNaN(v)) m.volume = Math.max(0, Math.min(1, v / 100));
  } else if (CMD.startsWith('seek')) {
    const s = parseFloat(base); if (!isNaN(s)) m.currentTime = Math.max(0, (m.currentTime || 0) + s);
  } else if (CMD.startsWith('rate')) {
    const r = parseFloat(base); if (!isNaN(r) && r > 0 && r <= 8) m.playbackRate = r;
  } else if (CMD === 'next' || CMD === 'prev') {
    // у сайта свои кнопки «дальше/назад» — ищем их по подписи и жмём
    const want = CMD === 'next' ? ['next','вперёд','следующ'] : ['prev','назад','предыдущ'];
    // Кнопки плеера тоже внутри shadow root — ищем глубоко, иначе «дальше/назад»
    // на YouTube находятся не будут.
    const btns = [];
    (function collect(root, depth) {
      if (depth > 6) return;
      let els, all;
      try { els = root.querySelectorAll('button,[role=button],a,[aria-label]');
            all = root.querySelectorAll('*'); } catch (e) { return; }
      for (const el of els) btns.push(el);
      for (const el of all) if (el.shadowRoot) collect(el.shadowRoot, depth + 1);
    })(document, 0);
    const cands = btns.filter(el => {
      const t = (((el.getAttribute && el.getAttribute('aria-label')) || '') + ' ' +
                 (el.title || '') + ' ' + (el.textContent || '')).toLowerCase();
      return want.some(w => t.indexOf(w) >= 0);
    });
    if (cands.length) { cands[0].click(); return {...rep(), clickedButton: true}; }
    return {...rep(), err: 'кнопка «' + CMD + '» на странице не найдена'};
  } else return {...rep(), err: 'неизвестная команда: ' + CMD};
  return {...rep(), sessionAct};
})()
"""


# ------------------------------------------------------------------ ТУЛЗЫ
@T("browser_page_snapshot",
   "ГЛАВНЫЙ инструмент чтения страницы: возвращает НУМЕРОВАННУЮ карту всех кликабельных "
   "элементов (кнопки, ссылки, поля, вкладки), заголовки, прокрутку и состояние медиа. "
   "Обходит shadow DOM (YouTube/VK/Discord). Вызывай ПЕРЕД каждым действием и ПОСЛЕ него — "
   "индексы сбрасываются при навигации. Дальше жми browser_act(index=N).",
   [P("tab", desc="id вкладки / часть URL / часть заголовка (пусто = активная)",
      required=False, default=""),
    P("active", "boolean", desc="взять активную вкладку", required=False, default=False),
    P("limit", "integer", desc="сколько элементов показать", required=False, default=120),
    P("only_visible", "boolean", desc="только элементы в пределах экрана",
      required=False, default=False)], C, core=True)
async def _(ctx, tab, active, limit, only_visible):
    try:
        tid, info = await _resolve_tab(tab, active)
    except Exception as e:
        return ToolResult(False, str(e))
    try:
        d = await _eval(tid, _snap_js())
    except Exception as e:
        return ToolResult(False, f"не удалось прочитать страницу: {type(e).__name__}: {e}")
    if not isinstance(d, dict):
        return ToolResult(False, f"страница вернула не объект: {str(d)[:200]}")
    if only_visible:
        d["items"] = [i for i in (d.get("items") or []) if i.get("vis")]
    return ToolResult(True, _fmt_snapshot(d, max(1, int(limit or 120))),
                      data={"tab": tid, "url": d.get("url"), "title": d.get("title"),
                            "elements": len(d.get("items") or []),
                            "media": d.get("media"), "truncated": d.get("counts", {}).get("truncated")})


@T("browser_act",
   "Действие с элементом ПО ИНДЕКСУ из browser_page_snapshot (индекс надёжнее селектора "
   "и работает внутри shadow DOM). action: click|type|append|clear|select|press|focus|hover|media. "
   "Для media: key=play|pause|toggle|mute|restart|vol50|seek30|seek-30.",
   [P("index", "integer", desc="индекс элемента из снимка ([12] -> 12)"),
    P("action", desc="click|type|append|clear|select|press|focus|hover|media",
      required=False, default="click",
      enum=["click", "type", "append", "clear", "select", "press", "focus", "hover", "media"]),
    P("text", desc="текст для type/append/select", required=False, default=""),
    P("key", desc="клавиша для press (Enter, Tab, Escape…) или команда для media",
      required=False, default=""),
    P("tab", desc="id вкладки (пусто = активная)", required=False, default=""),
    P("real_click", "boolean", desc="добить клик реальным вводом через CDP (для сайтов, "
                                    "которые игнорируют синтетические события)",
      required=False, default=True)], C, core=True)
async def _(ctx, index, action, text, key, tab, real_click):
    try:
        tid, info = await _resolve_tab(tab, False)
    except Exception as e:
        return ToolResult(False, str(e))
    js = (_ACT_JS.replace("__IDX__", str(int(index)))
                 .replace("__ACT__", json.dumps(action or "click"))
                 .replace("__TEXT__", json.dumps(text or ""))
                 .replace("__KEY__", json.dumps(key or "")))
    try:
        r = await _eval(tid, js)
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    if not isinstance(r, dict):
        return ToolResult(False, f"страница вернула {str(r)[:200]}")
    if not r.get("ok"):
        extra = ""
        if r.get("options"):
            extra = "\nварианты: " + ", ".join(
                f"{o.get('t') or o.get('v')}" for o in r["options"][:20])
        return ToolResult(False, str(r.get("err")) + extra)

    # синтетический click многие плееры и SPA игнорируют — добиваем настоящим
    # вводом через CDP (Input.dispatchMouseEvent по координатам элемента)
    if action == "click" and real_click and r.get("needRealClick"):
        try:
            from .. import browserbus as bus
            from .. import browser_cdp as cdp
            from .. import bridge
            params = {"x": r.get("x", 0), "y": r.get("y", 0), "button": "left",
                      "clickCount": 1, "buttons": 1}
            if bridge.online():
                for kind in ("mousePressed", "mouseReleased"):
                    await bridge.call({"cmd": "cdp", "tabId": int(tid),
                                       "method": "Input.dispatchMouseEvent",
                                       "params": {**params, "type": kind,
                                                  "buttons": 1 if kind == "mousePressed" else 0}})
            else:
                ws = await bus._cdp_ws(str(tid))
                for kind in ("mousePressed", "mouseReleased"):
                    await cdp.cmd_target(ws, "Input.dispatchMouseEvent",
                                         {**params, "type": kind,
                                          "buttons": 1 if kind == "mousePressed" else 0})
            r["realClick"] = True
        except Exception as e:
            r["realClickError"] = f"{type(e).__name__}: {e}"

    txt = f"{action} -> [{index}] «{r.get('el', '')}»"
    if action == "media":
        txt += (f" | {'ПАУЗА' if r.get('paused') else 'ИГРАЕТ'} "
                f"{r.get('t', 0)}/{r.get('dur', 0)}с громк.{r.get('volume', 0)}%"
                f"{' БЕЗ ЗВУКА' if r.get('muted') else ''}")
    elif action == "select":
        txt += f" | выбрано: {r.get('picked')}"
    elif action == "type":
        txt += f" | введено символов: {r.get('len', 0)}"
    return ToolResult(True, txt, data={"tab": tid, **{k: v for k, v in r.items()
                                                      if k not in ("ok", "needRealClick")}})


@T("browser_act_text",
   "Найти элемент ПО ТЕКСТУ (надписи на кнопке/ссылке) и нажать его — когда снимок "
   "большой и индекс искать неудобно. Пример: «Пауза», «Войти», «Последнее видео».",
   [P("text", desc="что написано на элементе (подстрока, регистр не важен)"),
    P("action", desc="click|type|press|focus|media", required=False, default="click",
      enum=["click", "type", "append", "clear", "select", "press", "focus", "hover", "media"]),
    P("value", desc="текст для ввода / вариант select / команда media", required=False, default=""),
    P("prefer", desc="предпочесть элемент, содержащий это слово (button/link/input)",
      required=False, default=""),
    P("tab", desc="id вкладки (пусто = активная)", required=False, default="")], C, core=True)
async def _(ctx, text, action, value, prefer, tab):
    try:
        tid, info = await _resolve_tab(tab, False)
    except Exception as e:
        return ToolResult(False, str(e))
    js = (_FIND_JS.replace("__NEEDLE__", json.dumps(text or ""))
                  .replace("__WANT__", json.dumps(prefer or "")))
    try:
        hits = await _eval(tid, js)
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    if not hits:
        return ToolResult(False, f"на странице нет элемента с текстом «{text}». "
                                 f"Сделай browser_page_snapshot — возможно, нужен скролл "
                                 f"или текст написан иначе.")
    best = hits[0]
    res = await REG.tools["browser_act"].handler(ctx=ctx, index=best["i"], action=action,
                                                 text=value, key=value if action in ("press", "media") else "",
                                                 tab=str(tid), real_click=True)
    alts = ", ".join(f"[{h['i']}] {h['text'][:28]}" for h in hits[1:5])
    if alts:
        res.text += f"\nдругие кандидаты: {alts}"
    return res


@T("browser_scroll_find",
   "Крутить страницу, пока не появится нужный текст/элемент (бесконечные ленты, "
   "«показать ещё», комментарии). Возвращает снимок после нахождения.",
   [P("needle", desc="что ищем (текст элемента или просто текст на странице)"),
    P("max_scrolls", "integer", desc="сколько шагов прокрутки максимум", required=False, default=8),
    P("step_px", "integer", desc="шаг прокрутки", required=False, default=700),
    P("tab", desc="id вкладки (пусто = активная)", required=False, default="")], C)
async def _(ctx, needle, max_scrolls, step_px, tab):
    try:
        tid, info = await _resolve_tab(tab, False)
    except Exception as e:
        return ToolResult(False, str(e))
    js_find = _FIND_JS.replace("__NEEDLE__", json.dumps(needle or "")).replace("__WANT__", '""')
    n = max(1, min(60, int(max_scrolls or 8)))
    step = max(100, min(5000, int(step_px or 700)))
    for i in range(n + 1):
        try:
            hits = await _eval(tid, js_find)
        except Exception:
            hits = None
        if hits:
            b = hits[0]
            return ToolResult(True, f"найдено после {i} прокруток: [{b['i']}] "
                                    f"{b.get('tag')} «{b['text'][:60]}»\n"
                                    f"Жми browser_act(index={b['i']})",
                              data={"index": b["i"], "scrolls": i, "hits": hits})
        try:
            pos = await _eval(tid, f"(() => {{ window.scrollBy(0, {step});"
                                   f" return {{y: Math.round(window.scrollY),"
                                   f" max: Math.round(document.documentElement.scrollHeight - innerHeight)}}; }})()")
        except Exception as e:
            return ToolResult(False, f"прокрутка не удалась: {e}")
        if isinstance(pos, dict) and pos.get("y", 0) >= pos.get("max", 0) - 4 and i > 0:
            return ToolResult(False, f"дошли до конца страницы, «{needle}» не найдено. "
                                     f"Возможно, нужен клик по другой вкладке раздела.")
    return ToolResult(False, f"после {n} прокруток «{needle}» не найдено")


@T("browser_page_media_state",
   "Что сейчас играет на странице: все video/audio (пауза/время/громкость/длительность) "
   "+ медиа-сессия ОС (название трека, исполнитель).",
   [P("tab", desc="id вкладки (пусто = активная)", required=False, default="")], C)
async def _(ctx, tab):
    try:
        tid, info = await _resolve_tab(tab, False)
    except Exception as e:
        return ToolResult(False, str(e))
    js = """(() => {
      const out = [];
      const all = [];
      (function collect(root, depth) {
        if (depth > 6) return;
        let els; try { els = root.querySelectorAll('*'); } catch (e) { return; }
        for (const el of els) {
          const tn = (el.tagName || '').toUpperCase();
          if (tn === 'VIDEO' || tn === 'AUDIO') all.push(el);
          if (el.shadowRoot) collect(el.shadowRoot, depth + 1);
        }
      })(document, 0);
      for (const m of all) {
        let r = {width: 0, height: 0};
        try { r = m.getBoundingClientRect(); } catch (e) {}
        out.push({tag: m.tagName.toLowerCase(), paused: m.paused, ended: m.ended,
                  muted: m.muted, volume: Math.round(m.volume * 100),
                  t: Math.round(m.currentTime), dur: Math.round(m.duration || 0),
                  rate: m.playbackRate, w: Math.round(r.width), h: Math.round(r.height),
                  src: (m.currentSrc || m.src || '').slice(0, 140)});
      }
      let s = null;
      try { const ms = navigator.mediaSession;
            if (ms && ms.metadata) s = {state: ms.playbackState, title: ms.metadata.title,
                                        artist: ms.metadata.artist, album: ms.metadata.album};
      } catch (e) {}
      return {url: location.href, title: document.title, media: out, session: s};
    })()"""
    try:
        d = await _eval(tid, js)
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    media = (d or {}).get("media") or []
    if not media:
        return ToolResult(True, f"на странице нет video/audio ({(d or {}).get('url', '')[:100]})",
                          data=d or {})
    lines = [f"{m['tag']}: {'ПАУЗА' if m['paused'] else ('КОНЕЦ' if m['ended'] else 'ИГРАЕТ')} "
             f"{m['t']}/{m['dur']}с громк.{m['volume']}%{' без звука' if m['muted'] else ''} "
             f"{m['w']}x{m['h']} скорость={m['rate']}" for m in media]
    s = (d or {}).get("session")
    if s:
        lines.append(f"медиа-сессия ОС: {s.get('state')} — {s.get('title')} {s.get('artist')}")
    return ToolResult(True, "\n".join(lines), data=d or {})


@T("browser_media_control",
   "Управление плеером СТРАНИЦЫ: play|pause|toggle|next|prev|mute|vol50|seek30|seek-30|rate1.5. "
   "Работает и когда у сайта свои кнопки (YouTube, Яндекс Музыка, VK) — через mediaSession "
   "и элементы video/audio.",
   [P("command", desc="play|pause|toggle|next|prev|mute|unmute|vol0-100|seek±сек|rateX",
      required=False, default="toggle"),
    P("tab", desc="id вкладки (пусто = активная)", required=False, default="")], C, core=True)
async def _(ctx, command, tab):
    try:
        tid, info = await _resolve_tab(tab, False)
    except Exception as e:
        return ToolResult(False, str(e))
    cmd = (command or "toggle").strip().lower()
    js = _MEDIA_JS.replace("__CMD__", json.dumps(cmd))
    try:
        r = await _eval(tid, js)
    except Exception as e:
        return ToolResult(False, f"{type(e).__name__}: {e}")
    if not isinstance(r, dict) or not r.get("found"):
        return ToolResult(False, f"на странице нет плеера ({(r or {}).get('err', '')}). "
                                 f"Если музыка играет в другом приложении — используй media_system_control.")
    state = "ПАУЗА" if r.get("paused") else "ИГРАЕТ"
    return ToolResult(True, f"{cmd}: {state} {r.get('t', 0)}/{r.get('dur', 0)}с "
                            f"громк.{r.get('volume', 0)}%{' без звука' if r.get('muted') else ''}",
                      data={"tab": tid, **r})

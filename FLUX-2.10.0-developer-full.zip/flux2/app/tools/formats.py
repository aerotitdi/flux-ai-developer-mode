"""Форматы данных: JSON/CSV/XML/YAML/MD/regex/цвета (27)."""
from __future__ import annotations

import colorsys
import csv
import difflib
import io
import json
import re
from urllib.parse import urljoin

from .registry import P, REG

C = "formats"
T = REG.tool


@T("fmt_json_format", "Красиво отформатировать JSON", [P("text", desc="json")], C)
def _(ctx, text): return json.dumps(json.loads(text), ensure_ascii=False, indent=2)


@T("fmt_json_minify", "Сжать JSON в одну строку", [P("text", desc="json")], C)
def _(ctx, text): return json.dumps(json.loads(text), ensure_ascii=False, separators=(",", ":"))


@T("fmt_json_validate", "Валиден ли JSON (и ошибка с позицией)", [P("text", desc="json")], C)
def _(ctx, text):
    try:
        json.loads(text)
        return "валиден"
    except Exception as e:
        return f"НЕ валиден: {e}"


@T("fmt_json_query", "Путь в JSON вида a.b[0].c -> значение", [P("text", desc="json"), P("path", desc="путь")], C)
def _(ctx, text, path):
    cur = json.loads(text)
    for part in re.findall(r"[^\.\[\]]+|\[\d+\]", path):
        if part.startswith("["):
            cur = cur[int(part[1:-1])]
        else:
            cur = cur[part]
    return json.dumps(cur, ensure_ascii=False) if not isinstance(cur, str) else cur


@T("fmt_json_flatten", "Плоский JSON (ключи через точку)", [P("text", desc="json")], C)
def _(ctx, text):
    out = {}

    def walk(node, prefix=""):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{prefix}.{k}" if prefix else k)
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{prefix}[{i}]")
        else:
            out[prefix] = node
    walk(json.loads(text))
    return json.dumps(out, ensure_ascii=False, indent=1)


@T("fmt_json_merge", "Глубокое слияние двух JSON-объектов", [P("a", desc="json 1"), P("b", desc="json 2")], C)
def _(ctx, a, b):
    def merge(x, y):
        if isinstance(x, dict) and isinstance(y, dict):
            out = dict(x)
            for k, v in y.items():
                out[k] = merge(x.get(k), v) if k in x else v
            return out
        return y
    return json.dumps(merge(json.loads(a), json.loads(b)), ensure_ascii=False)


@T("fmt_json_to_csv", "JSON-массив объектов -> CSV", [P("text", desc="json array")], C)
def _(ctx, text):
    rows = json.loads(text)
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    w.writeheader()
    for r in rows:
        w.writerow(r)
    return buf.getvalue()


@T("fmt_csv_to_json", "CSV -> JSON-массив объектов", [P("text", desc="csv с заголовком")], C)
def _(ctx, text):
    return json.dumps(list(csv.DictReader(io.StringIO(text))), ensure_ascii=False)


@T("fmt_csv_parse", "Разобрать CSV в таблицу (список списков)", [P("text", desc="csv")], C)
def _(ctx, text):
    return json.dumps(list(csv.reader(io.StringIO(text))), ensure_ascii=False)


@T("fmt_yaml_to_json", "YAML (подмножество) -> JSON", [P("text", desc="yaml")], C)
def _(ctx, text):
    try:
        import yaml  # type: ignore
        return json.dumps(yaml.safe_load(text), ensure_ascii=False)
    except ImportError:
        # мини-парсер: отступы + key: value
        def parse(lines, i, indent):
            obj = {}
            while i < len(lines):
                line = lines[i]
                if not line.strip() or line.strip().startswith("#"):
                    i += 1
                    continue
                cur = len(line) - len(line.lstrip())
                if cur < indent:
                    break
                key, _, val = line.strip().partition(":")
                if val.strip():
                    v = val.strip()
                    obj[key] = json.loads(v) if v[0] in "[{\"" or v in ("true", "false", "null") else v
                    i += 1
                else:
                    sub, i = parse(lines, i + 1, cur + 2)
                    obj[key] = sub
            return obj, i
        res, _ = parse(text.split("\n"), 0, 0)
        return json.dumps(res, ensure_ascii=False)


@T("fmt_json_to_yaml", "JSON -> YAML (простой.indent-сериализатор)", [P("text", desc="json")], C)
def _(ctx, text):
    def emit(node, ind=0):
        pad = "  " * ind
        if isinstance(node, dict):
            return "".join(f"{pad}{k}:\n{emit(v, ind+1)}" if isinstance(v, (dict, list)) else f"{pad}{k}: {json.dumps(v, ensure_ascii=False)}\n" for k, v in node.items())
        if isinstance(node, list):
            return "".join(f"{pad}- {json.dumps(v, ensure_ascii=False)}\n" if not isinstance(v, (dict, list)) else f"{pad}-\n{emit(v, ind+1)}" for v in node)
        return f"{pad}{json.dumps(node, ensure_ascii=False)}\n"
    return emit(json.loads(text))


@T("fmt_xml_to_json", "XML -> JSON", [P("text", desc="xml")], C)
def _(ctx, text):
    import xml.etree.ElementTree as ET

    def conv(el):
        d = {f"@{k}": v for k, v in el.attrib.items()}
        kids = list(el)
        if kids:
            for c in kids:
                d.setdefault(c.tag, conv(c))
        elif el.text and el.text.strip():
            d["#text"] = el.text.strip()
        return d
    return json.dumps(conv(ET.fromstring(text)), ensure_ascii=False)


@T("fmt_json_to_xml", "JSON -> XML", [P("text", desc="json"), P("root", desc="корневой тег", required=False, default="root")], C)
def _(ctx, text, root):
    def emit(tag, node):
        if isinstance(node, dict):
            inner = "".join(emit(k, v) for k, v in node.items())
            return f"<{tag}>{inner}</{tag}>"
        if isinstance(node, list):
            return "".join(emit(tag, v) for v in node)
        return f"<{tag}>{node}</{tag}>"
    return f'<?xml version="1.0"?>' + emit(root, json.loads(text))


@T("fmt_md_to_html", "Markdown (подмножество) -> HTML", [P("text", desc="markdown")], C)
def _(ctx, text):
    out = []
    in_code = False
    for line in text.split("\n"):
        if line.strip().startswith("```"):
            out.append("</code></pre>" if in_code else "<pre><code>")
            in_code = not in_code
            continue
        if in_code:
            out.append(line)
            continue
        l = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", line)
        l = re.sub(r"\*(.+?)\*", r"<i>\1</i>", l)
        l = re.sub(r"`(.+?)`", r"<code>\1</code>", l)
        m = re.match(r"^(#{1,6})\s+(.*)", l)
        if m:
            out.append(f"<h{len(m.group(1))}>{m.group(2)}</h{len(m.group(1))}>")
        elif re.match(r"^[-*]\s+", l):
            out.append("<li>" + l[2:] + "</li>")
        else:
            out.append("<p>" + l + "</p>" if l.strip() else "")
    return "\n".join(out)


@T("fmt_html_to_md", "HTML -> Markdown (базово)", [P("text", desc="html")], C)
def _(ctx, text):
    s = re.sub(r"<h([1-6])[^>]*>([\s\S]*?)</h\1>", lambda m: "#" * int(m.group(1)) + " " + m.group(2), text)
    s = re.sub(r"<(b|strong)>([\s\S]*?)</\1>", r"**\2**", s)
    s = re.sub(r"<(i|em)>([\s\S]*?)</\1>", r"*\2*", s)
    s = re.sub(r"<li[^>]*>", "- ", s)
    s = re.sub(r"<[^>]+>", "", s)
    import html as _h
    return _h.unescape(s)


@T("fmt_regex_test", "Проверить regex на тексте (совпадения)", [P("text", desc="текст"), P("pattern", desc="regex")], C)
def _(ctx, text, pattern):
    ms = list(re.finditer(pattern, text))
    return f"совпадений={len(ms)}: " + ", ".join(m.group(0)[:60] for m in ms[:10])


@T("fmt_regex_extract", "Извлечь группы regex из текста", [P("text", desc="текст"), P("pattern", desc="regex с группами")], C)
def _(ctx, text, pattern):
    return json.dumps([list(m.groups()) or [m.group(0)] for m in re.finditer(pattern, text)][:50], ensure_ascii=False)


@T("fmt_regex_replace", "Замена по regex с группами $1/$2", [P("text", desc="текст"), P("pattern", desc="regex"), P("repl", desc="замена")], C)
def _(ctx, text, pattern, repl):
    return re.sub(pattern, repl.replace("$", "\\"), text)


@T("fmt_diff", "Построчный diff двух текстов", [P("a", desc="текст 1"), P("b", desc="текст 2")], C)
def _(ctx, a, b):
    return "\n".join(difflib.unified_diff(a.split("\n"), b.split("\n"), lineterm="", n=1))[:6000]


@T("fmt_color_hex_rgb", "HEX <-> RGB", [P("value", desc="#rrggbb или 'r,g,b'")], C)
def _(ctx, value):
    if value.startswith("#"):
        h = value.lstrip("#")
        r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
        return f"rgb({r}, {g}, {b})"
    r, g, b = (int(x) for x in value.split(","))
    return f"#{r:02x}{g:02x}{b:02x}"


@T("fmt_color_rgb_hsl", "RGB -> HSL и обратно", [P("value", desc="'r,g,b' или 'h,s,l'"), P("to_hsl", "boolean", desc="в hsl?", required=False, default=True)], C)
def _(ctx, value, to_hsl):
    parts = [float(x) for x in value.split(",")]
    if to_hsl:
        h, l, s = colorsys.rgb_to_hls(*[p / 255 for p in parts])
        return f"hsl({h*360:.0f}, {s*100:.0f}%, {l*100:.0f}%)"
    h, s, l = parts[0] / 360, parts[1] / 100, parts[2] / 100
    r, g, b = colorsys.hls_to_rgb(h, l, s)
    return f"rgb({r*255:.0f}, {g*255:.0f}, {b*255:.0f})"


@T("fmt_color_contrast", "Контрастность WCAG двух цветов", [P("fg", desc="#hex передний план"), P("bg", desc="#hex фон")], C)
def _(ctx, fg, bg):
    def lum(h):
        h = h.lstrip("#")
        c = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
        c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
        return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
    l1, l2 = lum(fg), lum(bg)
    return f"{(max(l1,l2)+0.05)/(min(l1,l2)+0.05):.2f}:1"


@T("fmt_url_resolve", "Разрешить относительный URL против базового", [P("base", desc="базовый url"), P("rel", desc="относительный")], C)
def _(ctx, base, rel): return urljoin(base, rel)


@T("fmt_lines_to_json_array", "Строки списка -> JSON-массив", [P("text", desc="строки")], C)
def _(ctx, text): return json.dumps([l for l in text.split("\n") if l.strip()], ensure_ascii=False)


@T("fmt_json_to_lines", "JSON-массив -> строки списка", [P("text", desc="json array")], C)
def _(ctx, text): return "\n".join(str(x) for x in json.loads(text))


@T("fmt_table_markdown", "JSON-массив объектов -> markdown-таблица", [P("text", desc="json array")], C)
def _(ctx, text):
    rows = json.loads(text)
    if not rows:
        return "пусто"
    cols = list(rows[0].keys())
    out = ["| " + " | ".join(cols) + " |", "| " + " | ".join("---" for _ in cols) + " |"]
    for r in rows:
        out.append("| " + " | ".join(str(r.get(c, "")) for c in cols) + " |")
    return "\n".join(out)


@T("fmt_base64_gzip", "Сжать gzip и в base64", [P("text", desc="текст")], C)
def _(ctx, text):
    import base64 as b64
    import gzip
    return b64.b64encode(gzip.compress(text.encode())).decode()


@T("fmt_base64_gzip_dec", "Распаковать base64+gzip", [P("text", desc="base64 gzip")], C)
def _(ctx, text):
    import base64 as b64
    import gzip
    return gzip.decompress(b64.b64decode(text)).decode("utf-8", "replace")

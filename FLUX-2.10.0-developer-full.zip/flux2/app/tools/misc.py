"""Мета-инструменты агента, анализ текста, управление режимом (19) + скиллы (6)."""
from __future__ import annotations

import json
import math
import re
import string
from collections import Counter

from .. import skills as SK
from ..config import CONFIG
from .registry import P, REG, ToolResult

C = "agent"
T = REG.tool


@T("agent_providers_list", "Список настроенных подключений провайдеров и моделей", [], C)
def _(ctx):
    out = []
    for c in CONFIG.connections:
        out.append(f"{c['id']} | {c.get('name')} | {c.get('base_url')} | модели: {', '.join(c.get('model_ids', [])[:6])}")
    return "\n".join(out) or "подключений нет — добавь в настройках"


@T("agent_set_model", "Переключить модель чата (connection_id + model)", [P("connection_id", desc="id подключения"), P("model", desc="имя модели")], C)
def _(ctx, connection_id, model):
    CONFIG.settings["model_ref"] = f"{connection_id}::{model}"
    CONFIG.save()
    return f"модель: {connection_id}::{model}"


@T("agent_set_search", "Переключить движок поиска", [P("engine", desc="движок", enum=["duckduckgo", "searxng", "bing", "google", "wikipedia", "brave", "off"])], C)
def _(ctx, engine):
    CONFIG.settings["search_engine"] = engine
    CONFIG.save()
    return f"поиск: {engine}"


@T("agent_think_status", "Текущий режим раздумий и что решает авто", [], C)
def _(ctx):
    return f"think_mode={CONFIG.settings.get('think_mode')} (auto: сам решаю, думать ли и гуглить ли)"


@T("agent_set_think", "Задать режим раздумий", [P("mode", desc="режим", enum=["auto", "off", "brief", "medium", "deep"])], C)
def _(ctx, mode):
    CONFIG.settings["think_mode"] = mode
    CONFIG.save()
    return f"think: {mode}"


@T("agent_tools_search", "Найти инструменты в своём каталоге (300+)", [P("query", desc="запрос"), P("k", "integer", desc="сколько", required=False, default=10)], C, core=True)
def _(ctx, query, k):
    from .registry import REG as R
    return "\n".join(f"{s.name}: {s.description}" for s in R.search(query, k))


@T("agent_tools_categories", "Категории инструментов и число в каждой", [], C)
def _(ctx):
    from .registry import REG as R
    cats = R.categories()
    return f"всего={sum(cats.values())}\n" + "\n".join(f"{k}: {v}" for k, v in sorted(cats.items()))


@T("agent_selftest", "Самотест: число инструментов, дубликаты, подключение, CDP", [], C)
async def _(ctx):
    from .registry import REG as R
    lines = [f"инструментов={len(R.tools)} дубликатов={len(R.tools) != len(set(R.tools))}"]
    conn = CONFIG.active_connection()
    lines.append(f"подключение={'есть: ' + conn['name'] if conn else 'НЕТ'}")
    try:
        from .. import browser_cdp as cdp
        v = await cdp.version()
        lines.append(f"cdp={v.get('Browser')}")
    except Exception:
        lines.append("cdp=не подключён")
    return "\n".join(lines)


@T("agent_help", "Справка по командам и возможностям FLUX 2.0", [], C)
def _(ctx):
    return ("FLUX 2.0: чат-окно (.exe) или консоль; микрофон браузерный; think-auto сам решает думать/гуглить; "
            "300+ тулзов (agent_tools_search); браузер по вкладкам/окнам (browser_*); код-движки (code_test); "
            "скиллы NVIDIA (skills_*); провайдеры по API-ключу как в Open WebUI.")


# --- анализ текста -----------------------------------------------------------
@T("misc_password_strength", "Оценка стойкости пароля", [P("password", desc="пароль")], C)
def _(ctx, password):
    score = 0
    pools = [string.ascii_lowercase, string.ascii_uppercase, string.digits, string.punctuation]
    for p in pools:
        if any(c in p for c in password):
            score += 1
    entropy = len(password) * math.log2(sum(len(p) for p in pools if any(c in p for c in password)) or 2)
    lvl = ["слабый", "слабый", "средний", "хороший", "сильный"][score]
    return f"{lvl}, энтропия ~{entropy:.0f} бит"


@T("misc_entropy_bits", "Информационная энтропия строки (бит/символ)", [P("text", desc="текст")], C)
def _(ctx, text):
    c = Counter(text)
    n = len(text) or 1
    return -sum((v / n) * math.log2(v / n) for v in c.values())


@T("misc_readability", "Читабельность текста (RU/EN: Флеш и средняя длина)", [P("text", desc="текст")], C)
def _(ctx, text):
    sents = re.split(r"[.!?]+\s", text)
    words = text.split()
    syll = sum(len(re.findall(r"[аеёиоуыэюяaeiouy]", w, re.I)) or 1 for w in words)
    if not words or not sents:
        return "пусто"
    fre = 206.835 - 1.015 * (len(words) / len(sents)) - 84.6 * (syll / len(words))
    return f"слов={len(words)} предложений={len(sents)} Flesch={fre:.1f}"


@T("misc_word_frequency", "Частотность слов текста (топ-N)", [P("text", desc="текст"), P("n", "integer", desc="топ", required=False, default=15)], C)
def _(ctx, text, n):
    c = Counter(w.lower().strip(string.punctuation) for w in text.split())
    return "\n".join(f"{w}: {k}" for w, k in c.most_common(n) if len(w) > 2)


@T("misc_keywords_extract", "Ключевые слова текста (TF без стоп-слов)", [P("text", desc="текст"), P("n", "integer", desc="топ", required=False, default=10)], C)
def _(ctx, text, n):
    from .registry import STOP
    c = Counter(w.lower().strip(string.punctuation) for w in text.split())
    return ", ".join(w for w, k in c.most_common(n * 3) if w not in STOP and len(w) > 3)[:n * 12]


@T("misc_ngrams", "N-граммы слов текста", [P("text", desc="текст"), P("n", "integer", desc="длина граммы", required=False, default=2), P("top", "integer", desc="топ", required=False, default=10)], C)
def _(ctx, text, n, top):
    ws = text.lower().split()
    grams = Counter(tuple(ws[i:i + n]) for i in range(len(ws) - n + 1))
    return "\n".join(" ".join(g) + f" x{k}" for g, k in grams.most_common(top))


@T("misc_summarize_extractive", "Выжимка текста: топ-предложения по весу слов", [P("text", desc="текст"), P("n", "integer", desc="предложений", required=False, default=3)], C)
def _(ctx, text, n):
    from .registry import STOP
    sents = re.split(r"(?<=[.!?])\s+", text)
    wc = Counter(w.lower() for w in re.findall(r"[a-zа-яё]{3,}", text.lower()) if w not in STOP)
    scored = []
    for s in sents:
        ws = [w for w in re.findall(r"[a-zа-яё]{3,}", s.lower()) if w not in STOP]
        scored.append((sum(wc.get(w, 0) for w in ws) / (len(ws) or 1), s))
    scored.sort(key=lambda x: -x[0])
    return "\n".join("- " + s.strip()[:220] for _, s in scored[:n])


@T("misc_language_guess", "Определить язык текста (по алфавиту/частым словам)", [P("text", desc="текст")], C)
def _(ctx, text):
    cyr = len(re.findall(r"[а-яё]", text, re.I))
    lat = len(re.findall(r"[a-z]", text, re.I))
    if cyr > lat:
        ru_words = len(re.findall(r"\b(и|в|не|что|он|на|я|с|со|как|а|то|все|она|так|его|но|да|ты|к|у|же|вы|за|бы|по)\b", text, re.I))
        uk = len(re.findall(r"\b(і|ї|є|що|як|це|той|вона|they)\b", text))
        return "ukrainian" if uk > ru_words // 3 else "russian"
    en = len(re.findall(r"\b(the|and|of|to|in|is|it|for|on|with)\b", text, re.I))
    de = len(re.findall(r"\b(und|der|die|das|ist|nicht|mit)\b", text, re.I))
    es = len(re.findall(r"\b(y|de|la|el|es|que|no)\b", text, re.I))
    return max([("english", en), ("german", de), ("spanish", es), ("latin-other", 0)], key=lambda x: x[1])[0]


@T("misc_emoji_strip", "Убрать эмодзи из текста", [P("text", desc="текст")], C)
def _(ctx, text):
    return re.sub(r"[\U0001F300-\U0001FAFF\U00002600-\U000027BF]", "", text)


@T("misc_ascii_chart", "ASCII-столбчатая диаграмма по парам 'label value'", [P("pairs", desc="строки 'label: value'")], C)
def _(ctx, pairs):
    vals = []
    for line in pairs.split("\n"):
        m = re.match(r"\s*(.+?)[:=\s]\s*(-?\d+(?:\.\d+)?)\s*$", line)
        if m:
            vals.append((m.group(1), float(m.group(2))))
    if not vals:
        return "нужны строки 'label: value'"
    mx = max(v for _, v in vals) or 1
    return "\n".join(f"{lbl[:18]:<18} {'#' * max(1, int(v / mx * 40))} {v:g}" for lbl, v in vals)


@T("misc_text_case_detect", "Определить стиль регистра строки", [P("text", desc="текст")], C)
def _(ctx, text):
    if text == text.upper():
        return "UPPER"
    if text == text.lower():
        return "lower"
    if text == text.title():
        return "Title"
    return "mixed"


@T("misc_braille", "Текст в шрифт Брайля (латиница)", [P("text", desc="текст")], C)
def _(ctx, text):
    tbl = dict(zip("abcdefghijklmnopqrstuvwxyz", "⠁⠉⠑⠛⠓⠊⠚⠅⠇⠍⠝⠕⠏⠟⠗⠎⠞⠥⠧⠺⠭⠽⠵"))
    return "".join(tbl.get(c, c) for c in text.lower())


@T("misc_morse_ru", "Русский текст в морзе (кириллица)", [P("text", desc="текст")], C)
def _(ctx, text):
    tbl = dict(zip("абвгдежзийклмнопрстуфхцчшщъыьэюя",
                   [".-", "-...", ".--", "--.", "-..", ".", "...-", "--..", "..", ".---", "-.-", ".-..",
                    "--", "-.", "---", ".--.", ".-.", "...", "-", "..-", "...-", ".--.-", "--.-", "--..",
                    "-..-", "-...", "-.--", "-..-", "..-..", "..--", ".-.-", "....", "..--.."]))
    return " / ".join(" ".join(tbl.get(c, c) for c in w) for w in text.lower().split())


@T("model_consult", "Спросить совет у ДРУГОЙ модели (напр. DeepSeek): независимое мнение/второе мнение по вопросу", [
    P("question", desc="вопрос консультанту"),
    P("model_hint", desc="подстрока имени модели (deepseek, gpt, qwen...) или пусто=авто", required=False, default=""),
    P("connection_id", desc="id подключения (пусто=авто)", required=False, default="")], C, core=True)
async def _(ctx, question, model_hint, connection_id):
    from .. import providers
    from ..config import CONFIG
    conn, model = None, ""
    hint = (model_hint or "").lower()
    if connection_id:
        conn = CONFIG.get_connection(connection_id)
    if conn is None:
        # ищем модель по подсказке во всех подключениях
        for c in CONFIG.connections:
            for m in c.get("model_ids") or []:
                if hint and hint in m.lower():
                    conn, model = c, m
                    break
            if conn:
                break
    if conn is None and hint:
        conn = CONFIG.active_connection()
        model = ""
    if conn is None:
        conn = CONFIG.active_connection()
    if conn is None:
        return ToolResult(False, "нет подключений для консультации")
    if not model:
        models = conn.get("model_ids") or []
        model = next((m for m in models if hint and hint in m.lower()), models[0] if models else "")
    if not model:
        return ToolResult(False, f"у подключения {conn.get('name')} нет моделей")
    res = await providers.chat_once(
        conn, model,
        [{"role": "system", "content": "Ты консультант второго мнения. Отвечай коротко, конкретно, шагами."},
         {"role": "user", "content": question}],
        think_mode="brief")
    return ToolResult(True, f"[консультант: {conn.get('name')}/{model}]\n{res['text'][:4000]}")


# --- скиллы -------------------------------------------------------------------
@T("skills_list", "Список скиллов: локальные bundled + каталог NVIDIA (build.nvidia.com/skills)", [], C, core=True)
async def _(ctx):
    ss = await SK.all_skills()
    return f"всего={len(ss)}\n" + "\n".join(f"- [{s.get('source')}] {s['name']}" for s in ss[:80])


@T("skills_search", "Поиск скилла по описанию/имени", [P("query", desc="запрос"), P("k", "integer", desc="сколько", required=False, default=8)], C)
async def _(ctx, query, k):
    return "\n".join(f"- {s['name']}: {s.get('description','')[:140]}" for s in await SK.search_skills(query, k)) or "не найдено"


@T("skills_show", "Показать тело скилла (инструкции)", [P("name", desc="имя скилла")], C)
async def _(ctx, name):
    for s in SK.bundled_skills():
        if s["name"] == name:
            return s["body"][:6000]
    s = await SK.fetch_skill(name)
    return s["body"][:6000] if s else f"скилл {name} не найден"


@T("skills_install", "Установить (скачать в кэш) скилл NVIDIA по имени", [P("name", desc="имя скилла")], C)
async def _(ctx, name):
    s = await SK.fetch_skill(name)
    return f"установлен: {name}" if s else "не найден в каталоге NVIDIA"


@T("skills_set_auto", "Включить/выключить авто-подбор скиллов", [P("on", "boolean", desc="вкл?")], C)
def _(ctx, on):
    CONFIG.settings["skills_auto"] = bool(on)
    CONFIG.save()
    return f"skills_auto={on}"


@T("skills_refresh", "Обновить индекс каталога NVIDIA skills", [], C)
async def _(ctx):
    idx = await SK.nvidia_index(force=True)
    return f"индекс обновлён: {len(idx)} скиллов"

﻿# FLUX 2.0 Desktop — инсталлер (Windows 10/11 x64).
#
# Что делает: проверяет Python, копирует приложение БЕЗ секретов, создаёт
# изолированный venv, ставит зависимости, собирает exe (PyInstaller или Nuitka),
# подписывает (если задан сертификат), вешает ярлыки, гоняет самотест и
# подготавливает активацию лицензии.
#
# Запуск:  .\install.ps1 [-InstallDir D:\flux2] [-Engine nuitka] [-SkipExe]
#                        [-Autostart] [-LicenseKey FLX2-...] [-LicenseServer URL]
#                        [-CertFile my.pfx] [-CertPass ...] [-Quiet]
param(
  [string]$InstallDir = "",
  [ValidateSet("pyinstaller", "nuitka", "none")]
  [string]$Engine = "pyinstaller",
  [switch]$SkipExe,        # не собирать exe (быстрая установка: ярлыки на pythonw)
  [switch]$Autostart,      # ярлык в автозапуск
  [string]$Python = "",    # путь к python.exe, если не находится сам
  [string]$LicenseKey = "",
  [string]$LicenseServer = "",
  [string]$CertFile = "",  # .pfx/.p12 для подписи Authenticode
  [string]$CertPass = "",
  [string]$CertThumbprint = "",  # или сертификат из хранилища (по отпечатку)
  [string]$TimestampUrl = "http://timestamp.digicert.com",
  [switch]$NoSign,
  [switch]$Quiet
)
$ErrorActionPreference = "Stop"
if ($SkipExe) { $Engine = "none" }
$script:LogLevel = if ($Quiet) { 1 } else { 0 }

function Log($m)  { Write-Host "[FLUX2] $m" -ForegroundColor Cyan }
function Warn($m) { Write-Host "[FLUX2] ВНИМАНИЕ: $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "[FLUX2] ОШИБКА: $m" -ForegroundColor Red; exit 1 }
function Step($m) { Write-Host ""; Log "== $m ==" }

# --- 0. КРИТИЧНО: приватный ключ вендора не должен попасть в поставку ---------
# Прежняя версия копировала каталог ЦЕЛИКОМ (robocopy /E) и утаскивала с собой
# license_server\keys\vendor_private.pem. Любой, кто поставил приложение,
# получал возможность выпускать себе лицензии. Теперь ключи лицензионного сервера
# исключены жёстко, и после копирования делается отдельная проверка.
$src = Split-Path -Parent $PSScriptRoot
$SECRET_DIRS  = @("license_server\keys", "license_server\data", ".git", ".venv", "venv",
                  "__pycache__", "node_modules", "dist", "build", "tests\jsdom\node_modules")
$SECRET_FILES = @("*.pem", "*.p12", "*.pfx", "*.key", "admin_token.txt", "license.json",
                  "*.pyc", ".gitignore", ".gitattributes", "package-lock.json")

Step "Проверка окружения"
$pyCode = "import sys; print(sys.version_info.major*100+sys.version_info.minor)"
if ($Python) { $pyExe = $Python; $pyRest = @() }
elseif (Get-Command py -ErrorAction SilentlyContinue) { $pyExe = "py"; $pyRest = @("-3") }
else { $pyExe = "python"; $pyRest = @() }
$verN = [int]((& $pyExe @pyRest -c $pyCode) | Select-Object -First 1).ToString().Trim()
if ($verN -lt 310) { Die "Нужен Python 3.10+ (найдено: $verN). Поставь с python.org." }
Log "Python OK ($verN)"

# публичный ключ вендора обязан быть встроен, иначе проверка лицензии не запустится
$vendorKey = Join-Path $src "app\_vendor_key.py"
if (-not (Test-Path $vendorKey)) {
  Warn "нет app\_vendor_key.py — клиент не сможет проверить лицензию."
  Warn "Сгенерируй ключи на машине сборки: python -m license_server.keygen init"
} else {
  Log "Публичный ключ вендора встроен: app\_vendor_key.py"
}
foreach ($bad in @("license_server\keys\vendor_private.pem")) {
  if (Test-Path (Join-Path $src $bad)) {
    Log "Найден приватный ключ вендора в исходниках — в поставку он НЕ копируется."
  }
}

if (-not $InstallDir) { $InstallDir = Join-Path $env:LOCALAPPDATA "Flux2" }
Log "Каталог установки: $InstallDir"

# --- 1. Копирование приложения ------------------------------------------------
Step "Копирование файлов"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$xdArgs = @(); foreach ($d in $SECRET_DIRS) { $xdArgs += (Join-Path $src $d) }
$xdArgs += (Join-Path $InstallDir ".venv")     # не перетирать уже созданный venv
$xfArgs = @(); foreach ($f in $SECRET_FILES) { $xfArgs += $f }
$rcArgs = @($src, $InstallDir, "/E", "/PURGE", "/NFL", "/NDL", "/NJH", "/NJS", "/NP",
            "/XD") + $xdArgs + @("/XF") + $xfArgs
& robocopy @rcArgs | Out-Null
if ($LASTEXITCODE -gt 7) { Die "robocopy завершился с кодом $LASTEXITCODE" }
Log "Скопировано (robocopy rc=$LASTEXITCODE)"

# контроль: секретов в каталоге установки быть не должно
$leaks = @()
foreach ($d in $SECRET_DIRS) {
  $p = Join-Path $InstallDir $d
  if ((Test-Path $p) -and ($d -ne ".venv")) { $leaks += $d }
}
$leaks += @(Get-ChildItem -Path $InstallDir -Recurse -File -Include `
  @("vendor_private.pem", "*.p12", "*.pfx", "admin_token.txt") -ErrorAction SilentlyContinue |
  ForEach-Object { $_.FullName.Substring($InstallDir.Length) })
if ($leaks.Count) {
  Warn "в каталоге установки остались секреты: $($leaks -join ', ')"
  foreach ($l in $leaks) {
    $p = if ([IO.Path]::IsPathRooted($l)) { $l } else { Join-Path $InstallDir $l }
    if (Test-Path $p) { Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue }
  }
  Log "секреты удалены из каталога установки"
} else {
  Log "Проверка на утечку секретов: чисто"
}

# --- 2. venv и зависимости ----------------------------------------------------
Step "Зависимости"
$venvPy = Join-Path $InstallDir ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
  Log "Создаю изолированный venv..."
  & $pyExe @pyRest -m venv "$InstallDir\.venv"
  if ($LASTEXITCODE -ne 0) { Die "не удалось создать venv" }
}
& $venvPy -m pip install --upgrade pip --quiet
& $venvPy -m pip install -r (Join-Path $InstallDir "requirements.txt") --quiet
if ($LASTEXITCODE -ne 0) { Die "pip install -r requirements.txt завершился ошибкой" }
Log "Зависимости установлены"

if ($Engine -eq "nuitka") {
  Log "Ставлю Nuitka (компиляция в нативный код)..."
  & $venvPy -m pip install nuitka ordered-set zstandard --quiet
} elseif ($Engine -eq "pyinstaller") {
  & $venvPy -m pip install pyinstaller --quiet
}

# --- 3. Сборка exe ------------------------------------------------------------
$exeChat = Join-Path $InstallDir "dist\FluxChat\FluxChat.exe"
$exeCon  = Join-Path $InstallDir "dist\FluxConsole\FluxConsole.exe"

if ($Engine -ne "none") {
  Step "Сборка exe ($Engine)"
  Push-Location $InstallDir
  if ($Engine -eq "nuitka") {
    # Nuitka компилирует Python в C -> нативный exe. Исходников в поставке нет
    # (защита от копирования), и эвристики АВ реагируют на такой exe спокойнее,
    # чем на PyInstaller-бандл: это обычный скомпилированный файл без пакера.
    if (-not (Test-Path "packaging\build_nuitka.bat")) { Pop-Location; Die "нет packaging\build_nuitka.bat" }
    & cmd /c "packaging\build_nuitka.bat"
    $exeChat = Join-Path $InstallDir "dist\FluxChat.exe"
    $exeCon  = Join-Path $InstallDir "dist\FluxConsole.exe"
  } else {
    if (-not (Test-Path "packaging\version_info.py")) { Warn "нет packaging\version_info.py — exe будет без метаданных разработчика" }
    $vi = if (Test-Path "packaging\version_info.py") { @("--version-file", "packaging\version_info.py") } else { @() }
    & .venv\Scripts\pyinstaller.exe --noconfirm --clean --name FluxChat --windowed `
      --icon "ui\flux.ico" @vi `
      --add-data "ui;ui" --add-data "skills_bundled;skills_bundled" `
      --exclude-module license_server `
      --hidden-import webview --hidden-import edge_tts --hidden-import websockets `
      --hidden-import cryptography --hidden-import cryptography.hazmat.primitives.asymmetric.ed25519 `
      main.py | Out-Null
    & .venv\Scripts\pyinstaller.exe --noconfirm --clean --name FluxConsole --console `
      --icon "ui\flux.ico" @vi `
      --add-data "ui;ui" --add-data "skills_bundled;skills_bundled" `
      --exclude-module license_server `
      --hidden-import websockets --hidden-import edge_tts --hidden-import cryptography `
      main.py | Out-Null
  }
  Pop-Location
  if (Test-Path $exeChat) { Log "Собрано: $exeChat" }
  else { Warn "exe не собрался — ярлыки укажут на pythonw (режим без сборки)" }
} else {
  Log "Сборка exe пропущена"
}

# --- 4. Подпись Authenticode --------------------------------------------------
if ((-not $NoSign) -and ($Engine -ne "none") -and (Test-Path $exeChat)) {
  Step "Цифровая подпись"
  $certArg = @()
  if ($CertFile)     { $certArg = @("-CertFile", $CertFile) }
  elseif ($CertThumbprint) { $certArg = @("-CertThumbprint", $CertThumbprint) }
  if ($CertPass)     { $certArg += @("-CertPass", $CertPass) }
  if ($certArg.Count) {
    Push-Location $InstallDir
    & .venv\Scripts\python.exe packaging\sign.py @certArg -TimestampUrl $TimestampUrl `
        -Targets $exeChat $exeCon
    Pop-Location
    if ($LASTEXITCODE -eq 0) { Log "Подписано" } else { Warn "подписать не удалось — exe останется неподписанным" }
  } else {
    Warn "сертификат не задан (-CertFile my.pfx -CertPass ... или -CertThumbprint ...)."
    Warn "Без подписи SmartScreen и антивирусы будут ругаться заметно чаще:"
    Warn "подписанный exe — самый действенный способ снизить ложные срабатывания."
    Warn "Самоподписанный сертификат брать НЕ стоит: SmartScreen на него строже."
  }
}

# --- 5. Ярлыки ----------------------------------------------------------------
Step "Ярлыки"
function New-Shortcut($path, $target, $sArgs, $workdir, $desc) {
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut($path)
  $lnk.TargetPath = $target
  if ($sArgs)   { $lnk.Arguments = $sArgs }
  if ($workdir) { $lnk.WorkingDirectory = $workdir }
  $lnk.Description = $desc
  $ico = Join-Path $InstallDir "ui\flux.ico"
  if (Test-Path $ico) { $lnk.IconLocation = "$ico, 0" }
  $lnk.Save()
}
$desk = [Environment]::GetFolderPath("Desktop")
if (Test-Path $exeChat) {
  New-Shortcut "$desk\FLUX 2.0.lnk" $exeChat "" "" "FLUX 2.0 Desktop — чат-окно"
  New-Shortcut "$desk\FLUX 2.0 Console.lnk" $exeCon "" "" "FLUX 2.0 — терминальный чат"
} else {
  New-Shortcut "$desk\FLUX 2.0.lnk" (Join-Path $InstallDir ".venv\Scripts\pythonw.exe") "main.py" $InstallDir "FLUX 2.0 Desktop — чат-окно"
  New-Shortcut "$desk\FLUX 2.0 Console.lnk" $venvPy "main.py --console" $InstallDir "FLUX 2.0 — терминальный чат"
}
Log "Ярлыки созданы на рабочем столе"
if ($Autostart) {
  Copy-Item "$desk\FLUX 2.0.lnk" (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup") -Force
  Log "Автозапуск включён"
}

# --- 6. Настройка лицензирования ----------------------------------------------
Step "Лицензирование"
$cfgDir = $InstallDir
$cfgFile = Join-Path $cfgDir "config.json"
$cfg = @{}
if (Test-Path $cfgFile) {
  try { $cfg = Get-Content $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable } catch { $cfg = @{} }
}
if (-not $cfg.ContainsKey("settings")) { $cfg["settings"] = @{} }
$cfg["settings"]["license_required"] = $true
if ($LicenseServer) { $cfg["settings"]["license_server_url"] = $LicenseServer.TrimEnd('/') }
elseif (-not $cfg["settings"].ContainsKey("license_server_url")) {
  Warn "сервер лицензий не задан. Укажи его: -LicenseServer https://lic.твойдомен"
  Warn "или впиши license_server_url в config.json вручную."
}
$cfg | ConvertTo-Json -Depth 8 | Set-Content $cfgFile -Encoding UTF8
Log "config.json: license_required=true$(if ($LicenseServer) { ", server=$LicenseServer" })"
if ($LicenseKey) {
  Log "Ключ лицензии передан — активация произойдёт при первом запуске"
  Set-Content -Path (Join-Path $cfgDir "activation.key") -Value $LicenseKey.Trim() -Encoding ASCII
} else {
  Log "Ключ не передан: при первом запуске откроется окно активации"
}

# --- 7. Самотест --------------------------------------------------------------
Step "Самотест"
Push-Location $InstallDir
& $venvPy main.py --selftest
$stRc = $LASTEXITCODE
Pop-Location
if ($stRc -ne 0) { Warn "самотест вернул $stRc" }

Write-Host ""
Log "Установка завершена: $InstallDir"
Log "Запуск: ярлык «FLUX 2.0» на рабочем столе"
Log "Первый шаг: ввести лицензионный ключ, затем шестерёнка → Подключения → добавить провайдер"
Log "Удаление: powershell -ExecutionPolicy Bypass -File installer\uninstall.ps1"
exit 0

"""Сквозной тест лицензирования: выдача -> активация -> второе устройство -> отзыв -> блокировка.

Поднимает НАСТОЯЩИЙ сервер лицензий (aiohttp) и гоняет клиент через HTTP,
а не через вызовы функций: проверяется весь путь, включая транспорт.

Запуск:  python tests/test_licensing.py
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import tempfile
import threading
import time

TMP = tempfile.mkdtemp(prefix="flux2-lic-")
os.environ["FLUX2_HOME"] = os.path.join(TMP, "client")
os.environ["FLUX_LICENSE_DB"] = os.path.join(TMP, "licenses.db")
# тест делает десятки активаций с одного IP — обычный лимит (8/мин) его бы zatrzymaл.
# Сам механизм рейт-лимита проверяется отдельно в шаге [12].
os.environ["FLUX_RL_ACTIVATE"] = "5000"
os.environ["FLUX_RL_HEARTBEAT"] = "5000"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import aiohttp                                        # noqa: E402
from aiohttp import web                               # noqa: E402

from license_server import crypto, keys, server as LS, store as store_mod  # noqa: E402
from app import licensing                             # noqa: E402
from app.config import CONFIG                         # noqa: E402

PORT = 8797
BASE = f"http://127.0.0.1:{PORT}"
ADMIN_TOKEN = "test-admin-token-123"
PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {detail}" if detail and not cond else ""))


def start_license_server():
    loop = asyncio.new_event_loop()

    def runner():
        asyncio.set_event_loop(loop)
        app = LS.build_app(os.environ["FLUX_LICENSE_DB"], ADMIN_TOKEN, heartbeat_hours=72)
        r = web.AppRunner(app)
        loop.run_until_complete(r.setup())
        loop.run_until_complete(web.TCPSite(r, "127.0.0.1", PORT).start())
        loop.run_forever()

    threading.Thread(target=runner, daemon=True).start()
    import socket
    for _ in range(120):
        try:
            with socket.create_connection(("127.0.0.1", PORT), timeout=0.25):
                return
        except OSError:
            time.sleep(0.05)
    raise RuntimeError("сервер лицензий не поднялся")


DB = None


def issue(days: int = 0, **kw) -> dict:
    """days=0 -> бессрочно, иначе срок отсчитывается от сейчас."""
    expires_at = 0 if days <= 0 else int(time.time()) + days * 86400
    return DB.issue(expires_at=expires_at, **kw)


async def post(session, path, payload, headers=None):
    async with session.post(BASE + path, json=payload, headers=headers or {}) as r:
        return r.status, await r.json()


async def scenario():
    global DB
    LS.RL_MAX_ACTIVATE = 5000        # на случай, если env прочитан до установки
    LS.RL._hits.clear()
    print("\n[0] Формат ключа и криптография")
    k = crypto.make_key()
    check("ключ вида FLX2-XXXXX-XXXXX-XXXXX-XXXXX",
          k.startswith("FLX2-") and len(k) == 28 and len(k.split("-")) == 5, k)
    check("в алфавите нет 0 1 I L O U",
          not any(c in crypto.ALPHABET for c in "01ILOU"), crypto.ALPHABET)
    check("нормализация принимает строчные и пробелы",
          crypto.normalize_key(k.lower().replace("-", " ")) == k)
    body = k.replace("FLX2-", "").replace("-", "")
    typo = "FLX2-" + body[:-2] + ("A" if body[-2] != "A" else "B") + body[-1]
    check("опечатка ловится контрольным символом", crypto.normalize_key(typo) is None, typo)
    check("подсказка объясняет причину", "контрольн" in crypto.key_hint(typo), crypto.key_hint(typo))
    check("маска скрывает середину ключа", "*****" in crypto.mask_key(k), crypto.mask_key(k))

    print("\n[1] Выдача ключа админкой")
    DB = store_mod.LicenseStore(os.environ["FLUX_LICENSE_DB"])
    rec = issue(plan="pro", customer="test@example.com", note="счёт 42",
                max_activations=1, offline_days=7)
    key = rec["key"]
    check("ключ выдан", bool(key), str(rec))
    check("в базе только хеш, самого ключа нет",
          DB.get_by_hash(crypto.key_hash(key)) is not None)
    with open(os.environ["FLUX_LICENSE_DB"], "rb") as f:
        blob = f.read()
    check("ключа нет в файле базы в открытом виде",
          key.replace("-", "").encode() not in blob, "ключ найдён в БД!")

    print("\n[2] Клиент: активация на ПЕРВОМ устройстве")
    CONFIG.settings["license_server_url"] = BASE
    CONFIG.settings["license_required"] = True
    CONFIG.save()

    # «железо» первого устройства подменяем: в контейнере отпечаток ненадёжный
    import app.hwid as HW
    real_hwid, real_var = HW.hwid, HW.hwid_variants
    DEVICE_A = "a1" * 32
    DEVICE_B = "b2" * 32
    HW.hwid = lambda raw=None: DEVICE_A
    HW.hwid_variants = lambda raw=None, max_variants=8: [DEVICE_A, "aa" * 32]
    licensing._load_state_orig = licensing._load_state

    st = licensing.status()
    check("до активации приложение не активировано", not st["ok"] and st["need_key"], str(st.get("reason")))

    res = await licensing.activate(key)
    check("активация успешна", bool(res.get("ticket")), str(res)[:200])
    check("билет сохранён на диск", os.path.exists(licensing.state_path()))
    v = licensing.validate()
    check("офлайн-проверка проходит БЕЗ сети", v["ok"], str(v.get("reason")))
    check("план прочитан из билета", v.get("plan") == "pro", str(v.get("plan")))
    check("клиент виден", v.get("customer") == "test@example.com", str(v.get("customer")))
    check("hwid записан", v.get("hwid") == DEVICE_A, str(v.get("hwid")))

    print("\n[3] Билет нельзя подделать или перенести")
    state = json.load(open(licensing.state_path(), encoding="utf-8"))
    forged = json.loads(json.dumps(state["ticket"]))
    forged["payload"]["plan"] = "ultimate"
    pub, verify = licensing._pub()
    check("подделка плана отвергается", not verify(pub, forged, DEVICE_A)[0])
    forged2 = json.loads(json.dumps(state["ticket"]))
    forged2["payload"]["expires"] = int(time.time()) + 10 * 365 * 86400
    check("подделка срока отвергается", not verify(pub, forged2, DEVICE_A)[0])
    # атакующий генерирует СВОЮ пару и переподписывает билет ею
    attacker_priv_pem, attacker_pub_pem = crypto.generate_vendor_keypair()
    attacker_priv = crypto.load_private(attacker_priv_pem)
    forged3 = json.loads(json.dumps(state["ticket"]))
    forged3["payload"]["expires"] = int(time.time()) + 10 * 365 * 86400
    forged3["payload"]["plan"] = "ultimate"
    forged3["sig"] = crypto.sign(attacker_priv, forged3["payload"])
    ok3, why3 = verify(pub, forged3, DEVICE_A)
    check("переподпись ЧУЖИМ приватным ключом не проходит", not ok3, why3)
    attacker_pub = crypto.load_public(attacker_pub_pem)
    check("…но СВОИМ ключом атакующий билет подписывает (значит публичный ключ "
          "действительно встроен в клиент, а не берётся из билета)",
          crypto.verify_ticket(attacker_pub, forged3, DEVICE_A)[0])
    check("билет вендора чужим публичным ключом НЕ проверяется",
          not crypto.verify_ticket(attacker_pub, state["ticket"], DEVICE_A)[0])
    ok_why = verify(pub, state["ticket"], DEVICE_B)
    check("билет другого устройства отвергается", not ok_why[0] and "другое устройство" in ok_why[1],
          ok_why[1])

    print("\n[4] ВТОРОЕ устройство: активация тем же ключом блокируется")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": DEVICE_B, "hwid_variants": [DEVICE_B],
                             "hwid_label": "второй ноутбук"})
    check("второе устройство получило отказ", stt == 409 and d.get("ok") is False,
          f"{stt} {d}")
    check("код ошибки already_bound", d.get("error") == "already_bound", str(d.get("error")))
    check("в отказе видно, кем занято", bool(d.get("bound")), str(d.get("bound")))
    check("текст объясняет, как перенести лицензию",
          "Деактивировать" in d.get("message", ""), d.get("message", "")[:120])

    print("\n[5] Повторная активация на СВОЁМ устройстве место не тратит")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": DEVICE_A, "hwid_variants": [DEVICE_A, "aa" * 32]})
    check("своё устройство переактивируется", stt == 200 and d.get("ok") is True, f"{stt} {d}")
    check("активация по-прежнему одна",
          len(DB.activations(crypto.key_hash(key), active_only=True)) == 1)

    print("\n[6] Замена ОДНОГО компонента железа не сбрасывает лицензию")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": "cc" * 32,
                             "hwid_variants": ["cc" * 32, "aa" * 32]})
    check("вариант отпечатка совпал -> активация прошла", stt == 200 and d.get("ok"),
          f"{stt} {d}")
    check("место ПЕРЕНЕСЕНО, а не потрачено второе", d.get("hwid_migrated") is True, str(d)[:200])
    check("активных мест по-прежнему ровно одно",
          len(DB.activations(crypto.key_hash(key), active_only=True)) == 1,
          str([a["hwid"][:10] for a in DB.activations(crypto.key_hash(key), active_only=True)]))
    check("место теперь привязано к новому отпечатку",
          DB.find_activation(crypto.key_hash(key), ["cc" * 32]) is not None)

    print("\n[7] Heartbeat и отзыв")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/heartbeat",
                            {"key": key, "hwid": DEVICE_A,
                             "ticket": json.load(open(licensing.state_path(),
                                                      encoding="utf-8"))["ticket"]})
    check("heartbeat отвечает ok", stt == 200 and d.get("ok") is True, f"{stt} {d}")
    check("heartbeat не сообщает об отзыве", d.get("revoked") is False)

    rv = DB.revoke(rec["key_id"], "возврат средств")
    check("ключ отозван в базе", rv["status"] == "revoked", rv["status"])

    try:
        await licensing.heartbeat(force=True)
        check("клиент узнал об отзыве", False, "исключения не было")
    except licensing.LicenseError as e:
        check("клиент узнал об отзыве", e.code == "revoked", e.code)
        check("сообщение об отзыве внятно для пользователя",
              "ОТОЗВАНА" in str(e) and "новый ключ" in str(e), str(e))
    v = licensing.validate()
    check("после отзыва приложение ЗАБЛОКИРОВАНО", not v["ok"], str(v.get("reason")))
    check("блокировка требует новый ключ", v.get("need_key") is True)

    print("\n[8] Отозванным ключом нельзя активироваться заново")
    async with aiohttp.ClientSession() as s:
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": DEVICE_A, "hwid_variants": [DEVICE_A]})
    check("активация отозванного ключа отклонена", stt == 403 and d.get("error") == "revoked",
          f"{stt} {d}")
    check("причина отзыва видна пользователю", "возврат средств" in d.get("message", ""),
          d.get("message", ""))

    print("\n[9] Снятие отзыва возвращает лицензию")
    DB.unrevoke(rec["key_id"])
    async with aiohttp.ClientSession() as s:
        # после шага 6 место перенесено на "cc"*32, поэтому DEVICE_A — уже чужое
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": DEVICE_A, "hwid_variants": [DEVICE_A]})
        check("после миграции отпечатка старое устройство считается чужим",
              stt == 409 and d.get("error") == "already_bound", f"{stt} {d}")
        cur = (DB.activations(crypto.key_hash(key), active_only=True) or [{}])[0].get("hwid")
        await post(s, "/v1/deactivate", {"key": key, "hwid": cur})
        stt, d = await post(s, "/v1/activate",
                            {"key": key, "hwid": DEVICE_A, "hwid_variants": [DEVICE_A]})
    check("после unrevoke и освобождения места активация снова работает",
          stt == 200 and d.get("ok"), f"{stt} {d}")
    await licensing.activate(key)          # клиент тоже должен снять блокировку
    check("клиент снова активен после снятия отзыва", licensing.validate()["ok"],
          str(licensing.validate().get("reason")))

    print("\n[10] Срок действия")
    rec2 = issue(plan="trial", days=30, max_activations=1)
    v2 = licensing.validate()
    check("бессрочная лицензия не имеет days_left", v2["ok"] and v2.get("days_left") is None,
          str(v2.get("days_left")))
    exp = DB.get_by_id(rec2["key_id"])
    check("пробная лицензия имеет срок", exp["expires_at"] > time.time(), str(exp["expires_at"]))
    left = round((exp["expires_at"] - time.time()) / 86400, 1)
    check("срок ≈ 30 дней", 29.5 <= left <= 30.1, str(left))
    DB.extend(rec2["key_id"], 0)
    check("extend(0) делает лицензию бессрочной",
          DB.get_by_id(rec2["key_id"])["expires_at"] == 0)

    print("\n[11] Перенос лицензии: деактивация освобождает место")
    async with aiohttp.ClientSession() as s:
        # после шага 6 место привязано к "cc"*32 — освобождаем именно его
        cur_hw = (DB.activations(crypto.key_hash(key), active_only=True) or [{}])[0].get("hwid")
        stt, d = await post(s, "/v1/deactivate", {"key": key, "hwid": cur_hw})
        check("деактивация успешна", stt == 200 and d.get("ok"), f"{stt} {d}")
        check("устройство освобождено",
              len(DB.activations(crypto.key_hash(key), active_only=True)) == 0,
              str([a["hwid"][:10] for a in DB.activations(crypto.key_hash(key),
                                                          active_only=True)]))
        stt2, d2 = await post(s, "/v1/activate",
                              {"key": key, "hwid": DEVICE_B, "hwid_variants": [DEVICE_B]})
        check("после деактивации ключ встал на ВТОРОЕ устройство",
              stt2 == 200 and d2.get("ok"), f"{stt2} {d2}")

    print("\n[12] Мусор на входе и защита от перебора")
    LS.RL_MAX_ACTIVATE = 6                  # ужесточаем, чтобы проверить сам механизм
    LS.RL._hits.clear()
    async with aiohttp.ClientSession() as s:
        for bad, want in [("", "invalid_key"), ("привет", "invalid_key"),
                          ("FLX2-00000-11111-22222-33333", "invalid_key"),
                          (crypto.make_key(), "invalid_key")]:
            stt, d = await post(s, "/v1/activate", {"key": bad, "hwid": "z" * 64})
            check(f"«{bad[:26]}» -> {want}", d.get("error") == want, f"{stt} {d}")
        stt, d = await post(s, "/v1/activate", {"key": key, "hwid": "short"})
        check("короткий hwid отклоняется", d.get("error") == "bad_hwid", f"{stt} {d}")
        # лимит задаётся FLUX_RL_ACTIVATE; проверяем, что он вообще есть
        limit = LS.RL_MAX_ACTIVATE
        blocked = False
        for _ in range(limit + 6):
            stt, d = await post(s, "/v1/activate", {"key": crypto.make_key(), "hwid": "z" * 64})
            if stt == 429:
                blocked = True
                break
        check(f"рейт-лимит на активации срабатывает (лимит {limit}/мин)", blocked)

    print("\n[13] Админка: авторизация и данные")
    H = {"Authorization": "Bearer " + ADMIN_TOKEN}
    async with aiohttp.ClientSession() as s:
        async with s.get(BASE + "/admin/api/stats", headers=H) as r:
            d = await r.json()
        check("статистика отдаётся с токеном", d.get("ok") is True, str(d)[:200])
        check("в статистике есть отозванные", d["stats"]["revoked"] >= 0)
        async with s.get(BASE + "/admin/api/stats") as r:
            check("без токена — 403", r.status == 403)
        async with s.get(BASE + "/admin/api/stats",
                         headers={"Authorization": "Bearer неверный"}) as r:
            check("с чужим токеном — 403", r.status == 403)
        async with s.get(BASE + "/admin/api/licenses", headers=H) as r:
            d = await r.json()
        check("список лицензий отдаётся", d.get("ok") and len(d["licenses"]) >= 2,
              str(len(d.get("licenses", []))))
        check("key_hash наружу НЕ отдаётся",
              all("key_hash" not in l for l in d["licenses"]))
        async with s.post(BASE + "/admin/api/issue", headers=H,
                          json={"n": 2, "plan": "standard", "days": 365}) as r:
            d = await r.json()
        check("выдача через API работает", d.get("ok") and len(d["issued"]) == 2, str(d)[:200])
        async with s.get(BASE + "/admin", headers=H) as r:
            html = await r.text()
        check("веб-админка отдаётся", r.status == 200 and "Управление лицензиями" in html,
              str(r.status))
        async with s.get(BASE + "/health") as r:
            d = await r.json()
        check("/health жив", d.get("ok") and d.get("service") == "flux-license", str(d)[:160])

    print("\n[14] Журнал аудита")
    aud = DB.audit_log(200)
    acts = {a["action"] for a in aud}
    for need in ("issue", "activate", "activate_denied", "revoke", "unrevoke",
                 "deactivate", "heartbeat", "rate_limit"):
        check(f"в аудите есть {need}", need in acts, str(sorted(acts)))
    check("в аудите пишутся IP и HWID",
          all("ip" in a and "hwid" in a for a in aud))

    HW.hwid, HW.hwid_variants = real_hwid, real_var


if __name__ == "__main__":
    print(f"FLUX 2.0 — тест лицензирования   ({TMP})")
    if not keys.exists():
        keys.init()
    start_license_server()
    t0 = time.time()
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(scenario())
    finally:
        loop.close()
        try:
            DB.close()
        except Exception:
            pass
    print(f"\n{'='*64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time()-t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    sys.exit(1 if FAIL else 0)

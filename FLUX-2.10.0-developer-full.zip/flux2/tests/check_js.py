"""Проверка синтаксиса всех встроенных JS-блоков через node --check.

JS внутри Python-строк не проверяется ни Python-компилятором, ни линтерами,
а ошибка там всплывает только в рантайме на странице пользователя. Поэтому
вытаскиваем блоки regex'ом, подставляем плейсхолдеры и гоняем через node.

Запуск:  python tests/check_js.py
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SUBS = {
    "__MAX__": "220", "__SHADOW__": "true", "__IDX__": "1",
    "__ACT__": json.dumps("click"), "__TEXT__": json.dumps("текст"),
    "__KEY__": json.dumps("Enter"), "__NEEDLE__": json.dumps("Пауза"),
    "__WANT__": json.dumps("button"), "__CMD__": json.dumps("toggle"),
}
BLOCK_RE = re.compile(r'^(_[A-Za-z_]*(?:JS|js)[A-Za-z_]*) = r?"""(.*?)"""$', re.M | re.S)

failures: list[str] = []
checked = 0


def check_file(path: str) -> None:
    global checked
    src = open(path, encoding="utf-8").read()
    blocks = BLOCK_RE.findall(src)
    if not blocks:
        return
    print(f"\n{os.path.relpath(path, ROOT)}: {len(blocks)} JS-блок(ов)")
    for name, body in blocks:
        js = body
        for k, v in SUBS.items():
            js = js.replace(k, v)
        left = set(re.findall(r"__[A-Z][A-Z0-9_]+__", js))
        if left:
            print(f"  FAIL {name}: не подставлены плейсхолдеры {sorted(left)}")
            failures.append(f"{path}:{name} placeholders")
            continue
        if not js.strip():
            print(f"  FAIL {name}: пустой блок")
            failures.append(f"{path}:{name} empty")
            continue
        fd, tmp = tempfile.mkstemp(suffix=".js")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(js)
        try:
            r = subprocess.run(["node", "--check", tmp], capture_output=True, text=True, timeout=30)
        except FileNotFoundError:
            print("  (node не установлен — пропускаем синтаксис, плейсхолдеры проверены)")
            os.unlink(tmp)
            return
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        checked += 1
        if r.returncode == 0:
            print(f"  OK   {name} ({len(js)} символов)")
        else:
            err = (r.stderr or "").strip().splitlines()
            print(f"  FAIL {name}:")
            for line in err[:8]:
                print("       " + line)
            failures.append(f"{path}:{name}")


def main() -> int:
    print("FLUX 2.0 — проверка встроенного JavaScript")
    for dirpath, dirnames, filenames in os.walk(os.path.join(ROOT, "app")):
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for fn in sorted(filenames):
            if fn.endswith(".py"):
                check_file(os.path.join(dirpath, fn))
    for fn in sorted(os.listdir(os.path.join(ROOT, "extension"))):
        if fn.endswith(".js"):
            p = os.path.join(ROOT, "extension", fn)
            r = subprocess.run(["node", "--check", p], capture_output=True, text=True)
            print(f"\nextension/{fn}: {'OK' if r.returncode == 0 else 'FAIL'}")
            if r.returncode:
                print(r.stderr[:600])
                failures.append(p)
    print(f"\n{'='*60}\nПроверено JS-блоков: {checked} · Ошибок: {len(failures)}")
    for f in failures:
        print("  -", f)
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

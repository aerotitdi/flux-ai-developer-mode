"""E2E: mock-провайдер OpenAI-совместимый + агент + SSE + тулзы."""
import asyncio
import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("FLUX2_HOME", "/tmp/flux2home")

from aiohttp import web

CALLS = {"n": 0}


async def models(request):
    return web.json_response({"data": [{"id": "mock-mini"}, {"id": "mock-big"}]})


async def chat(request):
    body = await request.json()
    msgs = body["messages"]
    has_tool = any(m["role"] == "tool" for m in msgs)
    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream"})
    await resp.prepare(request)

    async def emit(delta: dict, finish=None):
        obj = {"choices": [{"delta": delta, "finish_reason": finish}]}
        await resp.write(("data: " + json.dumps(obj) + "\n\n").encode())

    CALLS["n"] += 1
    if not has_tool:
        # проверяем, что тулзы ушли в запрос
        assert body.get("tools"), "нет tools в запросе"
        await emit({"content": "Считаю..."})
        await emit({"tool_calls": [{"index": 0, "id": "call_1",
                                     "function": {"name": "math_eval", "arguments": ""}}]})
        await emit({"tool_calls": [{"index": 0, "function": {"arguments": '{"expr": "2+2*4"}'}}]})
        await emit({}, finish="tool_calls")
    else:
        tool_msg = [m for m in msgs if m["role"] == "tool"][-1]["content"]
        assert "10" in tool_msg, f"тулз вернул не то: {tool_msg}"
        await emit({"content": f"Ответ: 10 (think={body.get('reasoning_effort', '?')})"})
        await emit({}, finish="stop")
    await resp.write(b"data: [DONE]\n\n")
    return resp


async def main():
    mock = web.Application()
    mock.router.add_get("/models", models)
    mock.router.add_get("/v1/models", models)
    mock.router.add_post("/chat/completions", chat)
    mock.router.add_post("/v1/chat/completions", chat)
    runner = web.AppRunner(mock)
    await runner.setup()
    await web.TCPSite(runner, "127.0.0.1", 8999).start()

    from app.config import CONFIG
    CONFIG.upsert_connection({
        "id": "mock", "name": "Mock Router", "base_url": "http://127.0.0.1:8999/v1",
        "auth": "Bearer", "api_key": "sk-test-123", "passthrough": ["thinking", "reasoning_effort"],
        "model_ids": ["mock-mini"],
    })
    CONFIG.settings["model_ref"] = "mock::mock-mini"
    CONFIG.settings["search_engine"] = "off"
    CONFIG.settings["skills_auto"] = False
    # этот тест проверяет агента и SSE, а не лицензирование: шлюз /api/chat
    # иначе ответил бы 403 и события чата просто не пришли бы
    CONFIG.settings["license_required"] = False
    CONFIG.save()

    from app.server import build_app
    runner2 = web.AppRunner(build_app())
    await runner2.setup()
    await web.TCPSite(runner2, "127.0.0.1", 8642).start()

    import aiohttp
    async with aiohttp.ClientSession() as s:
        async with s.get("http://127.0.0.1:8642/api/state") as r:
            st = await r.json()
            assert st["tools_count"] >= 300, st["tools_count"]
            print("state ok: tools =", st["tools_count"], "| conns =", len(st["connections"]))
        async with s.get("http://127.0.0.1:8642/") as r:
            html = await r.text()
            assert "Добавить соединение" in html and "Базовый адрес API" in html
            print("ui ok: модалка подключений на месте")
        events = []
        async with s.post("http://127.0.0.1:8642/api/chat",
                          json={"text": "сколько будет 2+2*4?", "sid": "t1"}) as r:
            async for raw in r.content:
                line = raw.decode().strip()
                if line.startswith("data:"):
                    events.append(json.loads(line[5:]))
    kinds = [e["type"] for e in events]
    print("events:", kinds)
    assert "think" in kinds and "tool_start" in kinds and "tool_end" in kinds and "done" in kinds
    done = [e for e in events if e["type"] == "done"][0]
    print("final:", done["text"])
    assert "Ответ: 10" in done["text"]
    # оффлайн-тулзы напрямую
    from app.tools import REG
    r1 = await REG.dispatch("convert_temperature", {"value": 100, "src": "C", "dst": "F"}, {})
    r2 = await REG.dispatch("text_slug", {"text": "Привет, Мир!"}, {})
    r3 = await REG.dispatch("code_test", {"code": "print(6*7)", "engine": "python"}, {})
    r4 = await REG.dispatch("run_javascript", {"code": "console.log(1+1)"}, {})
    print("convert:", r1.text, "| slug:", r2.text)
    print("code python:", r3.text.replace("\n", " | ")[:90])
    print("code node:", r4.text.replace("\n", " | ")[:90])
    assert r1.ok and r2.ok and r3.ok
    print("\nE2E OK: провайдер->агент->тулзы->SSE работают; вызовов модели:", CALLS["n"])
    await runner.cleanup()
    await runner2.cleanup()


asyncio.run(main())

"""Сквозной тест КЛИЕНТА лицензирования: сервер FLUX -> окно активации -> блокировка чата.

Поднимает настоящий aiohttp-сервер FLUX (app/server.py) вместе с настоящим сервером
лицензий (license_server) и проверяет весь путь пользователя:
  не активирован -> чат отвечает 403 -> ввёл ключ -> чат работает -> отозвали -> заблокирован.

Запуск:  python tests/test_licensing_client.py
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import threading
import time

TMP = tempfile.mkdtemp(prefix="flux2-liccli-")
os.environ["FLUX2_HOME"] = os.path.join(TMP, "client")
os.environ["FLUX_LICENSE_DB"] = os.path.join(TMP, "licenses.db")
os.environ["FLUX_RL_ACTIVATE"] = "5000"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import aiohttp                                     # noqa: E402
from aiohttp import web                            # noqa: E402

from license_server import keys, server as LS, store as store_mod   # noqa: E402
from app import licensing                          # noqa: E402
from app.config import CONFIG                      # noqa: E402
from app.server import build_app                   # noqa: E402

LIC_PORT, APP_PORT = 8795, 8794
LIC = f"http://127.0.0.1:{LIC_PORT}"
APP = f"http://127.0.0.1:{APP_PORT}"
PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {detail}" if detail and not cond else ""))


def _serve(make_app, port):
    loop = asyncio.new_event_loop()

    def runner():
        asyncio.set_event_loop(loop)
        r = web.AppRunner(make_app())
        loop.run_until_complete(r.setup())
        loop.run_until_complete(web.TCPSite(r, "127.0.0.1", port).start())
        loop.run_forever()

    threading.Thread(target=runner, daemon=True).start()
    import socket
    for _ in range(150):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.25):
                return
        except OSError:
            time.sleep(0.05)
    raise RuntimeError(f"сервер на {port} не поднялся")


DB = None


async def main():
    global DB
    print("\n[1] Сервер FLUX отдаёт состояние лицензии")
    async with aiohttp.ClientSession() as s:
        r = await s.get(APP + "/api/license")
        d = await r.json()
        check("/api/license -> 200", r.status == 200, str(r.status))
        check("не активировано", d.get("ok") is False and d.get("activated") is False, str(d)[:200])
        check("есть внятная причина", bool(d.get("reason")), str(d.get("reason")))
        hi = d.get("hwid_info") or {}
        check("отдан ЭФФЕКТИВНЫЙ отпечаток (тот, что уходит на сервер)",
              bool(hi.get("effective_hwid")), str(hi)[:250])
        check("отпечаток совпадает с тем, что использует активация",
              hi.get("effective_hwid") == licensing._hwid()[0])
        check("при ненадёжном железе есть предупреждение",
              (hi.get("reliable") is True) or bool(hi.get("warning")), str(hi)[:250])
        check("указан сервер лицензий", d.get("server", "").startswith("http"), str(d.get("server")))

        r = await s.get(APP + "/api/state")
        d = await r.json()
        check("лицензия видна в /api/state", "license" in d and d["license"].get("required") is True,
              str(list(d))[:200])

    print("\n[2] Без лицензии чат заблокирован (403)")
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/chat", json={"text": "привет", "sid": "t"})
        check("чат вернул 403", r.status == 403, str(r.status))
        d = await r.json()
        check("в ответе error=license", d.get("error") == "license", str(d)[:200])
        check("есть флаг need_key", d.get("need_key") is True, str(d))
        check("сообщение понятно пользователю", "актив" in d.get("message", "").lower()
              or "ключ" in d.get("message", ""), d.get("message", ""))

    print("\n[3] Окно активации присутствует в UI")
    async with aiohttp.ClientSession() as s:
        html = await (await s.get(APP + "/")).text()
    for probe in ['id="licOv"', 'id="licKey"', 'id="licGo"', '/api/license/activate',
                  '/api/license/deactivate', '/api/license/check', 'const Lic = {',
                  'Lic.blocked()', 'id="licInfo"', 'FLX2-XXXXX-XXXXX-XXXXX-XXXXX']:
        check(f"в HTML есть {probe!r}", probe in html)
    check("send() проверяет лицензию до отправки",
          "🔑 чат заблокирован: лицензия не активирована" in html)
    check("обработчик 403 по лицензии на месте", "d.error||''==='license'" in html.replace(" ", "")
          or "(d.error||'')==='license'" in html)

    print("\n[4] Активация через HTTP-эндпоинт клиента")
    DB = store_mod.LicenseStore(os.environ["FLUX_LICENSE_DB"])
    rec = DB.issue(plan="pro", customer="user@example.com", max_activations=1, offline_days=7)
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/activate",
                         json={"key": rec["key"].lower(), "server": LIC})
        d = await r.json()
        check("активация ok (ключ введён строчными)", d.get("ok") is True, str(d)[:300])
        check("план вернулся", d.get("plan") == "pro", str(d.get("plan")))

        r = await s.get(APP + "/api/license")
        d = await r.json()
        check("после активации статус ok", d.get("ok") is True and d.get("activated") is True,
              str(d)[:300])
        check("ключ показан замаскированным", "*****" in d.get("key_masked", ""),
              d.get("key_masked", ""))
        check("полный ключ в ответ НЕ уходит", rec["key"] not in json.dumps(d))
        check("hwid в статусе есть", bool(d.get("hwid")), str(d.get("hwid")))
        check("офлайн-окно посчитано", d.get("offline_days_left") is not None,
              str(d.get("offline_days_left")))

        check("validate() проходит офлайн", licensing.validate()["ok"])
        check("require() пускает приложение", licensing.require()[0])

    print("\n[5] Чат разблокирован")
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/chat", json={"text": "привет", "sid": "t2"})
        check("чат больше не 403", r.status != 403, str(r.status))

    print("\n[6] Мусорный ключ не активируется")
    async with aiohttp.ClientSession() as s:
        for bad in ["", "abc", "FLX2-00000-11111-22222-33333"]:
            r = await s.post(APP + "/api/license/activate", json={"key": bad})
            d = await r.json()
            check(f"ключ «{bad[:24]}» отклонён с объяснением",
                  d.get("ok") is False and bool(d.get("message")), str(d)[:200])

    print("\n[7] Отзыв лицензии блокирует клиент")
    DB.revoke(rec["key_id"], "тестовый отзыв")
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/check")
        d = await r.json()
        check("проверка сообщила об отзыве (403)", r.status == 403, str(r.status))
        check("сообщение про отзыв", "ОТОЗВАНА" in d.get("message", ""), d.get("message", "")[:200])

        r = await s.get(APP + "/api/license")
        d = await r.json()
        check("статус стал неактивным", d.get("ok") is False, str(d)[:200])
        check("причина — отзыв", "отозван" in d.get("reason", "").lower(), d.get("reason", ""))

        r = await s.post(APP + "/api/chat", json={"text": "привет", "sid": "t3"})
        check("чат снова заблокирован", r.status == 403, str(r.status))

    print("\n[8] Деактивация освобождает устройство")
    rec2 = DB.issue(plan="standard", max_activations=1)
    DB.unrevoke(rec["key_id"])
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/license/activate", json={"key": rec["key"], "server": LIC})
        check("после снятия отзыва активация проходит", (await r.json()).get("ok") is True)
        r = await s.post(APP + "/api/license/deactivate")
        d = await r.json()
        check("деактивация ok", d.get("ok") is True, str(d)[:200])
        r = await s.get(APP + "/api/license")
        d = await r.json()
        check("состояние лицензии сброшено", d.get("activated") is False, str(d)[:200])
        check("файл состояния удалён", not os.path.exists(licensing.state_path()))

    print("\n[9] Режим разработки (license_required=false) не блокирует")
    CONFIG.settings["license_required"] = False
    CONFIG.save()
    check("validate() пускает без билета", licensing.validate()["ok"],
          str(licensing.validate().get("reason")))
    async with aiohttp.ClientSession() as s:
        r = await s.post(APP + "/api/chat", json={"text": "привет", "sid": "t4"})
        check("чат не блокируется лицензией", r.status != 403, str(r.status))
    CONFIG.settings["license_required"] = True
    CONFIG.save()


if __name__ == "__main__":
    print(f"FLUX 2.0 — клиент лицензирования ({TMP})")
    if not keys.exists():
        keys.init()
    _serve(lambda: LS.build_app(os.environ["FLUX_LICENSE_DB"], "tok"), LIC_PORT)
    CONFIG.settings["license_server_url"] = LIC
    CONFIG.settings["license_required"] = True
    CONFIG.save()
    _serve(build_app, APP_PORT)
    t0 = time.time()
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(main())
    finally:
        loop.close()
        try:
            DB.close()
        except Exception:
            pass
    print(f"\n{'='*64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time()-t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    sys.exit(1 if FAIL else 0)

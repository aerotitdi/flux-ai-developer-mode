"""Сквозной тест: HTTP-сервер -> SSE /api/events -> сработавший таймер.

Проверяет всю цепочку, которой раньше просто не существовало:
планировщик (фоновый поток) -> шина событий -> SSE-канал -> клиент окна чата.

Запуск:  python tests/test_events_sse.py     (нужен aiohttp)
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import threading
import time

TMP = tempfile.mkdtemp(prefix="flux2-sse-")
os.environ["FLUX2_HOME"] = TMP
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import aiohttp                                     # noqa: E402
from aiohttp import web                            # noqa: E402

from app import timers as TM                       # noqa: E402
from app.server import build_app                   # noqa: E402

PORT = 8791
BASE = f"http://127.0.0.1:{PORT}"
PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {detail}" if detail and not cond else ""))


def start_server() -> asyncio.AbstractEventLoop:
    loop = asyncio.new_event_loop()

    def runner():
        asyncio.set_event_loop(loop)
        r = web.AppRunner(build_app())
        loop.run_until_complete(r.setup())
        site = web.TCPSite(r, "127.0.0.1", PORT)
        loop.run_until_complete(site.start())
        loop.run_forever()

    threading.Thread(target=runner, daemon=True).start()
    for _ in range(100):
        try:
            import socket
            with socket.create_connection(("127.0.0.1", PORT), timeout=0.2):
                break
        except OSError:
            time.sleep(0.05)
    return loop


async def scenario():
    print("\n[1] SSE-канал /api/events открывается и шлёт hello")
    timeout = aiohttp.ClientTimeout(total=None, sock_read=25)
    async with aiohttp.ClientSession(timeout=timeout) as s:
        async with s.get(f"{BASE}/api/events") as resp:
            check("GET /api/events -> 200", resp.status == 200, str(resp.status))
            check("Content-Type: text/event-stream",
                  resp.headers.get("Content-Type", "").startswith("text/event-stream"),
                  resp.headers.get("Content-Type", ""))

            received: list[dict] = []

            async def reader():
                async for raw in resp.content:
                    line = raw.decode("utf-8", "replace").strip()
                    if not line.startswith("data:"):
                        continue
                    try:
                        received.append(json.loads(line[5:].strip()))
                    except Exception:
                        pass

            task = asyncio.create_task(reader())
            await asyncio.sleep(0.5)
            check("первым приходит hello", bool(received) and received[0].get("type") == "hello",
                  str(received[:1]))

            print("\n[2] Таймер, созданный через REST, долетает до клиента")
            async with s.post(f"{BASE}/api/timers",
                              json={"action": "set", "when": "1", "label": "сквозной тест"}) as r:
                body = await r.json()
            check("POST /api/timers ok", body.get("ok") is True, str(body))
            tid = (body.get("timer") or {}).get("id")
            check("вернулся id таймера", bool(tid), str(body))

            await asyncio.sleep(0.4)
            check("событие timer_set пришло по SSE",
                  any(e.get("type") == "timer_set" and e.get("id") == tid for e in received),
                  str([e.get("type") for e in received]))

            print("\n[3] Ждём срабатывания: звук + уведомление приходят БЕЗ хода чата")
            deadline = time.time() + 8
            while time.time() < deadline and not any(
                    e.get("type") == "notify" and e.get("kind") == "timer_fired" for e in received):
                await asyncio.sleep(0.1)
            fired = [e for e in received if e.get("type") == "notify" and e.get("kind") == "timer_fired"]
            check("notify(timer_fired) доставлен по SSE", len(fired) == 1, str(received[-3:]))
            if fired:
                ev = fired[0]
                check("в событии есть метка таймера", ev.get("title", "").endswith("сквозной тест"),
                      str(ev.get("title")))
                check("в событии есть имя звука для Web Audio", bool(ev.get("sound")), str(ev.get("sound")))
                check("в событии есть data.timer_id (для кнопок «Отложить/Выключить»)",
                      (ev.get("data") or {}).get("timer_id") == tid, str(ev.get("data")))

            print("\n[4] GET /api/timers отражает состояние")
            async with s.get(f"{BASE}/api/timers") as r:
                snap = await r.json()
            check("snapshot ok", snap.get("ok") is True, str(snap)[:200])
            check("планировщик работает", snap.get("stats", {}).get("fired", 0) >= 1, str(snap.get("stats")))
            st = {t["id"]: t["state"] for t in snap.get("timers", [])}
            check(f"таймер {tid} в состоянии done", st.get(tid) == TM.STATE_DONE, str(st))

            print("\n[5] Управление таймером из UI")
            async with s.post(f"{BASE}/api/timers",
                              json={"action": "set", "when": "каждые 30 секунд",
                                    "label": "повторный"}) as r:
                b2 = await r.json()
            t2 = (b2.get("timer") or {}).get("id")
            check("повторяющийся таймер создан", b2.get("ok") and (b2["timer"]["interval"] == 30),
                  str(b2)[:200])
            async with s.post(f"{BASE}/api/timers", json={"action": "pause", "id": t2}) as r:
                check("pause работает", (await r.json()).get("timer", {}).get("state") == "paused")
            async with s.post(f"{BASE}/api/timers", json={"action": "resume", "id": t2}) as r:
                check("resume работает", (await r.json()).get("timer", {}).get("state") == "armed")
            async with s.post(f"{BASE}/api/timers", json={"action": "cancel", "id": t2}) as r:
                check("cancel работает", (await r.json()).get("timer", {}).get("state") == "cancelled")
            async with s.post(f"{BASE}/api/timers", json={"action": "cancel", "id": "нету"}) as r:
                check("cancel неизвестного -> 400 с текстом", r.status == 400
                      and "не найден" in (await r.json()).get("error", ""), str(r.status))

            print("\n[6] Звук: остановить и проверить")
            async with s.post(f"{BASE}/api/notify/stop") as r:
                check("POST /api/notify/stop ok", (await r.json()).get("ok") is True)
            async with s.get(f"{BASE}/api/notify/test?sound=chime") as r:
                b = await r.json()
            check("GET /api/notify/test вернул диагностику", b.get("ok") and "diag" in b, str(b)[:200])
            check("WAV реально создан", bool(b.get("wav")) and os.path.exists(b.get("wav") or ""),
                  str(b.get("wav")))

            print("\n[7] Два клиента получают одно и то же событие")
            async with s.get(f"{BASE}/api/events") as resp2:
                got2 = []

                async def reader2():
                    async for raw in resp2.content:
                        line = raw.decode("utf-8", "replace").strip()
                        if line.startswith("data:"):
                            try:
                                got2.append(json.loads(line[5:].strip()))
                            except Exception:
                                pass

                t2task = asyncio.create_task(reader2())
                await asyncio.sleep(0.4)
                async with s.post(f"{BASE}/api/timers",
                                  json={"action": "set", "when": "1", "label": "два клиента"}) as r:
                    b3 = await r.json()
                await asyncio.sleep(0.5)
                check("второй клиент тоже получил timer_set",
                      any(e.get("type") == "timer_set" and e.get("id") == b3["timer"]["id"]
                          for e in got2), str([e.get("type") for e in got2]))
                t2task.cancel()
                try:
                    await t2task
                except (asyncio.CancelledError, Exception):
                    pass
                async with s.post(f"{BASE}/api/timers",
                                  json={"action": "cancel", "id": b3["timer"]["id"]}):
                    pass

            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass


if __name__ == "__main__":
    print(f"FLUX 2.0 — сквозной тест таймеров через HTTP/SSE   (данные: {TMP})")
    t0 = time.time()
    start_server()
    TM.start()
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(scenario())
    finally:
        TM.stop()
        loop.close()
    print(f"\n{'='*64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time()-t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    sys.exit(1 if FAIL else 0)

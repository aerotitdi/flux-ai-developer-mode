"""Тесты модуля таймеров (пункт 3 ТЗ) и PNG-кодера скриншотов (пункт 1).

Запуск:  python tests/test_timers_screen.py
Не требует pytest и не требует Windows: Win32-путь проверяется по контракту
(корректность PNG-кодера и логика планировщика — общие для всех платформ).
"""
from __future__ import annotations

import os
import sys
import tempfile
import time

TMP = tempfile.mkdtemp(prefix="flux2-test-")
os.environ["FLUX2_HOME"] = TMP
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import events, notify                              # noqa: E402
from app import timers as TM                                # noqa: E402
from app.tools import REG                                   # noqa: E402
from app.tools import screen as SCR                         # noqa: E402

PASS, FAIL = [], []


def check(name: str, cond: bool, detail: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    print(f"  {'OK ' if cond else 'FAIL'} {name}" + (f"  <- {detail}" if detail and not cond else ""))


# ============================================================== 1. парсер
def test_parse_when():
    print("\n[1] parse_when — разбор «когда»")
    now = time.time()
    cases = [
        # (вход, ожидаемая задержка в секундах, допуск)
        (300, 300, 0.01), ("300", 300, 0.01), ("300с", 300, 0.01),
        ("5 минут", 300, 0.01), ("5м", 300, 0.01), ("5 мин", 300, 0.01),
        ("1ч30м", 5400, 0.01), ("1h30m", 5400, 0.01), ("90 sec", 90, 0.01),
        ("через 10 минут", 600, 0.01), ("in 10 minutes", 600, 0.01),
        ("2 часа", 7200, 0.01), ("полчаса", 1800, 0.01), ("1:30:00", 5400, 0.01),
        ("0.5", 0.5, 0.01), (0.5, 0.5, 0.01), ("3 дня", 259200, 0.5),
        ("напомнить через 45 секунд", 45, 0.01),
    ]
    for value, want, tol in cases:
        w = TM.parse_when(value, now=now)
        got = w.delay if w.ok else None
        check(f"«{value}» -> {want}с", w.ok and got is not None and abs(got - want) <= tol,
              f"ok={w.ok} delay={got} err={w.error}")

    # абсолютное время
    w = TM.parse_when("14:30", now=now)
    check("«14:30» -> абсолютное время", w.ok and w.at is not None and w.delay is None,
          f"{w}")
    if w.ok and w.at:
        import datetime as dtm
        d = dtm.datetime.fromtimestamp(w.at)
        check("«14:30» -> именно 14:30", (d.hour, d.minute) == (14, 30), f"{d:%H:%M}")
        check("«14:30» -> не в прошлом", w.at > now, f"at={w.at} now={now}")

    import datetime as _dt
    w = TM.parse_when("завтра 9:00", now=now)
    ok = w.ok and w.at is not None and w.delay is None
    if ok:
        d = _dt.datetime.fromtimestamp(w.at)
        ok = (d.date() == _dt.date.today() + _dt.timedelta(days=1)) and (d.hour, d.minute) == (9, 0)
    check("«завтра 9:00» -> завтра ровно в 09:00", ok,
          f"ok={w.ok} at={_dt.datetime.fromtimestamp(w.at) if w.at else None}")

    # повтор
    w = TM.parse_when("каждые 10 минут", now=now)
    check("«каждые 10 минут» -> interval=600", w.ok and w.interval == 600, f"{w}")
    w = TM.parse_when("каждые 5 минут 3 раза", now=now)
    check("«каждые 5 минут 3 раза» -> interval+repeats", w.ok and w.interval == 300 and w.repeats == 3,
          f"{w}")

    # ЛОВУШКА: «всё» не должно превращаться в «вс» (воскресенье)
    w = TM.parse_when("всё через 5 минут", now=now)
    check("«всё через 5 минут» -> 300с, не воскресенье",
          w.ok and w.delay == 300 and w.at is None, f"{w}")

    # ошибки
    for bad in ("", None, "qwerty", "0", "-5"):
        w = TM.parse_when(bad, now=now)
        check(f"«{bad}» -> ошибка с внятным текстом", (not w.ok) and bool(w.error), f"{w}")


# ============================================================== 2. планировщик
def test_scheduler_fires():
    print("\n[2] Планировщик: таймер СРАБАТЫВАЕТ сам, без хода чата")
    store = TM.TimerStore(os.path.join(TMP, "t1.json"))
    sched = TM.Scheduler(store, tick=0.05, stale_after=60)
    received = []
    sched.on_fire = received.append
    q_events = []
    events.EVENTS._subs.clear()
    import asyncio

    async def collect():
        q = await events.EVENTS.subscribe()
        return q

    loop = asyncio.new_event_loop()
    q = loop.run_until_complete(collect())
    sched.start()
    check("поток планировщика жив", sched.running)

    t = sched.set_timer(0.25, "чайник")
    check("set_timer вернул armed-таймер", t.state == TM.STATE_ARMED and t.due > time.time())

    async def pump(seconds: float):
        """Крутим loop: публикация из потока планировщика приходит через
        call_soon_threadsafe и выполняется только пока loop работает."""
        end = asyncio.get_event_loop().time() + seconds
        while asyncio.get_event_loop().time() < end and not received:
            await asyncio.sleep(0.02)

    loop.run_until_complete(pump(3.0))
    check("таймер сработал без участия чата", len(received) == 1,
          f"received={len(received)}")
    if received:
        check("в сработавшем таймере правильная метка", received[0]["label"] == "чайник")
        check("state после срабатывания = done", store.get(t.id).state == TM.STATE_DONE)
        check("fired_count = 1", received[0]["fired_count"] == 1)

    un = sched.unacked()
    check("очередь unacked отдаёт сработавший таймер", len(un) == 1 and un[0]["id"] == t.id)
    check("повторный unacked пуст (не дублируем в промпт)", sched.unacked() == [])

    # событие долетело до шины (а значит и до /api/events -> звук в окне)
    loop.run_until_complete(asyncio.sleep(0.15))     # даём _deliver-потоку опубликовать notify
    got = []
    while True:
        try:
            got.append(q.get_nowait())
        except asyncio.QueueEmpty:
            break
    kinds = [e.get("type") for e in got]
    check("в шине есть timer_set", "timer_set" in kinds, str(kinds))
    check("в шине есть notify(timer_fired)",
          any(e.get("type") == "notify" and e.get("kind") == "timer_fired" for e in got), str(kinds))
    loop.run_until_complete(asyncio.sleep(0))
    events.EVENTS.unsubscribe(q)
    loop.close()
    sched.stop()
    check("планировщик останавливается", not sched.running)


def test_repeat_and_count():
    print("\n[3] Повторяющийся таймер: ровно N срабатываний, без дрейфа")
    store = TM.TimerStore(os.path.join(TMP, "t2.json"))
    sched = TM.Scheduler(store, tick=0.02, stale_after=60)
    fired = []
    sched.on_fire = fired.append
    sched.start()
    w = TM.When(ok=True, interval=0.15, repeats=3, text="каждые 0.15с")
    t = sched.set_timer(w, "вода")
    check("repeats_left = 3", t.repeats_left == 3, str(t.repeats_left))
    time.sleep(1.4)
    sched.stop()
    check("сработал ровно 3 раза", len(fired) == 3, f"fired={len(fired)}")
    st = store.get(t.id)
    check("после 3 срабатываний state=done", st.state == TM.STATE_DONE, st.state)
    dues = [f["due"] for f in fired]
    if len(dues) == 3:
        gaps = [round(dues[i + 1] - dues[i], 3) for i in range(2)]
        check("интервалы без дрейфа (~0.15с)", all(0.10 <= g <= 0.35 for g in gaps), str(gaps))


def test_pause_snooze_cancel():
    print("\n[4] Пауза / snooze / отмена")
    store = TM.TimerStore(os.path.join(TMP, "t3.json"))
    sched = TM.Scheduler(store, tick=0.02, stale_after=60)
    fired = []
    sched.on_fire = fired.append
    t = sched.set_timer(0.3, "обед")
    sched.pause(t.id)
    check("пауза -> state=paused", store.get(t.id).state == TM.STATE_PAUSED)
    check("пауза запоминает остаток", store.get(t.id).paused_left > 0.1)
    sched.start()
    time.sleep(0.6)
    check("на паузе НЕ срабатывает", len(fired) == 0, f"fired={len(fired)}")
    sched.resume(t.id)
    time.sleep(0.8)
    check("после resume срабатывает", len(fired) == 1, f"fired={len(fired)}")

    t2 = sched.set_timer(5, "позже")
    sched.snooze(t2.id, 0.2)
    check("snooze сдвинул дедлайн", abs(store.get(t2.id).due - (time.time() + 0.2)) < 0.3)
    time.sleep(0.5)
    check("snooze-таймер сработал", len(fired) == 2, f"fired={len(fired)}")

    t3 = sched.set_timer(0.3, "отмени меня")
    sched.cancel(t3.id)
    check("cancel -> state=cancelled", store.get(t3.id).state == TM.STATE_CANCELLED)
    time.sleep(0.5)
    check("отменённый не срабатывает", len(fired) == 2, f"fired={len(fired)}")

    try:
        sched.cancel("нет-такого")
        check("cancel несуществующего -> KeyError", False)
    except KeyError:
        check("cancel несуществующего -> KeyError", True)
    sched.stop()


def test_persistence_and_recovery():
    print("\n[5] Хранение и восстановление после перезапуска")
    path = os.path.join(TMP, "t4.json")
    s1 = TM.TimerStore(path)
    sched1 = TM.Scheduler(s1, tick=0.05, stale_after=60)
    sched1.set_timer(0.3, "не проспи")          # успеет «протухнуть» к следующему запуску
    check("файл timers.json создан", os.path.exists(path))

    time.sleep(0.6)                              # имитируем: приложение было закрыто
    s2 = TM.TimerStore(path)
    fired2 = []
    sched2 = TM.Scheduler(s2, tick=0.05, stale_after=60, on_fire=fired2.append)
    check("таймер пережил перезагрузку хранилища", any(t.label == "не проспи" for t in s2.all()))
    sched2.start()
    time.sleep(0.6)
    check("просроченный (<stale) сработал сразу после рестарта", len(fired2) == 1,
          f"fired={len(fired2)}")
    sched2.stop()

    # старше stale_after -> «пропущен», без сирены
    s3 = TM.TimerStore(os.path.join(TMP, "t5.json"))
    sched3 = TM.Scheduler(s3, tick=0.05, stale_after=1)
    t = TM.Timer(id="old1", label="вчерашний", due=time.time() - 3600)
    s3.add(t)
    missed = []
    sub_q = None
    sched3._recover()
    check("свеже-просроченный >stale -> done (пропущен)", s3.get("old1").state == TM.STATE_DONE,
          s3.get("old1").state)
    check("пропущенный учтён в статистике", sched3.stats["missed"] == 1, str(sched3.stats))


# ============================================================== 3. тулзы
def test_tools_via_registry():
    print("\n[6] Вызов тулзов через REG.dispatch (как это делает модель)")
    import asyncio

    async def call(name, args):
        return await REG.dispatch(name, args, {"history": [], "session_stats": {}})

    loop = asyncio.new_event_loop()
    for name in ("timer_set", "timer_list", "timer_cancel", "timer_status",
                 "timer_next", "timer_stop_sound", "notify_show"):
        check(f"тулз зарегистрирован: {name}", name in REG.tools)

    # модель часто отдаёт СТРОКУ вместо числа — старый код на этом падал
    r = loop.run_until_complete(call("timer_set", {"label": "тест-строка", "seconds": "2"}))
    check("timer_set со строковым seconds='2' работает", r.ok, r.text)
    r = loop.run_until_complete(call("timer_set", {"label": "тест-when", "when": "5 минут"}))
    check("timer_set с when='5 минут' работает", r.ok, r.text)
    r = loop.run_until_complete(call("timer_set", {"label": "без времени"}))
    check("timer_set без времени -> понятная ошибка", not r.ok and "не указано время" in r.text, r.text)
    r = loop.run_until_complete(call("timer_set", {"label": "мусор", "when": "абракадабра"}))
    check("timer_set с мусором -> ошибка с примерами", not r.ok and "не понял" in r.text, r.text)
    r = loop.run_until_complete(call("timer_list", {}))
    check("timer_list показывает активные", r.ok and "тест-when" in r.text, r.text)
    r = loop.run_until_complete(call("timer_cancel", {"timer_id": "all"}))
    check("timer_cancel all", r.ok, r.text)
    r = loop.run_until_complete(call("timer_status", {}))
    check("timer_status отдаёт диагностику", r.ok and "running" in r.text, r.text[:200])
    loop.close()


# ============================================================== 4. звук
def test_sound():
    print("\n[7] Звуковой канал уведомления")
    for name in ("alarm", "chime", "done", "error", "tick"):
        p = notify.sound_path(name)
        ok = bool(p) and os.path.exists(p) and os.path.getsize(p) > 1000
        check(f"WAV «{name}» сгенерирован", ok, str(p))
        if ok:
            import wave
            with wave.open(p, "rb") as w:
                check(f"WAV «{name}» валиден (каналы/биты/длина)",
                      w.getnchannels() == 1 and w.getsampwidth() == 2
                      and w.getnframes() >= int(notify.SAMPLE_RATE * notify.duration_of(name) * 0.9),
                      f"{w.getparams()}")
    check("alarm длиннее tick", notify.duration_of("alarm") > notify.duration_of("tick"))
    ch = notify.play("chime", repeat=1, force=True)
    check("play() не падает и возвращает канал", ch in ("native", "beep", "none"), ch)
    check("stop_sound() не падает", isinstance(notify.stop_sound(), bool))


# ============================================================== 5. PNG-кодер
def test_png_encoder():
    print("\n[8] PNG-кодер скриншотов (то, чем Win32-кадр превращается в файл)")
    w, h = 8, 5
    # градиент BGRA: разные значения в каждом канале — проверяем порядок R/G/B
    buf = bytearray()
    for y in range(h):
        for x in range(w):
            buf += bytes([x * 8, y * 40, 255 - x * 8, 255])   # B, G, R, A
    data = SCR.encode_png(w, h, bytes(buf))
    check("сигнатура PNG", data[:8] == b"\x89PNG\r\n\x1a\n", data[:8].hex())

    import struct, zlib
    def chunks(blob):
        i, out = 8, []
        while i < len(blob):
            ln = struct.unpack(">I", blob[i:i + 4])[0]
            tag = blob[i + 4:i + 8]
            body = blob[i + 8:i + 8 + ln]
            crc = struct.unpack(">I", blob[i + 8 + ln:i + 12 + ln])[0]
            out.append((tag, body, crc))
            i += 12 + ln
        return out

    ch = {t: b for t, b, _ in chunks(data)}
    check("есть IHDR/IDAT/IEND", set(ch) == {b"IHDR", b"IDAT", b"IEND"}, str(set(ch)))
    iw, ih, depth, color = struct.unpack(">IIBB", ch[b"IHDR"][:10])
    check("IHDR: размер и 8-бит RGB", (iw, ih, depth, color) == (w, h, 8, 2), str((iw, ih, depth, color)))
    for tag, body, crc in chunks(data):
        check(f"CRC корректен для {tag.decode()}", zlib.crc32(tag + body) & 0xFFFFFFFF == crc)

    raw = zlib.decompress(ch[b"IDAT"])
    check("IDAT распаковывается в h строк по (1+3w) байт", len(raw) == h * (1 + 3 * w), str(len(raw)))
    row0 = raw[1:1 + 3 * w]
    # первый пиксель был B=0,G=0,R=255 -> в PNG обязан лежать R,G,B = 255,0,0
    check("порядок каналов BGRA->RGB правильный", tuple(row0[:3]) == (255, 0, 0), str(tuple(row0[:3])))
    check("фильтр строки = 0", all(raw[y * (1 + 3 * w)] == 0 for y in range(h)))

    # downscale: 8x5 с шагом 2 -> 4x5
    d2 = SCR.encode_png(w, h, bytes(buf), downscale=2)
    ch2 = {t: b for t, b, _ in chunks(d2)}
    iw2, ih2 = struct.unpack(">II", ch2[b"IHDR"][:8])
    check("downscale=2 уменьшает ширину вдвое", (iw2, ih2) == (4, 5), str((iw2, ih2)))

    path = SCR.save_png(os.path.join(TMP, "shot.png"), w, h, bytes(buf))
    check("save_png пишет файл на диск", os.path.exists(path) and os.path.getsize(path) == len(data))
    check("save_png не оставляет .tmp", not os.path.exists(path + ".tmp"))

    try:
        from PIL import Image
        im = Image.open(path)
        im.load()
        check("Pillow открывает наш PNG", im.size == (w, h) and im.mode == "RGB", str(im.size))
    except ImportError:
        print("  (Pillow не установлен — пропускаем кросс-проверку)")

    # большой кадр: производительность на 1920x1080
    big_w, big_h = 1920, 1080
    big = bytes(os.urandom(0)) + bytes((i % 256 for i in range(0, 0)))  # placeholder
    import random
    random.seed(1)
    row = bytes(random.getrandbits(8) for _ in range(big_w * 4))
    t0 = time.time()
    data = SCR.encode_png(big_w, big_h, row * big_h, downscale=2)
    dt = time.time() - t0
    check(f"1080p кодируется < 3с (факт {dt:.2f}с, {len(data)//1024} КБ)", dt < 3.0)


# ============================================================== 6. контракт тулзов экрана
def test_screen_tools_contract():
    print("\n[9] Контракт скриншот-тулзов")
    expected = ["screen_screenshot", "screen_capture_window", "screen_capture_region",
                "screen_capture_monitor", "screen_monitors_list", "screen_windows_list",
                "screen_active_window_screenshot", "screen_capture_delayed",
                "screen_capture_browser_tab", "screen_capture_page_element",
                "screen_size", "screen_pixel", "ocr_screen", "ocr_image", "screen_info"]
    for n in expected:
        check(f"тулз есть: {n}", n in REG.tools)

    spec = REG.tools["screen_screenshot"]
    check("screen_screenshot: все параметры необязательны (старые вызовы ctx-only не ломаются)",
          all(not p.required for p in spec.params), str([p.name for p in spec.params if p.required]))
    names = [p.name for p in spec.params]
    for need in ("target", "window", "hwnd", "monitor", "x", "y", "width", "height",
                 "include_cursor", "client_only", "downscale", "delay_s"):
        check(f"  параметр {need}", need in names)
    check("screen_screenshot остаётся core (всегда в выдаче модели)", spec.core)

    # PowerShell-фолбэк больше не использует $args
    check("в _PS_SHOOT нет $args (именно он ломал сохранение)", "$args" not in SCR._PS_SHOOT)
    check("в _PS_SHOOT путь приходит как $a0", "$a0" in SCR._PS_SHOOT)
    check("в _PS_OCR нет $args", "$args" not in SCR._PS_OCR)
    check("в _PS_OCR путь приходит как $a0", "$a0" in SCR._PS_OCR)

    # winproc: скрытый запуск
    from app import winproc
    if winproc.NT:
        kw = winproc.hidden_kwargs()
        check("hidden_kwargs даёт CREATE_NO_WINDOW", kw.get("creationflags") == winproc.CREATE_NO_WINDOW)
        check("hidden_kwargs даёт SW_HIDE в STARTUPINFO",
              kw["startupinfo"].wShowWindow == winproc.SW_HIDE)
    else:
        check("ps_quote экранирует апостроф", winproc.ps_quote("it's") == "'it''s'",
              winproc.ps_quote("it's"))
        check("ps_quote закрывает $-инъекцию", winproc.ps_quote("$env:X") == "'$env:X'")
        check("ps_command инлайнит аргументы как $a0/$a1",
              winproc.ps_command("f $a0 $a1", ["a", 2]).startswith("$a0='a'; $a1=2; "),
              winproc.ps_command("f $a0 $a1", ["a", 2]))
        check("ps() на не-Windows безопасен (возвращает '')", winproc.ps("Get-Date") == "")
        r = winproc.run(["echo", "скрытый-запуск-работает"], timeout=10)
        check("winproc.run работает", r.returncode == 0 and "скрытый" in r.stdout, r.stdout)

    # screen_info не должен падать ни на одной платформе
    import asyncio
    res = REG.tools["screen_info"].handler(ctx={})
    check("screen_info отрабатывает без падения", isinstance(res, str) and "shots" in res, str(res)[:200])


# ============================================================== 7. целостность реестра
def test_registry_integrity():
    print("\n[10] Целостность реестра инструментов")
    cats = REG.categories()
    check("нет дубликатов имён", len(REG.tools) == len(set(REG.tools)))
    check("категория timers существует", cats.get("timers", 0) >= 10, str(cats.get("timers")))
    check("категория screen существует", cats.get("screen", 0) >= 12, str(cats.get("screen")))
    check("старых таймеров в memory больше нет",
          all(n in REG.tools for n in ("mem_remember", "kv_set")) and
          REG.tools["timer_set"].category == "timers")
    for name, spec in REG.tools.items():
        try:
            sch = spec.schema()
            assert sch["function"]["name"] == name
            assert isinstance(sch["function"]["parameters"]["properties"], dict)
        except Exception as e:
            check(f"схема валидна: {name}", False, str(e))
    check("все схемы инструментов валидны", True)
    hits = [s.name for s in REG.search("поставь таймер напомни через 5 минут", k=8)]
    check("retrieval находит timer_set по «напомни через 5 минут»", "timer_set" in hits, str(hits))
    hits = [s.name for s in REG.search("сделай скриншот окна хром", k=8)]
    check("retrieval находит скриншот-тулзы", any(h.startswith("screen_") for h in hits), str(hits))


if __name__ == "__main__":
    print(f"FLUX 2.0 — тесты таймеров и скриншотов   (данные: {TMP})")
    t0 = time.time()
    for fn in (test_parse_when, test_scheduler_fires, test_repeat_and_count,
               test_pause_snooze_cancel, test_persistence_and_recovery,
               test_tools_via_registry, test_sound, test_png_encoder,
               test_screen_tools_contract, test_registry_integrity):
        fn()
    print(f"\n{'='*64}\nИТОГО: {len(PASS)} OK, {len(FAIL)} FAIL   ({time.time()-t0:.1f}с)")
    if FAIL:
        print("Провалено:")
        for f in FAIL:
            print("  -", f)
    sys.exit(1 if FAIL else 0)

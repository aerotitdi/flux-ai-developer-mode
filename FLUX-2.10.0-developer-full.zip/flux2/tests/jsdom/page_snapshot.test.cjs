/* Проверка встроенного JS на настоящем DOM (jsdom): карта страницы с shadow DOM,
   действия по индексу, поиск по тексту, управление плеером.

   Запуск:  node tests/jsdom/page_snapshot.test.cjs
   Нужен jsdom:  npm install jsdom  (в каталоге tests/jsdom)
*/
'use strict';
const fs = require('fs');
const path = require('path');
const { JSDOM } = require(path.join(__dirname, 'node_modules', 'jsdom'));

const ROOT = path.resolve(__dirname, '..', '..');

// --- вытаскиваем JS-блоки из app/tools/page.py -----------------------------
function extractJs(pyPath) {
  const src = fs.readFileSync(pyPath, 'utf8');
  const out = {};
  const re = /^(_[A-Za-z_]+JS) = r"""\n([\s\S]*?)\n"""$/gm;
  let m;
  while ((m = re.exec(src)) !== null) out[m[1]] = m[2];
  return out;
}
const PY = extractJs(path.join(ROOT, 'app', 'tools', 'page.py'));

const PASS = [], FAIL = [];
function check(name, cond, detail) {
  (cond ? PASS : FAIL).push(name);
  console.log(`  ${cond ? 'OK  ' : 'FAIL'} ${name}${(!cond && detail) ? '  <- ' + detail : ''}`);
}

// --- страница, похожая на YouTube: кастомные элементы с shadow DOM ----------
const HTML = `<!DOCTYPE html><html><head><title>MrMarmok — YouTube</title></head><body>
  <style>.hidden{display:none}</style>
  <ytd-masthead id="mast">
    <input id="search" type="search" placeholder="Введите запрос" aria-label="Поиск">
    <button id="btn-login" aria-label="Войти">Войти</button>
    <button class="hidden" id="btn-hidden">Невидимая</button>
    <a id="chan" href="/@MrMarmok/videos">Видео канала</a>
  </ytd-masthead>

  <ytd-video-player id="player"></ytd-video-player>

  <ytd-rich-grid id="grid"></ytd-rich-grid>

  <select id="quality"><option value="1080">1080p</option><option value="720">720p</option></select>

  <script>
    // плеер внутри shadow root — document.querySelector его не видит
    const vp = document.getElementById('player');
    const sr = vp.attachShadow({mode: 'open'});
    sr.innerHTML = '<video id="v" controls></video>'
      + '<button id="pause" aria-label="Пауза">Пауза</button>'
      + '<button id="next">Следующее видео</button>';
    const v = sr.querySelector('video');
    v.src = 'https://rr1.googlevideo.com/videoplayback?id=abc';
    Object.defineProperty(v, 'duration', {value: 620, configurable: true});
    Object.defineProperty(v, 'readyState', {value: 4, configurable: true});
    v.currentTime = 42;
    v.volume = 0.8;
    let _paused = false;
    Object.defineProperty(v, 'paused', { get(){ return _paused; },
                                         set(x){ _paused = !!x; }, configurable: true });
    v.play = function(){ _paused = false; this._played = true; };
    v.pause = function(){ _paused = true; };

    // лента видео тоже в shadow root
    const grid = document.getElementById('grid');
    const gsr = grid.attachShadow({mode: 'open'});
    gsr.innerHTML = [
      '<a class="vid" href="/watch?v=AAA">Охота на Разумных Животных</a>',
      '<a class="vid" href="/watch?v=BBB">Второе видео</a>',
      '<a class="vid" href="/watch?v=CCC">Третье видео</a>'
    ].join('');
    gsr.querySelectorAll('.vid').forEach(a => {
      a.addEventListener('click', () => { window.__clicked = a.getAttribute('href'); });
    });
    sr.querySelector('#pause').addEventListener('click', () => { window.__paused = true; });
  </script>
</body></html>`;

const dom = new JSDOM(HTML, { runScripts: 'dangerously', pretendToBeVisual: true,
                               url: 'https://www.youtube.com/@MrMarmok/videos' });
const win = dom.window;

// jsdom не считает layout: все getBoundingClientRect() нулевые, а наш фильтр
// отбрасывает элементы нулевого размера. Даём каждому элементу фиксированный
// прямоугольник — проверяется ЛОГИКА обхода/подписей, а не вёрстка.
win.Element.prototype.getBoundingClientRect = function () {
  const big = this.tagName === 'VIDEO';
  return { x: 10, y: 20, left: 10, top: 20, right: 10 + (big ? 640 : 120),
           bottom: 20 + (big ? 360 : 32), width: big ? 640 : 120, height: big ? 360 : 32,
           toJSON() { return this } };
};
win.Element.prototype.scrollIntoView = function () {};
Object.defineProperty(win, 'innerWidth', { value: 1280, configurable: true });
Object.defineProperty(win, 'innerHeight', { value: 720, configurable: true });
win.scrollY = 0;
Object.defineProperty(win, 'scrollY', { value: 0, writable: true, configurable: true });
Object.defineProperty(win.document.documentElement, 'scrollHeight',
                      { value: 3000, configurable: true });

function run(js) { return win.eval(js); }
// _ACT_JS — async IIFE: в браузере его ждёт CDP (awaitPromise:true),
// здесь ждём сами.
async function runAsync(js) { return await win.eval(js); }

(async function main() {
// ============================================================ 1. карта страницы
console.log('\n[1] browser_page_snapshot: обход, shadow DOM, подписи, нумерация');
const snapJs = PY._SNAPSHOT_JS.replace('__MAX__', '220').replace('__SHADOW__', 'true');
check('JS-блок _SNAPSHOT_JS извлечён из page.py', !!snapJs && snapJs.length > 500);
const snap = run(snapJs);
check('снапшот вернул объект', snap && typeof snap === 'object', String(snap).slice(0, 120));
check('заголовок страницы прочитан', snap.title.includes('MrMarmok'), snap.title);
check('URL прочитан', snap.url.includes('youtube.com'), snap.url);
check('высота прокрутки посчитана', snap.scroll.max > 0, JSON.stringify(snap.scroll));

const items = snap.items || [];
const byText = t => items.find(i => (i.text || '').includes(t));
check('элементы найдены', items.length >= 8, 'найдено ' + items.length);

// ГЛАВНОЕ: элементы из shadow root обычного плеера
const pauseBtn = byText('Пауза');
check('кнопка «Пауза» ВНУТРИ shadow root найдена', !!pauseBtn,
      JSON.stringify(items.map(i => i.text)));
check('она подписана как button', pauseBtn && pauseBtn.role === 'button',
      pauseBtn && pauseBtn.role);
check('aria-label использован как подпись', pauseBtn && pauseBtn.text === 'Пауза',
      pauseBtn && pauseBtn.text);

const vid1 = byText('Охота на Разумных');
check('ссылка на видео из shadow root ленты найдена', !!vid1, JSON.stringify(items.map(i => i.text)));
check('у ссылки виден href', vid1 && vid1.href === '/watch?v=AAA', vid1 && vid1.href);
check('роль ссылки определена', vid1 && vid1.role === 'link', vid1 && vid1.role);

const searchItem = items.find(i => i.tag === 'input');
check('поле поиска найдено', !!searchItem);
check('placeholder виден отдельным полем ph', searchItem && searchItem.ph === 'Введите запрос',
      JSON.stringify(searchItem));
check('aria-label и placeholder склеены в подписи',
      searchItem && /Поиск/.test(searchItem.text) && /Введите запрос/.test(searchItem.text),
      searchItem && searchItem.text);
const search = items.find(i => i.tag === 'input');
check('у input виден type=search', search && search.type === 'search', search && search.type);
check('кнопка «Войти» найдена', !!byText('Войти'));
check('display:none элемент ПРОПУЩЕН', !byText('Невидимая'),
      JSON.stringify(items.filter(i => i.text === 'Невидимая')));

check('нумерация последовательная с 1',
      items.every((it, k) => it.i === k + 1), JSON.stringify(items.slice(0, 5).map(i => i.i)));
check('window.__fluxEls заполнен ссылками на узлы',
      !!win.__fluxEls && Object.keys(win.__fluxEls).length === items.length,
      String(win.__fluxEls && Object.keys(win.__fluxEls).length));
check('__fluxEls[pauseBtn.i] — это именно кнопка паузы',
      win.__fluxEls[pauseBtn.i] && win.__fluxEls[pauseBtn.i].getAttribute('aria-label') === 'Пауза');
check('data-flux-id проставлен на элементе',
      win.__fluxEls[pauseBtn.i].getAttribute('data-flux-id') === String(pauseBtn.i));

check('видео найдено в media', (snap.media || []).length === 1, JSON.stringify(snap.media));
const mv = (snap.media || [])[0] || {};
check('состояние плеера прочитано (играет)', mv.paused === false, JSON.stringify(mv));
check('позиция и длительность прочитаны', mv.t === 42 && mv.dur === 620, JSON.stringify(mv));
check('громкость прочитана в процентах', mv.volume === 80, String(mv.volume));
check('число обозренных узлов > 0', snap.counts.scanned > 5, String(snap.counts.scanned));

// ============================================================ 2. действие по индексу
console.log('\n[2] browser_act: клик/ввод/select/press по индексу');
async function act(idx, action, text, key) {
  const js = PY._ACT_JS.replace('__IDX__', String(idx))
                       .replace('__ACT__', JSON.stringify(action || 'click'))
                       .replace('__TEXT__', JSON.stringify(text || ''))
                       .replace('__KEY__', JSON.stringify(key || ''));
  return await runAsync(js);
}

win.__clicked = null;
let r = await act(vid1.i, 'click');
check('клик по ссылке из shadow root: ok', r.ok === true, JSON.stringify(r));
check('клик реально дошёл до обработчика страницы', win.__clicked === '/watch?v=AAA',
      String(win.__clicked));
check('в ответе есть координаты для добивающего CDP-клика',
      typeof r.x === 'number' && typeof r.y === 'number', JSON.stringify(r));

win.__paused = null;
r = await act(pauseBtn.i, 'click');
check('клик по кнопке «Пауза»: ok', r.ok === true, JSON.stringify(r));
check('обработчик кнопки «Пауза» сработал', win.__paused === true);

const searchIdx = items.find(i => i.tag === 'input').i;
r = await act(searchIdx, 'type', 'MrMarmok последнее видео');
check('ввод в поле: ok', r.ok === true, JSON.stringify(r));
check('значение действительно записано в input',
      win.document.getElementById('search').value === 'MrMarmok последнее видео',
      win.document.getElementById('search').value);
check('в ответе число введённых символов', r.len === 'MrMarmok последнее видео'.length, String(r.len));

r = await act(searchIdx, 'clear');
check('clear очищает поле', win.document.getElementById('search').value === '', JSON.stringify(r));

const selIdx = items.find(i => i.tag === 'select').i;
r = await act(selIdx, 'select', '720p');
check('select по видимому тексту: ok', r.ok === true, JSON.stringify(r));
check('select реально переключил значение', win.document.getElementById('quality').value === '720',
      win.document.getElementById('quality').value);
r = await act(selIdx, 'select', '480p');
check('select несуществующего варианта -> ошибка со списком',
      r.ok === false && Array.isArray(r.options) && r.options.length === 2, JSON.stringify(r));

let pressed = null;
win.document.getElementById('search').addEventListener('keydown', e => { pressed = e.key; });
r = await act(searchIdx, 'press', '', 'Enter');
check('press отправил KeyboardEvent', pressed === 'Enter', String(pressed));

// несуществующий индекс и исчезнувший элемент
r = await act(9999, 'click');
check('несуществующий индекс -> понятная ошибка', r.ok === false && /snapshot/i.test(r.err),
      JSON.stringify(r));
const ghost = items.find(i => i.text === 'Второе видео');
win.__fluxEls[ghost.i].remove();
r = await act(ghost.i, 'click');
check('исчезнувший элемент -> «сделай снимок заново»',
      r.ok === false && /исчез/.test(r.err), JSON.stringify(r));

// ============================================================ 3. поиск по тексту
console.log('\n[3] browser_act_text: поиск элемента по видимому тексту');
function find(needle, want) {
  return run(PY._FIND_JS.replace('__NEEDLE__', JSON.stringify(needle))
                        .replace('__WANT__', JSON.stringify(want || '')));
}
let hits = find('Пауза');
check('«Пауза» найдена', Array.isArray(hits) && hits.length >= 1, JSON.stringify(hits));
check('первый кандидат — кнопка паузы', hits[0] && hits[0].i === pauseBtn.i,
      JSON.stringify(hits[0]));
hits = find('охота на разумных');
check('регистр не важен', hits.length >= 1 && hits[0].i === vid1.i, JSON.stringify(hits[0]));
hits = find('видео', 'href');
check('поиск по подстроке «видео» даёт несколько кандидатов', hits.length >= 2, String(hits.length));
hits = find('этого-текста-точно-нет');
check('ненайденный текст -> пустой список', hits.length === 0, JSON.stringify(hits));

// ============================================================ 4. управление плеером
console.log('\n[4] browser_media_control: пауза/воспроизведение/громкость/перемотка');
function media(cmd) { return run(PY._MEDIA_JS.replace('__CMD__', JSON.stringify(cmd))); }
let m = media('pause');
check('pause: найден плеер', m.found === true, JSON.stringify(m));
check('pause: видео на паузе', m.paused === true, JSON.stringify(m));
m = media('play');
check('play: видео снова играет', m.paused === false, JSON.stringify(m));
m = media('toggle');
check('toggle: переключилось на паузу', m.paused === true, JSON.stringify(m));
m = media('vol50');
check('vol50: громкость 50%', m.volume === 50, String(m.volume));
m = media('mute');
check('mute: звук выключен', m.muted === true, JSON.stringify(m));
m = media('unmute');
check('unmute: звук включён', m.muted === false);
m = media('seek30');
check('seek30: перемотка вперёд', m.t === 72, String(m.t));
m = media('seek-30');
check('seek-30: перемотка назад', m.t === 42, String(m.t));
m = media('rate1.5');
check('rate1.5: скорость изменена', m.rate === 1.5, String(m.rate));
m = media('stop');
check('stop: пауза и в начало', m.paused === true && m.t === 0, JSON.stringify(m));
// кнопка «следующее» лежит в shadow root плеера — её тоже надо находить
win.__nextClicked = null;
const playerSr = win.document.getElementById('player').shadowRoot;
playerSr.querySelector('#next').addEventListener('click', () => { win.__nextClicked = true; });
m = media('next');
check('next: кнопка внутри shadow root найдена и нажата',
      win.__nextClicked === true, JSON.stringify(m));
m = media('неведомая-команда');
check('неизвестная команда -> ошибка, а не молчание', m.err && m.err.includes('неизвестная'),
      JSON.stringify(m));

// ============================================================ 5. shadow DOM выключен
console.log('\n[5] Отключение обхода shadow DOM (page_shadow_dom=false)');
delete win.__fluxEls;
const noShadow = run(PY._SNAPSHOT_JS.replace('__MAX__', '220').replace('__SHADOW__', 'false'));
const noPause = (noShadow.items || []).find(i => (i.text || '') === 'Пауза');
check('без обхода shadow root кнопка «Пауза» НЕ видна', !noPause,
      JSON.stringify((noShadow.items || []).map(i => i.text)));
check('элементы светлого DOM при этом найдены',
      (noShadow.items || []).some(i => (i.text || '').includes('Войти')));

// ============================================================ 6. лимит элементов
console.log('\n[6] Лимит элементов и признак обрезки');
delete win.__fluxEls;
const small = run(PY._SNAPSHOT_JS.replace('__MAX__', '3').replace('__SHADOW__', 'true'));
check('MAX=3 ограничивает выдачу', (small.items || []).length === 3,
      String((small.items || []).length));
check('при обрезке выставлен флаг truncated', small.counts.truncated === true,
      JSON.stringify(small.counts));

console.log(`\n${'='.repeat(64)}`);
console.log(`ИТОГО: ${PASS.length} OK, ${FAIL.length} FAIL`);
if (FAIL.length) { console.log('Провалено:'); FAIL.forEach(f => console.log('  -', f)); }
process.exit(FAIL.length ? 1 : 0);
})().catch(e => { console.error('ТЕСТ УПАЛ:', e); process.exit(2); });

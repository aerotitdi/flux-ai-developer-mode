"""АДМИН-УТИЛИТА выдачи лицензионных ключей FLUX.

Это отдельная программа, она НЕ входит в клиентскую поставку: без неё и без
приватного ключа вендора новые ключи не создать. Держи её на своей машине сборки.

Синхронизация с бэкендом — через общую базу `license_server/data/licenses.db`
(или через HTTP API сервера лицензий, флаг `--api`).

Использование:
  python -m license_server.keygen init                 # создать пару ключей вендора
  python -m license_server.keygen issue                # выдать 1 ключ (standard, бессрочно)
  python -m license_server.keygen issue -n 10 --plan pro --days 365 \\
         --customer "ivan@example.com" --note "оплата 12.10" --devices 1
  python -m license_server.keygen list [--status active]
  python -m license_server.keygen info KEY-ID
  python -m license_server.keygen revoke KEY-ID --reason "возврат средств"
  python -m license_server.keygen unrevoke KEY-ID
  python -m license_server.keygen extend KEY-ID --days 90
  python -m license_server.keygen devices KEY-ID [--release HWID]
  python -m license_server.keygen audit [--limit 50]
  python -m license_server.keygen stats
  python -m license_server.keygen export [--out keys.csv]     # CSV для бухгалтерии
  python -m license_server.keygen serve                      # поднять сервер лицензий

Ключ печатается в момент выдачи ЕДИНОЖДЕННЫЙ раз — в базе хранится только его
sha256-хеш, поэтому восстановить забытый ключ нельзя (выдай новый и отзови старый).
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from typing import Optional

from . import crypto, keys, store as store_mod

DEFAULT_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "licenses.db")


def _db(args) -> store_mod.LicenseStore:
    return store_mod.LicenseStore(args.db or os.environ.get("FLUX_LICENSE_DB") or DEFAULT_DB)


def _fmt_date(ts: int) -> str:
    if not ts:
        return "бессрочно"
    return time.strftime("%d.%m.%Y", time.localtime(ts))


def _fmt_dt(ts: Optional[int]) -> str:
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(ts)) if ts else "—"


def _print_license(rec: dict, acts: Optional[list] = None) -> None:
    print(f"  {rec['key_id']}  [{rec['status']}]  план={rec['plan']}  "
          f"выдан {_fmt_dt(rec['issued_at'])}  срок до {_fmt_date(rec['expires_at'])}")
    if rec.get("customer"):
        print(f"      клиент: {rec['customer']}")
    if rec.get("note"):
        print(f"      примечание: {rec['note']}")
    print(f"      активаций: {rec['max_activations']} · "
          f"офлайн-проверка: {rec['offline_days']} дн · последний контакт: "
          f"{_fmt_dt(rec.get('last_seen'))}")
    if rec.get("status") == "revoked":
        print(f"      ОТОЗВАН {_fmt_dt(rec.get('revoked_at'))}: {rec.get('revoke_reason') or '—'}")
    for a in (acts if acts is not None else rec.get("activations") or []):
        print(f"      устройство {a['hwid'][:16].upper()}… "
              f"{'(освобождено)' if a.get('released') else ''} "
              f"активировано {_fmt_dt(a['activated_at'])}, "
              f"последний раз {_fmt_dt(a['last_seen'])}"
              + (f" · {a['hwid_label']}" if a.get("hwid_label") else ""))


def cmd_init(args) -> int:
    r = keys.init(force=args.force)
    if not r.get("created"):
        print("Пара ключей вендора уже существует:", r.get("path"))
        print(r.get("note", ""))
        print("Публичный ключ встроен в:", keys.EMBED_PATH)
        print("Отпечаток публичного ключа:", keys.fingerprint())
        return 0
    print("Создана пара ключей вендора Ed25519")
    print("  приватный:", r["path"], "(шифрован паролем)" if r.get("encrypted") else "(БЕЗ пароля!)")
    print("  публичный:", r["pub"])
    print("  встроен в клиент:", r.get("embed"))
    print("  отпечаток:", r.get("fingerprint"))
    print()
    print("ВАЖНО:")
    print("  1. Сделай резервную копию каталога license_server/keys/ в безопасное место.")
    print("     Без приватного ключа выданные лицензии нельзя ни продлить, ни перевыпустить.")
    print("  2. Каталог keys/ добавлен в .gitignore — проверь, что он не попал в репозиторий.")
    print("  3. Задай пароль: export FLUX_VENDOR_KEY_PASS='...' и выполни init --force,")
    print("     иначе приватный ключ лежит на диске открытым текстом.")
    return 0


def cmd_issue(args) -> int:
    if not keys.exists():
        print("Сначала создай ключи вендора: python -m license_server.keygen init")
        return 2
    db = _db(args)
    expires = 0 if args.days <= 0 else int(time.time()) + args.days * 86400
    issued = []
    for i in range(max(1, args.n)):
        rec = db.issue(plan=args.plan, customer=args.customer or "", note=args.note or "",
                       expires_at=expires, max_activations=max(1, args.devices),
                       offline_days=max(1, args.offline))
        issued.append(rec)
        print(f"[{i + 1}/{args.n}] КЛЮЧ: {rec['key']}")
        print(f"         id: {rec['key_id']}  план: {rec['plan']}  "
              f"срок: {_fmt_date(rec['expires_at'])}  устройств: {rec['max_activations']}")
    if args.out:
        with open(args.out, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            if f.tell() == 0:
                w.writerow(["дата", "ключ", "id", "план", "клиент", "срок", "устройств", "примечание"])
            for r in issued:
                w.writerow([_fmt_dt(r["issued_at"]), r["key"], r["key_id"], r["plan"],
                            r["customer"], _fmt_date(r["expires_at"]),
                            r["max_activations"], r["note"]])
        print(f"\nдописано в {args.out}")
    print("\nКлюч показан один раз — в базе хранится только его хеш.")
    return 0


def cmd_list(args) -> int:
    db = _db(args)
    rows = db.list_all(status=args.status or "", limit=args.limit)
    if not rows:
        print("лицензий нет" + (f" со статусом {args.status}" if args.status else ""))
        return 0
    print(f"всего: {len(rows)}")
    for rec in rows:
        _print_license(rec)
    return 0


def cmd_info(args) -> int:
    db = _db(args)
    rec = db.get_by_id(args.key_id) or (db.get_by_key(args.key_id) if "-" in args.key_id else None)
    if not rec:
        print(f"лицензия не найдена: {args.key_id}")
        return 1
    rec = db.refresh_status(rec)
    _print_license(rec, db.activations(rec["key_hash"], active_only=False))
    print("\nпоследние события по ключу:")
    for a in db.audit_log(15, rec["key_id"]):
        print(f"  {_fmt_dt(a['ts'])} {a['action']:<12} {a.get('hwid', '')[:16]:<16} "
              f"{a.get('ip', ''):<15} {a.get('detail', '')[:60]}")
    return 0


def cmd_revoke(args) -> int:
    db = _db(args)
    rec = db.revoke(args.key_id, args.reason or "")
    if not rec:
        print(f"лицензия не найдена: {args.key_id}")
        return 1
    n = len(db.activations(rec["key_hash"], active_only=True))
    print(f"ОТОЗВАН {rec['key_id']} (причина: {args.reason or 'не указана'})")
    print(f"затронуто устройств: {n}")
    print("клиенты заблокируются при ближайшей проверке (heartbeat или истечение билета).")
    return 0


def cmd_unrevoke(args) -> int:
    db = _db(args)
    rec = db.unrevoke(args.key_id)
    if not rec:
        print(f"лицензия не найдена: {args.key_id}")
        return 1
    print(f"отзыв снят: {rec['key_id']} -> {rec['status']}")
    return 0


def cmd_extend(args) -> int:
    db = _db(args)
    rec = db.extend(args.key_id, args.days)
    if not rec:
        print(f"лицензия не найдена: {args.key_id}")
        return 1
    print(f"{rec['key_id']}: срок до {_fmt_date(rec['expires_at'])}"
          + (" (бессрочно)" if not rec["expires_at"] else ""))
    return 0


def cmd_devices(args) -> int:
    db = _db(args)
    rec = db.get_by_id(args.key_id)
    if not rec:
        print(f"лицензия не найдена: {args.key_id}")
        return 1
    acts = db.activations(rec["key_hash"], active_only=False)
    if args.release:
        ok = db.release_activation(rec["key_hash"], args.release)
        db.audit("release", rec["key_id"], args.release, detail="освобождено вручную")
        print("освобождено" if ok else f"активация {args.release[:16]}… не найдена")
        acts = db.activations(rec["key_hash"], active_only=False)
    if args.release_all:
        n = db.release_all(rec["key_hash"])
        db.audit("release_all", rec["key_id"], detail=f"освобождено {n}")
        print(f"освобождено устройств: {n}")
        acts = db.activations(rec["key_hash"], active_only=False)
    print(f"{rec['key_id']}: занято {len([a for a in acts if not a['released']])} "
          f"из {rec['max_activations']}")
    for a in acts:
        mark = "освобождено" if a["released"] else "АКТИВНО"
        print(f"  {a['hwid'][:20].upper()}…  [{mark}]  {_fmt_dt(a['activated_at'])}"
              + (f"  {a['hwid_label']}" if a.get("hwid_label") else ""))
    return 0


def cmd_audit(args) -> int:
    db = _db(args)
    rows = db.audit_log(args.limit, args.key_id or "")
    if not rows:
        print("журнал пуст")
        return 0
    for a in rows:
        print(f"{_fmt_dt(a['ts'])} {a['action']:<12} {a['key_id']:<14} "
              f"{a.get('hwid', '')[:16]:<16} {a.get('ip', ''):<15} {a.get('detail', '')[:70]}")
    return 0


def cmd_stats(args) -> int:
    db = _db(args)
    st = db.stats()
    print(f"лицензий всего : {st['total']}")
    print(f"  не активировано: {st['inactive']}")
    print(f"  активных      : {st['active']}")
    print(f"  отозвано      : {st['revoked']}")
    print(f"  истекло       : {st['expired']}")
    print(f"устройств привязано: {st['devices']}")
    print(f"последнее событие  : {_fmt_dt(st['last_event'])}")
    print(f"база: {db.path}")
    print(f"публичный ключ вендора: {keys.fingerprint()}")
    return 0


def cmd_export(args) -> int:
    db = _db(args)
    rows = db.list_all(limit=100000)
    out = args.out or "flux-licenses.csv"
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["key_id", "plan", "status", "customer", "issued_at", "expires_at",
                    "max_activations", "used_activations", "last_seen", "note"])
        for r in rows:
            w.writerow([r["key_id"], r["plan"], r["status"], r["customer"],
                        _fmt_dt(r["issued_at"]), _fmt_date(r["expires_at"]),
                        r["max_activations"], len([a for a in r["activations"] if not a["released"]]),
                        _fmt_dt(r.get("last_seen")), r["note"]])
    print(f"экспортировано {len(rows)} лицензий в {out}")
    print("сами ключи в экспорт не попадают — в базе только их хеши.")
    return 0


def cmd_serve(args) -> int:
    from . import server
    return server.run(host=args.host, port=args.port, db_path=args.db or DEFAULT_DB,
                      admin_token=args.admin_token)


def cmd_selftest(args) -> int:
    """Проверка всей цепочки без сети: выдача -> активация -> отзыв -> блокировка."""
    import tempfile
    print("Самопроверка лицензирования")
    if not keys.exists():
        print("  нет ключей вендора — создаю временные…")
        keys.init()
    tmp = tempfile.mkdtemp(prefix="flux-lic-selftest-")
    db = store_mod.LicenseStore(os.path.join(tmp, "t.db"))
    priv = keys.load_private_key()
    pub = keys.load_public_key()

    ok = True

    def ck(name, cond, extra=""):
        nonlocal ok
        ok = ok and bool(cond)
        print(f"  {'OK  ' if cond else 'FAIL'} {name}" + (f"  <- {extra}" if extra and not cond else ""))

    rec = db.issue(plan="pro", customer="selftest", max_activations=1, offline_days=7)
    ck("ключ выдан", bool(rec.get("key")), str(rec))
    ck("ключ формата FLX2-…", (rec["key"] or "").startswith("FLX2-") and
       len(rec["key"].split("-")) == 5, rec.get("key", ""))
    ck("в базе лежит хеш, а не ключ", db.get_by_hash(crypto.key_hash(rec["key"])) is not None)
    ck("нормализация: строчные буквы и пробелы принимаются",
       crypto.normalize_key(rec["key"].lower().replace("-", " ")) == rec["key"])
    ck("опечатка ловится контрольным символом",
       crypto.normalize_key(rec["key"][:-1] + ("A" if rec["key"][-1] != "A" else "B")) is None)

    hwid = "a" * 64
    ticket = crypto.make_ticket(priv, key=rec["key"], hwid=hwid, plan=rec["plan"],
                                expires=0, offline_days=7)
    good, why = crypto.verify_ticket(pub, ticket, hwid)
    ck("билет проверяется публичным ключом", good, why)
    good2, why2 = crypto.verify_ticket(pub, ticket, "b" * 64)
    ck("билет на другом HWID отвергается", not good2, why2)
    bad = json.loads(json.dumps(ticket))
    bad["payload"]["plan"] = "ultimate"
    ck("подделка билета отвергается", not crypto.verify_ticket(pub, bad, hwid)[0])
    exp = crypto.make_ticket(priv, key=rec["key"], hwid=hwid, plan="pro",
                             expires=int(time.time()) - 10, offline_days=7)
    ck("просроченный билет отвергается", not crypto.verify_ticket(pub, exp, hwid)[0])
    off = crypto.make_ticket(priv, key=rec["key"], hwid=hwid, plan="pro", expires=0,
                             offline_days=0, issued=int(time.time()) - 86400)
    ck("билет с истёкшим офлайн-окном отвергается", not crypto.verify_ticket(pub, off, hwid)[0])

    db.add_activation(crypto.key_hash(rec["key"]), hwid, [hwid], "selftest")
    ck("активация зарегистрирована", len(db.activations(crypto.key_hash(rec["key"]))) == 1)
    ck("статус стал active", db.refresh_status(rec)["status"] == "active")
    rv = db.revoke(rec["key_id"], "самопроверка")
    ck("отзыв работает", rv["status"] == "revoked")
    un = db.unrevoke(rec["key_id"])
    ck("снятие отзыва работает", un["status"] == "active")
    ck("аудит пишется", len(db.audit_log(50)) >= 3)
    db.close()
    print(f"\n{'ВСЁ ОК' if ok else 'ЕСТЬ ПРОВАЛЫ'}")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="keygen", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default="", help=f"путь к базе лицензий (по умолчанию {DEFAULT_DB})")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init", help="создать пару ключей вендора")
    p.add_argument("--force", action="store_true",
                   help="пересоздать (старые лицензии перестанут проверяться!)")
    p.set_defaults(fn=cmd_init)

    p = sub.add_parser("issue", help="выдать ключ(и)")
    p.add_argument("-n", type=int, default=1, help="сколько ключей выдать")
    p.add_argument("--plan", default="standard", help="standard|pro|ultimate|trial|свой")
    p.add_argument("--days", type=int, default=0, help="срок в днях (0 = бессрочно)")
    p.add_argument("--devices", type=int, default=1, help="сколько активаций разрешено")
    p.add_argument("--offline", type=int, default=14, help="дней офлайн-проверки билета")
    p.add_argument("--customer", default="", help="почта/имя клиента")
    p.add_argument("--note", default="", help="примечание (номер счёта и т.п.)")
    p.add_argument("--out", default="", help="дописать выданные ключи в CSV")
    p.set_defaults(fn=cmd_issue)

    p = sub.add_parser("list", help="список лицензий")
    p.add_argument("--status", default="", choices=["", "inactive", "active", "revoked", "expired"])
    p.add_argument("--limit", type=int, default=200)
    p.set_defaults(fn=cmd_list)

    p = sub.add_parser("info", help="подробно о лицензии")
    p.add_argument("key_id")
    p.set_defaults(fn=cmd_info)

    p = sub.add_parser("revoke", help="ОТОЗВАТЬ ключ (клиент заблокируется)")
    p.add_argument("key_id")
    p.add_argument("--reason", default="")
    p.set_defaults(fn=cmd_revoke)

    p = sub.add_parser("unrevoke", help="снять отзыв")
    p.add_argument("key_id")
    p.set_defaults(fn=cmd_unrevoke)

    p = sub.add_parser("extend", help="продлить")
    p.add_argument("key_id")
    p.add_argument("--days", type=int, required=True, help="на сколько дней (0 = бессрочно)")
    p.set_defaults(fn=cmd_extend)

    p = sub.add_parser("devices", help="устройства, на которых активирован ключ")
    p.add_argument("key_id")
    p.add_argument("--release", default="", help="освободить конкретный HWID")
    p.add_argument("--release-all", action="store_true", help="освободить все устройства")
    p.set_defaults(fn=cmd_devices)

    p = sub.add_parser("audit", help="журнал действий")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--key-id", default="")
    p.set_defaults(fn=cmd_audit)

    p = sub.add_parser("stats", help="сводка")
    p.set_defaults(fn=cmd_stats)

    p = sub.add_parser("export", help="экспорт в CSV (без самих ключей)")
    p.add_argument("--out", default="")
    p.set_defaults(fn=cmd_export)

    p = sub.add_parser("serve", help="поднять сервер лицензий")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8790)
    p.add_argument("--admin-token", default="", help="токен админки (иначе FLUX_ADMIN_TOKEN)")
    p.set_defaults(fn=cmd_serve)

    p = sub.add_parser("selftest", help="проверить всю цепочку без сети")
    p.set_defaults(fn=cmd_selftest)
    return ap


def main(argv: Optional[list] = None) -> int:
    args = build_parser().parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())

"""Криптография лицензий FLUX: Ed25519 + формат ключей.

СХЕМА (как в коммерческих продуктах, а не «ключ зашит в exe»):

  * КЛЮЧ — короткий секрет, который пользователь вводит руками:
    `FLX2-XXXXX-XXXXX-XXXXX-XXXXX`. Сам по себе он ничего не доказывает клиенту —
    проверяется только сервером (по sha256-хешу в базе). Из exe нельзя вытащить
    «генератор ключей», потому что его там нет.

  * БИЛЕТ (activation ticket) — подписанный Ed25519 JSON, который сервер выдаёт
    при активации и который привязан к HWID. Клиент проверяет его подпись
    ВСТРОЕННЫМ ПУБЛИЧНЫМ ключом, поэтому работает офлайн весь срок действия билета.
    Подделать билет, не имея приватного ключа вендора, нельзя.

  * Приватный ключ вендора живёт ТОЛЬКО в `license_server/keys/` на машине сборки
    (или в HSM) и в клиентскую поставку НЕ попадает. Публичный — встраивается.

Почему Ed25519: 64-байтная подпись, 32-байтный публичный ключ (влезает в строку
конфига), детерминированная подпись, есть в `cryptography` без внешних зависимостей.

Алфавит ключа — Crockford base32 без неоднозначных символов (0, 1, I, L, O, U):
`23456789ABCDEFGHJKMNPQRSTVWXYZ`. Ошибку при вводе ловит контрольный символ.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from typing import Any, Optional

# ------------------------------------------------------------------ формат ключа
# Каноническое определение формата живёт в app/license_fmt.py: этот пакет входит в
# КЛИЕНТСКУЮ поставку, а license_server — нет. Клиент обязан уметь нормализовать
# введённый ключ и объяснить опечатку без серверного кода. Импорт отсюда
# гарантирует, что формат не «разъедется» между клиентом и сервером.
import os as _os
import sys as _sys

_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
if _ROOT not in _sys.path:
    _sys.path.insert(0, _ROOT)

from app.license_fmt import (ALPHABET, GROUP, KEY_BODY_LEN, KEY_PREFIX, _check_char,
                             key_hash, key_hint, key_id, make_key, mask_key,
                             normalize_key)


__all__ = [
    # реэкспорт формата ключа (единый источник — app/license_fmt.py)
    "ALPHABET", "GROUP", "KEY_BODY_LEN", "KEY_PREFIX", "make_key", "normalize_key",
    "key_hint", "key_hash", "key_id", "mask_key",
    # криптография и билеты
    "LicenseCryptoError", "generate_vendor_keypair", "load_private", "load_public",
    "sign", "verify", "canonical_json", "make_ticket", "verify_ticket",
    "ticket_payload", "constant_time_eq", "random_token", "now_iso", "secure_dir",
]


class LicenseCryptoError(Exception):
    pass


# ============================================================ ключи вендора
def _ed25519():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey, Ed25519PublicKey)
        return Ed25519PrivateKey, Ed25519PublicKey
    except ImportError as e:                          # pragma: no cover
        raise LicenseCryptoError(
            "нужен пакет cryptography: pip install cryptography") from e


def generate_vendor_keypair() -> tuple[str, str]:
    """Новая пара ключей вендора. Возвращает (private_pem, public_pem)."""
    Priv, _ = _ed25519()
    sk = Priv.generate()
    from cryptography.hazmat.primitives import serialization
    priv = sk.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()).decode()
    pub = sk.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    return priv, pub


def load_private(pem: str | bytes):
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    if isinstance(pem, str):
        pem = pem.encode()
    return load_pem_private_key(pem, password=None)


def load_public(pem: str | bytes):
    from cryptography.hazmat.primitives.serialization import load_pem_public_key
    if isinstance(pem, str):
        pem = pem.encode()
    return load_pem_public_key(pem)


def sign(private_key, payload: dict) -> str:
    """Подписать словарь -> base64url(подпись)."""
    data = canonical_json(payload).encode("utf-8")
    sig = private_key.sign(data)
    return base64.urlsafe_b64encode(sig).decode("ascii").rstrip("=")


def verify(public_key, payload: dict, signature_b64: str) -> bool:
    """Проверить подпись словаря. Любая ошибка -> False (не исключение)."""
    try:
        pad = "=" * (-len(signature_b64) % 4)
        sig = base64.urlsafe_b64decode(signature_b64 + pad)
        public_key.verify(sig, canonical_json(payload).encode("utf-8"))
        return True
    except Exception:
        return False


def canonical_json(obj: Any) -> str:
    """Канонический JSON: порядок ключей и разделители фиксированы, иначе подпись
    не сойдётся между машинами (Python dict сохраняет порядок вставки)."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), default=str)


# ============================================================ билеты
def make_ticket(private_key, *, key: str, hwid: str, plan: str,
                expires: int, issued: Optional[int] = None,
                offline_days: int = 14, customer: str = "",
                extra: Optional[dict] = None) -> dict:
    """Подписанный билет активации. Клиент проверяет его офлайн публичным ключом."""
    issued = int(issued or time.time())
    payload = {
        "v": 1,
        "kid": key_id(key),                      # публичный id, НЕ сам ключ
        "hwid": hwid,
        "plan": plan,
        "customer": customer,
        "issued": issued,
        "expires": int(expires),                 # 0 = бессрочно
        "offline_until": issued + int(offline_days) * 86400,
        "nonce": secrets.token_hex(8),           # защита от копирования одного билета
    }
    if extra:
        payload["extra"] = extra
    return {"payload": payload, "sig": sign(private_key, payload)}


def verify_ticket(public_key, ticket: dict, hwid: str,
                  now: Optional[float] = None) -> tuple[bool, str]:
    """Проверить билет на клиенте. Возвращает (ok, причина)."""
    now = time.time() if now is None else now
    if not isinstance(ticket, dict):
        return False, "билет повреждён"
    payload = ticket.get("payload")
    sig = ticket.get("sig")
    if not isinstance(payload, dict) or not sig:
        return False, "билет неполный"
    if not verify(public_key, payload, sig):
        return False, "подпись билета недействительна (билет подделан или повреждён)"
    if payload.get("hwid") != hwid:
        return False, "билет выдан на другое устройство"
    exp = int(payload.get("expires") or 0)
    if exp and now > exp:
        return False, f"лицензия истекла {time.strftime('%d.%m.%Y', time.localtime(exp))}"
    off = int(payload.get("offline_until") or 0)
    if off and now > off:
        return False, (f"прошёл срок офлайн-проверки ({int((now - off) / 3600)} ч назад) — "
                       f"нужно подключиться к серверу лицензий")
    if now < int(payload.get("issued") or 0) - 86400:
        return False, "билет выдан в будущем — проверь системное время"
    return True, "ok"


def ticket_payload(ticket: dict) -> dict:
    return dict((ticket or {}).get("payload") or {})


def constant_time_eq(a: str, b: str) -> bool:
    return hmac.compare_digest((a or "").encode(), (b or "").encode())


def random_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def now_iso() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def secure_dir(path: str) -> str:
    """Каталог с правами только для владельца (приватный ключ не должен читаться всеми)."""
    os.makedirs(path, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass
    return path

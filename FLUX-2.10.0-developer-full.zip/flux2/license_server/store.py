"""Хранилище лицензий: SQLite (stdlib, без внешних СУБД) + аудит.

Модель данных:
  licenses     — сам ключ (хранится ТОЛЬКО sha256-хеш), план, срок, статус, лимит активаций
  activations  — устройства, на которых ключ активирован (HWID, билет, последний контакт)
  audit        — каждое действие: выдача, активация, отказ, отзыв, продление

Почему хеш, а не ключ: при утечке базы ключи невозможно восстановить и нельзя
активировать чужие копии. Сервер сверяет sha256(введённый ключ) с key_hash.

Статусы лицензии:
  inactive  — выдан, ни разу не активирован
  active    — активирован хотя бы на одном устройстве
  revoked   — отозван администратором (клиент блокируется при ближайшей проверке)
  expired   — истёк срок

HWID и допуск к смене железа: клиент присылает ВАРИАНТЫ отпечатка (полный и
«без каждого компонента»), сервер принимает совпадение с любым из них — поэтому
замена сетевой карты или добавление диска не сбрасывает активацию, а смена
материнской платы считается новым устройством. См. app/hwid.py.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Optional

from . import crypto

SCHEMA = """
CREATE TABLE IF NOT EXISTS licenses (
    key_hash        TEXT PRIMARY KEY,
    key_id          TEXT NOT NULL,
    plan            TEXT NOT NULL DEFAULT 'standard',
    customer        TEXT DEFAULT '',
    note            TEXT DEFAULT '',
    issued_at       INTEGER NOT NULL,
    expires_at      INTEGER NOT NULL DEFAULT 0,
    max_activations INTEGER NOT NULL DEFAULT 1,
    offline_days    INTEGER NOT NULL DEFAULT 14,
    status          TEXT NOT NULL DEFAULT 'inactive',
    revoked_at      INTEGER,
    revoke_reason   TEXT DEFAULT '',
    last_seen       INTEGER
);
CREATE TABLE IF NOT EXISTS activations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    key_hash     TEXT NOT NULL,
    hwid         TEXT NOT NULL,
    hwid_label   TEXT DEFAULT '',
    variants     TEXT DEFAULT '[]',
    activated_at INTEGER NOT NULL,
    last_seen    INTEGER NOT NULL,
    ticket_exp   INTEGER NOT NULL DEFAULT 0,
    released     INTEGER NOT NULL DEFAULT 0,
    app_version  TEXT DEFAULT '',
    UNIQUE(key_hash, hwid)
);
CREATE TABLE IF NOT EXISTS audit (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      INTEGER NOT NULL,
    key_id  TEXT DEFAULT '',
    action  TEXT NOT NULL,
    hwid    TEXT DEFAULT '',
    ip      TEXT DEFAULT '',
    detail  TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_lic_status ON licenses(status);
CREATE INDEX IF NOT EXISTS idx_act_key ON activations(key_hash);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts DESC);
"""

ST_INACTIVE, ST_ACTIVE, ST_REVOKED, ST_EXPIRED = "inactive", "active", "revoked", "expired"


class LicenseStore:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False, timeout=15)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA foreign_keys=ON")
        with self._lock:
            self._db.executescript(SCHEMA)
            self._db.commit()

    def close(self) -> None:
        with self._lock:
            try:
                self._db.commit()
            finally:
                self._db.close()

    # ---------------------------------------------------------------- аудит
    def audit(self, action: str, key_id: str = "", hwid: str = "",
              ip: str = "", detail: str = "") -> None:
        with self._lock:
            self._db.execute("INSERT INTO audit(ts,key_id,action,hwid,ip,detail) VALUES(?,?,?,?,?,?)",
                             (int(time.time()), key_id, action, hwid[:64], ip[:64], detail[:400]))
            self._db.commit()

    def audit_log(self, limit: int = 100, key_id: str = "") -> list[dict]:
        q = "SELECT * FROM audit"
        args: list = []
        if key_id:
            q += " WHERE key_id=?"
            args.append(key_id)
        q += " ORDER BY ts DESC LIMIT ?"
        args.append(int(limit))
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        return [dict(r) for r in rows]

    # ---------------------------------------------------------------- выдача
    def issue(self, *, plan: str = "standard", customer: str = "", note: str = "",
              expires_at: int = 0, max_activations: int = 1, offline_days: int = 14,
              key: Optional[str] = None) -> dict:
        """Выпустить новый ключ. Возвращает запись С самим ключом (единственный раз,
        когда он показывается — дальше в базе только хеш)."""
        key = crypto.normalize_key(key) if key else None
        while not key:
            cand = crypto.make_key()
            if not self.get_by_hash(crypto.key_hash(cand)):
                key = cand
                break
        kh = crypto.key_hash(key)
        if self.get_by_hash(kh):
            raise ValueError("такой ключ уже выпущен (коллизия) — повтори выдачу")
        now = int(time.time())
        with self._lock:
            self._db.execute(
                """INSERT INTO licenses(key_hash,key_id,plan,customer,note,issued_at,expires_at,
                                        max_activations,offline_days,status)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (kh, crypto.key_id(key), plan, customer, note, now, int(expires_at),
                 int(max_activations), int(offline_days), ST_INACTIVE))
            self._db.commit()
        self.audit("issue", crypto.key_id(key), detail=f"plan={plan} customer={customer}")
        rec = self.get_by_hash(kh)
        rec["key"] = key
        return rec

    def get_by_hash(self, kh: str) -> Optional[dict]:
        with self._lock:
            row = self._db.execute("SELECT * FROM licenses WHERE key_hash=?", (kh,)).fetchone()
        return dict(row) if row else None

    def get_by_key(self, key: str) -> Optional[dict]:
        norm = crypto.normalize_key(key)
        if not norm:
            return None
        return self.get_by_hash(crypto.key_hash(norm))

    def get_by_id(self, kid: str) -> Optional[dict]:
        with self._lock:
            row = self._db.execute("SELECT * FROM licenses WHERE key_id=?",
                                   (kid.upper(),)).fetchone()
        return dict(row) if row else None

    def list_all(self, status: str = "", limit: int = 500) -> list[dict]:
        q = "SELECT * FROM licenses"
        args: list = []
        if status:
            q += " WHERE status=?"
            args.append(status)
        q += " ORDER BY issued_at DESC LIMIT ?"
        args.append(int(limit))
        with self._lock:
            rows = [dict(r) for r in self._db.execute(q, args).fetchall()]
        for rec in rows:
            rec["activations"] = self.activations(rec["key_hash"], active_only=True)
        return rows

    def count(self, status: str = "") -> int:
        q = "SELECT COUNT(*) AS n FROM licenses"
        args: list = []
        if status:
            q += " WHERE status=?"
            args.append(status)
        with self._lock:
            return int(self._db.execute(q, args).fetchone()["n"])

    # ---------------------------------------------------------------- статусы
    def revoke(self, key_id: str, reason: str = "") -> Optional[dict]:
        rec = self.get_by_id(key_id)
        if not rec:
            return None
        with self._lock:
            self._db.execute("UPDATE licenses SET status=?, revoked_at=?, revoke_reason=? "
                             "WHERE key_hash=?", (ST_REVOKED, int(time.time()), reason,
                                                  rec["key_hash"]))
            self._db.commit()
        self.audit("revoke", key_id, detail=reason)
        return self.get_by_hash(rec["key_hash"])

    def unrevoke(self, key_id: str) -> Optional[dict]:
        rec = self.get_by_id(key_id)
        if not rec:
            return None
        new = ST_ACTIVE if self.activations(rec["key_hash"], active_only=True) else ST_INACTIVE
        with self._lock:
            self._db.execute("UPDATE licenses SET status=?, revoked_at=NULL, revoke_reason='' "
                             "WHERE key_hash=?", (new, rec["key_hash"]))
            self._db.commit()
        self.audit("unrevoke", key_id, detail=f"-> {new}")
        return self.get_by_hash(rec["key_hash"])

    def extend(self, key_id: str, days: int) -> Optional[dict]:
        rec = self.get_by_id(key_id)
        if not rec:
            return None
        base = max(int(rec["expires_at"] or 0), int(time.time()))
        new_exp = 0 if days <= 0 else base + int(days) * 86400
        with self._lock:
            self._db.execute("UPDATE licenses SET expires_at=?, "
                             "status=CASE WHEN status='expired' THEN 'active' ELSE status END "
                             "WHERE key_hash=?", (new_exp, rec["key_hash"]))
            self._db.commit()
        self.audit("extend", key_id, detail=f"+{days} дней -> {new_exp or 'бессрочно'}")
        return self.get_by_hash(rec["key_hash"])

    def set_plan(self, key_id: str, plan: str) -> Optional[dict]:
        rec = self.get_by_id(key_id)
        if not rec:
            return None
        with self._lock:
            self._db.execute("UPDATE licenses SET plan=? WHERE key_hash=?",
                             (plan, rec["key_hash"]))
            self._db.commit()
        self.audit("set_plan", key_id, detail=plan)
        return self.get_by_hash(rec["key_hash"])

    # ---------------------------------------------------------------- активации
    def activations(self, key_hash: str, active_only: bool = True) -> list[dict]:
        q = "SELECT * FROM activations WHERE key_hash=?"
        if active_only:
            q += " AND released=0"
        q += " ORDER BY activated_at"
        with self._lock:
            return [dict(r) for r in self._db.execute(q, (key_hash,)).fetchall()]

    def find_activation(self, key_hash: str, variants: list[str]) -> Optional[dict]:
        """Ищем активацию этого устройства среди вариантов HWID."""
        acts = self.activations(key_hash, active_only=True)
        vs = set(variants or [])
        for a in acts:
            try:
                stored = set(json.loads(a.get("variants") or "[]"))
            except Exception:
                stored = set()
            stored.add(a["hwid"])
            if stored & vs:
                return a
        return None

    def add_activation(self, key_hash: str, hwid: str, variants: list[str],
                       hwid_label: str = "", ticket_exp: int = 0,
                       app_version: str = "") -> dict:
        now = int(time.time())
        with self._lock:
            self._db.execute(
                """INSERT INTO activations(key_hash,hwid,hwid_label,variants,activated_at,
                                           last_seen,ticket_exp,app_version)
                   VALUES(?,?,?,?,?,?,?,?)
                   ON CONFLICT(key_hash,hwid) DO UPDATE SET
                     released=0, last_seen=excluded.last_seen,
                     variants=excluded.variants, ticket_exp=excluded.ticket_exp,
                     hwid_label=excluded.hwid_label, app_version=excluded.app_version""",
                (key_hash, hwid, hwid_label, json.dumps(variants or []), now, now,
                 int(ticket_exp), app_version))
            self._db.commit()
        return {"key_hash": key_hash, "hwid": hwid, "activated_at": now}

    def move_activation(self, key_hash: str, old_hwid: str, new_hwid: str,
                        variants: list[str], hwid_label: str = "",
                        ticket_exp: int = 0, app_version: str = "") -> bool:
        """Перенести УЖЕ ЗАНЯТОЕ место на новый отпечаток. Возвращает True, если перенесли.

        Нужно, когда у пользователя изменился один компонент железа (замена сетевой
        карты, добавление диска): вариант отпечатка совпал со старым, значит это та же
        машина. Без переноса каждая такая активация создавала бы НОВУЮ строку и тратила
        ещё одно место из лимита — то есть одна машина могла бы занять всю лицензию.
        """
        if old_hwid == new_hwid:
            self.add_activation(key_hash, new_hwid, variants, hwid_label,
                                ticket_exp, app_version)
            return False
        now = int(time.time())
        with self._lock:
            # убираем возможную прежнюю строку с НОВЫМ hwid, иначе UPDATE упрётся
            # в UNIQUE(key_hash, hwid). История остаётся в audit, не в activations.
            self._db.execute("DELETE FROM activations WHERE key_hash=? AND hwid=?",
                             (key_hash, new_hwid))
            cur = self._db.execute(
                """UPDATE activations SET hwid=?, variants=?, last_seen=?, ticket_exp=?,
                        hwid_label=CASE WHEN ?='' THEN hwid_label ELSE ? END,
                        app_version=CASE WHEN ?='' THEN app_version ELSE ? END,
                        released=0
                   WHERE key_hash=? AND hwid=? AND released=0""",
                (new_hwid, json.dumps(variants or []), now, int(ticket_exp),
                 hwid_label, hwid_label, app_version, app_version, key_hash, old_hwid))
            moved = cur.rowcount > 0
            self._db.commit()
        if not moved:
            self.add_activation(key_hash, new_hwid, variants, hwid_label,
                                ticket_exp, app_version)
        return moved

    def touch_activation(self, key_hash: str, hwid: str) -> None:
        now = int(time.time())
        with self._lock:
            self._db.execute("UPDATE activations SET last_seen=? WHERE key_hash=? AND hwid=?",
                             (now, key_hash, hwid))
            self._db.execute("UPDATE licenses SET last_seen=? WHERE key_hash=?", (now, key_hash))
            self._db.commit()

    def release_activation(self, key_hash: str, hwid: str) -> bool:
        with self._lock:
            cur = self._db.execute("UPDATE activations SET released=1 WHERE key_hash=? AND hwid=?",
                                   (key_hash, hwid))
            self._db.commit()
            return cur.rowcount > 0

    def release_all(self, key_hash: str) -> int:
        with self._lock:
            cur = self._db.execute("UPDATE activations SET released=1 WHERE key_hash=? "
                                   "AND released=0", (key_hash,))
            self._db.commit()
            return cur.rowcount

    def refresh_status(self, rec: dict) -> dict:
        """Пересчитать статус по факту (истёк срок / есть активации)."""
        kh = rec["key_hash"]
        if rec["status"] == ST_REVOKED:
            return rec
        exp = int(rec.get("expires_at") or 0)
        acts = self.activations(kh, active_only=True)
        if exp and time.time() > exp:
            new = ST_EXPIRED
        elif acts:
            new = ST_ACTIVE
        else:
            new = ST_INACTIVE
        if new != rec["status"]:
            with self._lock:
                self._db.execute("UPDATE licenses SET status=? WHERE key_hash=?", (new, kh))
                self._db.commit()
            rec = self.get_by_hash(kh)
        return rec

    # ---------------------------------------------------------------- сводка
    def stats(self) -> dict:
        out = {"total": self.count()}
        for st in (ST_INACTIVE, ST_ACTIVE, ST_REVOKED, ST_EXPIRED):
            out[st] = self.count(st)
        with self._lock:
            out["devices"] = self._db.execute(
                "SELECT COUNT(*) AS n FROM activations WHERE released=0").fetchone()["n"]
            row = self._db.execute("SELECT MAX(ts) AS m FROM audit").fetchone()
        out["last_event"] = row["m"] if row else None
        return out
